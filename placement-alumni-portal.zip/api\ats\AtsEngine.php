<?php
/**
 * ATS Resume Checker & Analysis Engine
 * Extracts text from PDF and DOCX, runs algorithmic ATS audit, and performs Job Description matching.
 */

class AtsEngine {

    /**
     * Dictionary of 150+ high-frequency technical and domain skills
     */
    public static array $techSkillDictionary = [
        // Languages
        'Java', 'Python', 'C++', 'C', 'C#', '.NET', 'JavaScript', 'TypeScript', 'PHP', 'Go', 'Golang',
        'Rust', 'Ruby', 'Kotlin', 'Swift', 'SQL', 'R', 'HTML', 'HTML5', 'CSS', 'CSS3', 'Bash', 'Shell',
        // Frameworks & Web
        'Spring Boot', 'Spring MVC', 'Hibernate', 'React', 'React.js', 'Angular', 'AngularJS', 'Vue', 'Vue.js',
        'Node.js', 'Express', 'Express.js', 'Django', 'Flask', 'FastAPI', 'Laravel', 'ASP.NET', 'Next.js',
        'Bootstrap', 'Tailwind CSS', 'jQuery', 'REST', 'RESTful APIs', 'GraphQL', 'Microservices', 'WebSockets',
        // Databases & Storage
        'MySQL', 'PostgreSQL', 'MongoDB', 'Redis', 'Oracle', 'SQLite', 'Cassandra', 'DynamoDB', 'Elasticsearch',
        // Cloud & DevOps
        'AWS', 'Amazon Web Services', 'Azure', 'Microsoft Azure', 'GCP', 'Google Cloud', 'Docker', 'Kubernetes',
        'CI/CD', 'Jenkins', 'Git', 'GitHub', 'GitLab', 'Linux', 'Ubuntu', 'Terraform', 'Ansible', 'Nginx',
        // AI / ML & Data
        'Machine Learning', 'Deep Learning', 'PyTorch', 'TensorFlow', 'Keras', 'Scikit-Learn', 'Pandas',
        'NumPy', 'Data Analysis', 'Computer Vision', 'NLP', 'Natural Language Processing', 'Generative AI',
        // Core Computer Science
        'Data Structures', 'Algorithms', 'OOP', 'Object Oriented Programming', 'DBMS', 'Operating Systems',
        'Computer Networks', 'System Design', 'Distributed Systems', 'Multithreading', 'Concurrency'
    ];

    /**
     * Soft skills dictionary
     */
    public static array $softSkillDictionary = [
        'Problem Solving', 'Critical Thinking', 'Team Collaboration', 'Team Leadership', 'Communication',
        'Agile', 'Scrum', 'Time Management', 'Adaptability', 'Emotional Intelligence', 'Mentorship',
        'Analytical Thinking', 'Detail Oriented', 'Ownership', 'Presentation Skills'
    ];

    /**
     * High-impact action verbs (XYZ Formula)
     */
    public static array $actionVerbs = [
        'architected', 'spearheaded', 'engineered', 'optimized', 'automated', 'deployed', 'implemented',
        'designed', 'developed', 'refactored', 'streamlined', 'reduced', 'increased', 'accelerated',
        'formulated', 'orchestrated', 'pioneered', 'maximized', 'benchmarked', 'delivered', 'supervised'
    ];

    /**
     * Extract text from DOCX (reading word/document.xml)
     */
    public static function extractDocxText(string $filePath): string {
        if (!class_exists('ZipArchive')) {
            return '';
        }
        $zip = new ZipArchive();
        if ($zip->open($filePath) === true) {
            $xmlIndex = $zip->locateName('word/document.xml');
            if ($xmlIndex !== false) {
                $xmlData = $zip->getFromIndex($xmlIndex);
                $zip->close();
                // Strip tags with space separation
                $xmlData = str_replace(['</w:p>', '</w:tr>'], ["\n", "\n"], $xmlData);
                return trim(strip_tags($xmlData));
            }
            $zip->close();
        }
        return '';
    }

    /**
     * Extract text from PDF (pure PHP streams & object string parser)
     */
    public static function extractPdfText(string $filePath): string {
        $content = @file_get_contents($filePath);
        if (!$content) return '';

        $text = '';

        // Check for streams
        preg_match_all('#stream[\r\n]+(.*?)[\r\n]+endstream#s', $content, $matches);
        if (!empty($matches[1])) {
            foreach ($matches[1] as $stream) {
                // Try gzuncompress if stream was FlateDecode
                $uncompressed = @gzuncompress($stream);
                $dataToScan = ($uncompressed !== false) ? $uncompressed : $stream;

                // Look for text chunks enclosed in parentheses within text operators BT ... ET
                if (preg_match_all('#\((.*?)\)\s*(?:Tj|TJ|\')#s', $dataToScan, $textMatches)) {
                    foreach ($textMatches[1] as $tm) {
                        $text .= $tm . ' ';
                    }
                    $text .= "\n";
                }
            }
        }

        // If streams didn't yield text (e.g. uncompressed plain text PDF), extract plain text blocks
        if (strlen(trim($text)) < 50) {
            if (preg_match_all('#\(([^()]{3,})\)#', $content, $stringMatches)) {
                $text = implode(' ', $stringMatches[1]);
            }
        }

        // Clean up escaped PDF characters
        $text = str_replace(['\\(', '\\)', '\\\\'], ['(', ')', '\\'], $text);
        return trim(preg_replace('/\s+/', ' ', $text));
    }

    /**
     * Complete ATS Audit Algorithm
     */
    public static function analyzeResume(string $text): array {
        $textLower = strtolower($text);
        $wordCount = str_word_count($text);

        // 1. Contact Information Audit (Max 10)
        $hasEmail = (bool)preg_match('/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/', $text);
        $hasPhone = (bool)preg_match('/(?:\+?\d{1,3}[-.\s]?)?\(?\d{3,5}\)?[-.\s]?\d{3,5}[-.\s]?\d{3,5}/', $text);
        $hasLinkedIn = (stripos($textLower, 'linkedin.com') !== false || stripos($textLower, 'linkedin') !== false);
        $hasGitHub = (stripos($textLower, 'github.com') !== false || stripos($textLower, 'github') !== false);

        $contactScore = 0;
        if ($hasEmail) $contactScore += 3;
        if ($hasPhone) $contactScore += 3;
        if ($hasLinkedIn) $contactScore += 2;
        if ($hasGitHub) $contactScore += 2;

        // 2. Summary Audit (Max 10)
        $hasSummaryHeading = (bool)preg_match('/(professional summary|summary|career objective|about me|profile)/i', $text);
        $summaryScore = 0;
        if ($hasSummaryHeading) $summaryScore += 6;
        if ($hasSummaryHeading && $wordCount >= 200) $summaryScore += 4;
        elseif ($hasSummaryHeading) $summaryScore += 2;

        // 3. Education Audit (Max 15)
        $hasEduHeading = (bool)preg_match('/(education|academic|qualifications|university|college)/i', $text);
        $hasDegree = (bool)preg_match('/(b\.tech|bachelor|b\.e|m\.tech|master|diploma|hsc|degree)/i', $text);
        $hasCgpa = (bool)preg_match('/(cgpa|gpa|percentage|%|[0-9]\.[0-9]{1,2}\s*\/\s*10)/i', $text);

        $eduScore = 0;
        if ($hasEduHeading) $eduScore += 5;
        if ($hasDegree) $eduScore += 5;
        if ($hasCgpa) $eduScore += 5;

        // 4. Skills Audit (Max 25)
        $detectedTech = [];
        foreach (self::$techSkillDictionary as $skill) {
            // Match word boundary
            $pattern = '/\b' . preg_quote(strtolower($skill), '/') . '\b/i';
            if (preg_match($pattern, $text)) {
                $detectedTech[] = $skill;
            }
        }
        $detectedTech = array_values(array_unique($detectedTech));

        $detectedSoft = [];
        foreach (self::$softSkillDictionary as $sskill) {
            $pattern = '/\b' . preg_quote(strtolower($sskill), '/') . '\b/i';
            if (preg_match($pattern, $text)) {
                $detectedSoft[] = $sskill;
            }
        }
        $detectedSoft = array_values(array_unique($detectedSoft));

        $skillsScore = 0;
        $techCount = count($detectedTech);
        if ($techCount >= 10) $skillsScore += 18;
        elseif ($techCount >= 6) $skillsScore += 14;
        elseif ($techCount >= 3) $skillsScore += 8;
        else $skillsScore += 4;

        if (count($detectedSoft) >= 3) $skillsScore += 7;
        elseif (count($detectedSoft) >= 1) $skillsScore += 4;

        // 5. Experience & Projects Audit (Max 20)
        $hasExpHeading = (bool)preg_match('/(experience|internship|work history|employment)/i', $text);
        $hasProjHeading = (bool)preg_match('/(projects|academic projects|technical projects)/i', $text);

        $detectedVerbs = [];
        foreach (self::$actionVerbs as $verb) {
            if (preg_match('/\b' . $verb . '\b/i', $text)) {
                $detectedVerbs[] = $verb;
            }
        }

        $expScore = 0;
        if ($hasExpHeading) $expScore += 6;
        if ($hasProjHeading) $expScore += 6;
        if (count($detectedVerbs) >= 6) $expScore += 8;
        elseif (count($detectedVerbs) >= 3) $expScore += 5;
        elseif (count($detectedVerbs) >= 1) $expScore += 2;

        // 6. Formatting & Structure (Max 20)
        $formattingScore = 0;
        // Ideal word count for student resume: 300 to 650 words
        if ($wordCount >= 280 && $wordCount <= 700) {
            $formattingScore += 10;
        } elseif ($wordCount >= 150) {
            $formattingScore += 6;
        } else {
            $formattingScore += 2;
        }

        // Bullet point detection or line break density
        $hasBullets = (substr_count($text, '•') > 3 || substr_count($text, '-') > 5 || substr_count($text, '*') > 3);
        if ($hasBullets) $formattingScore += 6;
        else $formattingScore += 3;

        // Quantifiable metrics detection (%, numbers, currency, scales)
        $hasMetrics = (bool)preg_match('/([0-9]{1,3}%\s*|\b[0-9]{2,}\b|\b[0-9]+\s*ms\b|reduced|increased)/i', $text);
        if ($hasMetrics) $formattingScore += 4;

        // Overall Score Calculation
        $overallScore = $contactScore + $summaryScore + $eduScore + $skillsScore + $expScore + $formattingScore;
        $overallScore = min(100, max(20, $overallScore));

        // Compile Strengths & Weaknesses
        $strengths = [];
        $weaknesses = [];
        $suggestions = [];

        if ($hasEmail && $hasPhone && ($hasLinkedIn || $hasGitHub)) {
            $strengths[] = 'Comprehensive contact header with active professional profiles (LinkedIn/GitHub).';
        } else {
            $weaknesses[] = 'Incomplete contact details. Ensure your professional email, mobile number, and LinkedIn profile are clearly stated at the top.';
            $suggestions[] = 'Add direct links to your GitHub and LinkedIn profiles to help recruiters inspect code samples.';
        }

        if ($techCount >= 8) {
            $strengths[] = "Strong technical footprint: {$techCount} industry-standard technical competencies recognized.";
        } else {
            $weaknesses[] = 'Low density of technical keywords. ATS parsers look for specific languages, databases, and frameworks.';
            $suggestions[] = 'Group your skills into clear categories: Programming Languages, Frameworks, Databases, and Developer Tools.';
        }

        if (count($detectedVerbs) >= 5) {
            $strengths[] = 'Effective use of strong action verbs (e.g. ' . implode(', ', array_slice($detectedVerbs, 0, 4)) . ') displaying ownership.';
        } else {
            $weaknesses[] = 'Passive language detected. Descriptions use terms like "responsible for" or "helped in" instead of impact verbs.';
            $suggestions[] = 'Rewrite bullets using the XYZ formula: Accomplished [X] as measured by [Y] by doing [Z]. Start with verbs like Architected, Engineered, or Automated.';
        }

        if ($hasMetrics) {
            $strengths[] = 'Includes quantifiable metrics (percentages, performance stats) validating business or technical impact.';
        } else {
            $weaknesses[] = 'Few numerical metrics. Technical recruiters prioritize candidates who measure project performance.';
            $suggestions[] = 'Quantify your accomplishments (e.g. "Reduced API response times by 35%", "Engineered pipeline handling 5,000 requests/day").';
        }

        if ($hasSummaryHeading) {
            $strengths[] = 'Dedicated professional summary highlighting career ambition and core strengths.';
        } else {
            $suggestions[] = 'Include a concise 2-3 sentence Professional Summary tailored to your target software role.';
        }

        $formattingFeedback = [
            "Word Count: {$wordCount} words (" . ($wordCount >= 280 && $wordCount <= 700 ? 'Optimal for 1-page resume' : ($wordCount < 280 ? 'Too short' : 'Consider trimming')) . ').',
            "Action Verbs Detected: " . count($detectedVerbs) . " strong action verbs.",
            "Technical Skills Count: {$techCount} skills matched.",
            "Soft Skills Count: " . count($detectedSoft) . " competencies found."
        ];

        return [
            'overall_score' => $overallScore,
            'rating' => ($overallScore >= 80) ? 'Excellent' : (($overallScore >= 65) ? 'Good' : 'Needs Optimization'),
            'section_scores' => [
                'contact' => ['score' => $contactScore, 'max' => 10, 'label' => 'Contact Information'],
                'summary' => ['score' => $summaryScore, 'max' => 10, 'label' => 'Professional Summary'],
                'education' => ['score' => $eduScore, 'max' => 15, 'label' => 'Education & Academics'],
                'skills' => ['score' => $skillsScore, 'max' => 25, 'label' => 'Technical & Soft Skills'],
                'experience' => ['score' => $expScore, 'max' => 20, 'label' => 'Experience & Projects'],
                'formatting' => ['score' => $formattingScore, 'max' => 20, 'label' => 'Formatting & Structure']
            ],
            'extracted_data' => [
                'email' => $hasEmail,
                'phone' => $hasPhone,
                'linkedin' => $hasLinkedIn,
                'github' => $hasGitHub,
                'detected_tech_skills' => $detectedTech,
                'detected_soft_skills' => $detectedSoft,
                'detected_action_verbs' => $detectedVerbs,
                'word_count' => $wordCount
            ],
            'strengths' => $strengths,
            'weaknesses' => $weaknesses,
            'suggestions' => $suggestions,
            'formatting_feedback' => $formattingFeedback,
            'disclaimer' => 'Note: This score is an estimated compatibility score based on algorithmic parsing of standard ATS requirements (format, keyword density, section headers, and metrics). It is not an official score from any proprietary ATS vendor.'
        ];
    }

    /**
     * Job Description Matching Algorithm
     */
    public static function matchJobDescription(string $resumeText, string $jdText): array {
        $resumeLower = strtolower($resumeText);
        $jdLower = strtolower($jdText);

        // 1. Extract required skills from JD using skill dictionaries
        $jdTechSkills = [];
        foreach (self::$techSkillDictionary as $skill) {
            $pattern = '/\b' . preg_quote(strtolower($skill), '/') . '\b/i';
            if (preg_match($pattern, $jdText)) {
                $jdTechSkills[] = $skill;
            }
        }
        $jdTechSkills = array_values(array_unique($jdTechSkills));

        // 2. Classify into Matched and Missing
        $matchedSkills = [];
        $missingSkills = [];

        foreach ($jdTechSkills as $skill) {
            $pattern = '/\b' . preg_quote(strtolower($skill), '/') . '\b/i';
            if (preg_match($pattern, $resumeText)) {
                $matchedSkills[] = $skill;
            } else {
                $missingSkills[] = $skill;
            }
        }

        // 3. Extract common keywords from JD
        $stopWords = ['and', 'the', 'for', 'with', 'you', 'will', 'are', 'our', 'this', 'that', 'have', 'from', 'your', 'about', 'must', 'work', 'years', 'team', 'candidate', 'experience', 'knowledge', 'ability', 'degree'];
        $words = preg_split('/[^a-zA-Z0-9+#]+/', $jdLower);
        $wordFreq = [];
        foreach ($words as $w) {
            $w = trim($w);
            if (strlen($w) >= 4 && !in_array($w, $stopWords, true) && !is_numeric($w)) {
                $wordFreq[$w] = ($wordFreq[$w] ?? 0) + 1;
            }
        }
        arsort($wordFreq);
        $topJdKeywords = array_slice(array_keys($wordFreq), 0, 15);

        $matchedKeywords = [];
        $missingKeywords = [];
        foreach ($topJdKeywords as $kw) {
            if (stripos($resumeLower, $kw) !== false) {
                $matchedKeywords[] = ucfirst($kw);
            } else {
                $missingKeywords[] = ucfirst($kw);
            }
        }

        // 4. Calculate Match Percentage
        $totalExpected = count($jdTechSkills) + count($topJdKeywords);
        $totalMatched = count($matchedSkills) + count($matchedKeywords);

        $matchPercentage = 50;
        if ($totalExpected > 0) {
            $matchPercentage = (int)round(($totalMatched / $totalExpected) * 100);
            $matchPercentage = min(98, max(25, $matchPercentage));
        }

        // 5. Tailored Suggestions
        $suggestions = [];
        if (!empty($missingSkills)) {
            $sampleMissing = array_slice($missingSkills, 0, 4);
            $suggestions[] = "The Job Description heavily emphasizes: " . implode(', ', $sampleMissing) . ". If you have hands-on experience or coursework in these areas, make sure they are prominently featured in your Skills or Project sections.";
        }
        if (!empty($matchedSkills)) {
            $suggestions[] = "Great alignment on core technologies: " . implode(', ', array_slice($matchedSkills, 0, 5)) . ". Emphasize these in your project bullet points.";
        }
        $suggestions[] = "Mirror the company's phrasing: If the job description asks for 'microservice architecture' or 'REST APIs', ensure you use those exact terms rather than abbreviations.";
        $suggestions[] = "Ethical Recommendation: Never add skills you haven't worked with. Instead, highlight transferable fundamentals and relevant coursework.";

        return [
            'match_percentage' => $matchPercentage,
            'matched_skills' => $matchedSkills,
            'missing_skills' => $missingSkills,
            'matched_keywords' => $matchedKeywords,
            'missing_keywords' => $missingKeywords,
            'suggestions' => $suggestions,
            'summary' => "Your resume matches approximately {$matchPercentage}% of the target job description criteria."
        ];
    }
}
