<?php
/**
 * API: Public Portfolio Endpoint for Recruiters & Visitors
 * GET: ?slug=...
 * Accessible publicly without login. Tracks view count.
 */

require_once __DIR__ . '/../../config/auth.php';

$pdo = Database::getConnection();

$slug = trim($_GET['slug'] ?? '');
if (empty($slug)) {
    sendError('Portfolio slug is required.', 400);
}

// Fetch published portfolio by slug
$stmt = $pdo->prepare("
    SELECT p.*, s.roll_no, s.branch, s.cgpa, s.year, u.name, u.avatar
    FROM student_portfolios p
    JOIN students s ON p.student_id = s.id
    JOIN users u ON s.user_id = u.id
    WHERE p.slug = :slug LIMIT 1
");
$stmt->execute(['slug' => $slug]);
$port = $stmt->fetch();

if (!$port) {
    sendError('Portfolio not found.', 404);
}

if ((int)$port['is_published'] !== 1) {
    sendError('This portfolio is currently in private/draft mode by the student.', 403);
}

// Increment view count asynchronously
try {
    $pdo->prepare("UPDATE student_portfolios SET views_count = views_count + 1 WHERE id = :id")->execute(['id' => $port['id']]);
} catch (Exception $e) {
    // Non-blocking
}

$portId = (int)$port['id'];

// Fetch components
$edu = $pdo->prepare("SELECT * FROM portfolio_education WHERE portfolio_id = :pid ORDER BY start_year DESC, id DESC");
$edu->execute(['pid' => $portId]);

$skills = $pdo->prepare("SELECT * FROM portfolio_skills WHERE portfolio_id = :pid ORDER BY skill_type ASC, id ASC");
$skills->execute(['pid' => $portId]);

$projects = $pdo->prepare("SELECT * FROM portfolio_projects WHERE portfolio_id = :pid ORDER BY featured DESC, id DESC");
$projects->execute(['pid' => $portId]);

$experiences = $pdo->prepare("SELECT * FROM portfolio_experiences WHERE portfolio_id = :pid ORDER BY id DESC");
$experiences->execute(['pid' => $portId]);

$certifications = $pdo->prepare("SELECT * FROM portfolio_certifications WHERE portfolio_id = :pid ORDER BY id DESC");
$certifications->execute(['pid' => $portId]);

$achievements = $pdo->prepare("SELECT * FROM portfolio_achievements WHERE portfolio_id = :pid ORDER BY id DESC");
$achievements->execute(['pid' => $portId]);

$payload = [
    'name' => $port['name'],
    'roll_no' => $port['roll_no'],
    'branch' => $port['branch'],
    'cgpa' => (float)$port['cgpa'],
    'headline' => $port['headline'],
    'about_me' => $port['about_me'],
    'location' => $port['location'],
    'phone' => $port['phone'],
    'email' => $port['email'],
    'github_url' => $port['github_url'],
    'linkedin_url' => $port['linkedin_url'],
    'website_url' => $port['website_url'],
    'profile_photo' => $port['profile_photo'] ?: $port['avatar'],
    'template' => $port['template'] ?: 'modern',
    'primary_color' => $port['primary_color'] ?: '#4f46e5',
    'views_count' => (int)$port['views_count'] + 1,
    'education' => $edu->fetchAll(),
    'skills' => $skills->fetchAll(),
    'projects' => $projects->fetchAll(),
    'experiences' => $experiences->fetchAll(),
    'certifications' => $certifications->fetchAll(),
    'achievements' => $achievements->fetchAll()
];

sendJson([
    'success' => true,
    'portfolio' => $payload,
    'data' => $payload
]);
