<?php
/**
 * Configuration for InfinityFree Live Hosting
 * Domain: https://dipak-placement-portal.infinityfreeapp.com
 */

// Replace these 4 values with the credentials from your InfinityFree "MySQL Databases" page:
define('DB_HOST', 'sqlxxx.infinityfree.com');      // e.g. sql100.infinityfree.com
define('DB_PORT', '3306');
define('DB_NAME', 'if0_xxxxxxx_placement');       // Your InfinityFree DB Name
define('DB_USER', 'if0_xxxxxxx');                 // Your InfinityFree DB Username
define('DB_PASS', 'YOUR_INFINITYFREE_PASSWORD');   // Your InfinityFree vPanel Password
define('DB_CHARSET', 'utf8mb4');

// Production Application URL
define('APP_URL', 'https://dipak-placement-portal.infinityfreeapp.com');

// Session configuration
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    session_start();
}

// Upload paths
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('RESUME_DIR', UPLOAD_DIR . 'resumes/');

// Helper functions
require_once __DIR__ . '/Database.php';

function sendJson($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function sendError($message, $statusCode = 400) {
    sendJson(['success' => false, 'message' => $message], $statusCode);
}
