<?php
/**
 * API: Get Student ATS History
 * GET: Fetches uploaded resumes, current score, and recent JD comparisons
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireRole(['student']);
$pdo = Database::getConnection();

$studentId = (int)($user['student_profile']['id'] ?? 0);
if ($studentId <= 0) {
    sendError('Student profile not found.', 404);
}

// Resumes list
$rStmt = $pdo->prepare("SELECT id, original_filename, stored_filename, file_type, file_size, uploaded_at FROM resumes WHERE student_id = :sid ORDER BY id DESC");
$rStmt->execute(['sid' => $studentId]);
$resumes = $rStmt->fetchAll();

// Latest Analysis
$latestAnalysis = null;
if (!empty($resumes)) {
    $aStmt = $pdo->prepare("SELECT * FROM ats_analyses WHERE student_id = :sid ORDER BY id DESC LIMIT 1");
    $aStmt->execute(['sid' => $studentId]);
    $row = $aStmt->fetch();
    if ($row) {
        $latestAnalysis = [
            'id' => (int)$row['id'],
            'resume_id' => (int)$row['resume_id'],
            'overall_score' => (int)$row['overall_score'],
            'rating' => ($row['overall_score'] >= 80) ? 'Excellent' : (($row['overall_score'] >= 65) ? 'Good' : 'Needs Optimization'),
            'section_scores' => json_decode($row['section_scores'], true),
            'extracted_data' => json_decode($row['extracted_data'], true),
            'strengths' => json_decode($row['strengths'], true),
            'weaknesses' => json_decode($row['weaknesses'], true),
            'suggestions' => json_decode($row['suggestions'], true),
            'formatting_feedback' => json_decode($row['formatting_feedback'], true),
            'analyzed_at' => $row['analyzed_at']
        ];
    }
}

// Recent JD comparisons
$jcStmt = $pdo->prepare("SELECT id, job_title, job_company, match_percentage, compared_at FROM job_comparisons WHERE student_id = :sid ORDER BY id DESC LIMIT 5");
$jcStmt->execute(['sid' => $studentId]);
$comparisons = $jcStmt->fetchAll();

sendJson([
    'success' => true,
    'resumes' => $resumes,
    'latest_analysis' => $latestAnalysis,
    'recent_comparisons' => $comparisons
]);
