<?php
/**
 * API: Analyze Existing Resume / Fetch Analysis
 * POST / GET: ?resume_id=...
 */

require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/AtsEngine.php';

$user = requireRole(['student']);
$pdo = Database::getConnection();

$studentId = (int)($user['student_profile']['id'] ?? 0);
if ($studentId <= 0) {
    sendError('Student profile not found.', 404);
}

$data = getRequestData();
$resumeId = (int)($data['resume_id'] ?? ($_GET['resume_id'] ?? 0));

if ($resumeId <= 0) {
    // Look up student's latest uploaded resume
    $rStmt = $pdo->prepare("SELECT * FROM resumes WHERE student_id = :sid ORDER BY id DESC LIMIT 1");
    $rStmt->execute(['sid' => $studentId]);
    $resume = $rStmt->fetch();
} else {
    $rStmt = $pdo->prepare("SELECT * FROM resumes WHERE id = :id AND student_id = :sid LIMIT 1");
    $rStmt->execute(['id' => $resumeId, 'sid' => $studentId]);
    $resume = $rStmt->fetch();
}

if (!$resume) {
    sendError('No uploaded resume found. Please upload a resume first.', 404);
}

// Fetch existing latest analysis or re-run
$aStmt = $pdo->prepare("SELECT * FROM ats_analyses WHERE resume_id = :rid ORDER BY id DESC LIMIT 1");
$aStmt->execute(['rid' => $resume['id']]);
$existingAts = $aStmt->fetch();

if ($existingAts && $_SERVER['REQUEST_METHOD'] === 'GET') {
    sendJson([
        'success' => true,
        'resume' => [
            'id' => (int)$resume['id'],
            'original_filename' => $resume['original_filename'],
            'stored_filename' => $resume['stored_filename'],
            'file_type' => $resume['file_type'],
            'file_size' => (int)$resume['file_size'],
            'file_url' => 'uploads/resumes/' . $resume['stored_filename'],
            'uploaded_at' => $resume['uploaded_at']
        ],
        'analysis' => [
            'id' => (int)$existingAts['id'],
            'overall_score' => (int)$existingAts['overall_score'],
            'rating' => ($existingAts['overall_score'] >= 80) ? 'Excellent' : (($existingAts['overall_score'] >= 65) ? 'Good' : 'Needs Optimization'),
            'section_scores' => json_decode($existingAts['section_scores'], true),
            'extracted_data' => json_decode($existingAts['extracted_data'], true),
            'strengths' => json_decode($existingAts['strengths'], true),
            'weaknesses' => json_decode($existingAts['weaknesses'], true),
            'suggestions' => json_decode($existingAts['suggestions'], true),
            'formatting_feedback' => json_decode($existingAts['formatting_feedback'], true),
            'analyzed_at' => $existingAts['analyzed_at'],
            'disclaimer' => 'Note: This score is an estimated compatibility score based on standard ATS parsing algorithms. It is not an actual score from any company\'s proprietary ATS software.'
        ]
    ]);
}

// Re-analyze
$analysis = AtsEngine::analyzeResume($resume['extracted_text'] ?: '');

$insAts = $pdo->prepare("
    INSERT INTO ats_analyses (student_id, resume_id, overall_score, section_scores, extracted_data, strengths, weaknesses, suggestions, formatting_feedback)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
");
$insAts->execute([
    $studentId,
    $resume['id'],
    $analysis['overall_score'],
    json_encode($analysis['section_scores']),
    json_encode($analysis['extracted_data']),
    json_encode($analysis['strengths']),
    json_encode($analysis['weaknesses']),
    json_encode($analysis['suggestions']),
    json_encode($analysis['formatting_feedback'])
]);

sendJson([
    'success' => true,
    'message' => 'ATS re-analysis completed!',
    'resume' => [
        'id' => (int)$resume['id'],
        'original_filename' => $resume['original_filename'],
        'stored_filename' => $resume['stored_filename'],
        'file_type' => $resume['file_type'],
        'file_size' => (int)$resume['file_size'],
        'file_url' => 'uploads/resumes/' . $resume['stored_filename'],
        'uploaded_at' => $resume['uploaded_at']
    ],
    'analysis' => $analysis
]);
