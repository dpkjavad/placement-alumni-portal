<?php
/**
 * API: Placement Readiness Score Calculator
 * Implements Phase 11: Feature 3 (Placement Readiness Score)
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireLogin();
$pdo = Database::getConnection();

$studentId = 0;
if ($user['role'] === 'student') {
    $studentId = (int)($user['student_profile']['id'] ?? 0);
} else {
    $studentId = (int)($_GET['student_id'] ?? 0);
}

if ($studentId <= 0) {
    sendError('Student profile ID required.', 400);
}

// Fetch student details
$stStmt = $pdo->prepare("SELECT * FROM students WHERE id = :sid LIMIT 1");
$stStmt->execute(['sid' => $studentId]);
$student = $stStmt->fetch();
if (!$student) sendError('Student record not found.', 404);

// Fetch portfolio projects count
$portStmt = $pdo->prepare("
    SELECT COUNT(pp.id) AS project_count, sp.id AS port_id
    FROM student_portfolios sp
    LEFT JOIN portfolio_projects pp ON pp.portfolio_id = sp.id
    WHERE sp.student_id = :sid
    GROUP BY sp.id
");
$portStmt->execute(['sid' => $studentId]);
$portData = $portStmt->fetch();
$projectCount = (int)($portData['project_count'] ?? 0);

// Score factors breakdown
$breakdown = [];
$totalScore = 0;

// 1. Resume Upload (20 pts)
$hasResume = !empty($student['resume']);
$resumeScore = $hasResume ? 20 : 0;
$totalScore += $resumeScore;
$breakdown['resume'] = [
    'title' => 'Active Resume',
    'score' => $resumeScore,
    'max' => 20,
    'status' => $hasResume ? 'completed' : 'pending',
    'tip' => $hasResume ? 'Resume uploaded and ready for recruitment drives.' : 'Upload your updated PDF/DOCX resume in the Resume Manager.'
];

// 2. Technical Skills (20 pts)
$skillsArr = array_filter(array_map('trim', explode(',', $student['skills'] ?? '')));
$skillsCount = count($skillsArr);
$skillsScore = min(20, $skillsCount * 4);
$totalScore += $skillsScore;
$breakdown['skills'] = [
    'title' => 'Technical Skills',
    'score' => $skillsScore,
    'max' => 20,
    'status' => ($skillsScore >= 16) ? 'completed' : 'needs_work',
    'tip' => ($skillsCount >= 5) ? "Good skills portfolio ({$skillsCount} skills documented)." : "Add at least 5 technical skills to improve drive matching."
];

// 3. Coding & Professional Profiles (30 pts)
$hasGithub = !empty($student['github_url']);
$hasHackerRank = !empty($student['hackerrank_url']);
$hasLinkedin = !empty($student['linkedin_url']);
$codingScore = ($hasGithub ? 10 : 0) + ($hasHackerRank ? 10 : 0) + ($hasLinkedin ? 10 : 0);
$totalScore += $codingScore;
$breakdown['profiles'] = [
    'title' => 'Coding & Professional Profiles',
    'score' => $codingScore,
    'max' => 30,
    'status' => ($codingScore === 30) ? 'completed' : 'needs_work',
    'details' => [
        'github' => $hasGithub,
        'hackerrank' => $hasHackerRank,
        'linkedin' => $hasLinkedin
    ],
    'tip' => ($codingScore === 30) 
        ? 'All developer profiles (GitHub, HackerRank, LinkedIn) connected.' 
        : 'Connect GitHub, HackerRank, and LinkedIn profiles on your profile page.'
];

// 4. Projects Showcase (15 pts)
$projScore = min(15, $projectCount * 5);
$totalScore += $projScore;
$breakdown['projects'] = [
    'title' => 'Project Portfolio',
    'score' => $projScore,
    'max' => 15,
    'status' => ($projScore >= 10) ? 'completed' : 'needs_work',
    'tip' => ($projectCount >= 2) ? "{$projectCount} featured projects listed." : 'Add at least 2 hands-on projects to your student portfolio.'
];

// 5. Academic Profile (15 pts)
$cgpa = (float)($student['cgpa'] ?? 0);
$academicScore = ($cgpa >= 8.5) ? 15 : (($cgpa >= 7.5) ? 12 : (($cgpa >= 6.5) ? 9 : 6));
$totalScore += $academicScore;
$breakdown['academics'] = [
    'title' => 'Academic Profile (CGPA)',
    'score' => $academicScore,
    'max' => 15,
    'status' => ($cgpa >= 7.5) ? 'completed' : 'needs_work',
    'tip' => "Current CGPA: {$cgpa}. Maintain above 7.5 to unlock 90%+ of recruitment drives."
];

// Rating tier
$tier = 'Needs Preparation';
$badgeColor = 'danger';
if ($totalScore >= 80) {
    $tier = 'Placement Ready';
    $badgeColor = 'success';
} elseif ($totalScore >= 60) {
    $tier = 'Moderately Prepared';
    $badgeColor = 'warning';
}

sendJson([
    'success' => true,
    'overall_score' => $totalScore,
    'tier' => $tier,
    'badge_color' => $badgeColor,
    'breakdown' => $breakdown,
    'disclaimer' => 'The Placement Readiness Score is an indicative analytical assessment calculated based on profile completeness and preparation factors. It does not constitute a legal or contractual employment guarantee.'
]);
