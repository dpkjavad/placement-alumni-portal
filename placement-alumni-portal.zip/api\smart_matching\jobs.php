<?php
/**
 * API: Smart Job Matching & Skill Gap Analyzer
 * Implements Phase 11: Feature 1 & 2 (Smart Matching & Skill Gap Analyzer)
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireLogin();
$pdo = Database::getConnection();

$studentId = 0;
if ($user['role'] === 'student') {
    $studentId = (int)($user['student_profile']['id'] ?? 0);
} else {
    $studentId = (int)($_GET['student_id'] ?? 0);
}

if ($studentId <= 0) {
    sendError('Student profile required for smart job matching.', 400);
}

// Fetch student profile & skills
$stStmt = $pdo->prepare("SELECT * FROM students WHERE id = :sid LIMIT 1");
$stStmt->execute(['sid' => $studentId]);
$student = $stStmt->fetch();
if (!$student) sendError('Student record not found.', 404);

// Parse student skills into normalized array
$rawStudentSkills = array_filter(array_map('trim', explode(',', strtolower($student['skills'] ?? ''))));
// Also add skills from student portfolio if available
$portSkillsStmt = $pdo->prepare("
    SELECT ps.skill_name 
    FROM portfolio_skills ps
    JOIN student_portfolios sp ON ps.portfolio_id = sp.id
    WHERE sp.student_id = :sid
");
$portSkillsStmt->execute(['sid' => $studentId]);
$portSkills = $portSkillsStmt->fetchAll(PDO::FETCH_COLUMN);
foreach ($portSkills as $psk) {
    $clean = strtolower(trim($psk));
    if (!empty($clean) && !in_array($clean, $rawStudentSkills, true)) {
        $rawStudentSkills[] = $clean;
    }
}

// Fetch all active placement drives
$drivesStmt = $pdo->query("
    SELECT d.*, c.company_name, c.industry, c.logo
    FROM drives d
    JOIN companies c ON d.company_id = c.id
    WHERE d.status = 'active'
    ORDER BY d.drive_date ASC
");
$drives = $drivesStmt->fetchAll();

$matches = [];
$studentCgpa = (float)($student['cgpa'] ?? 0);
$studentBranch = strtolower(trim($student['branch'] ?? ''));

foreach ($drives as $drive) {
    $driveSkills = array_filter(array_map('trim', explode(',', strtolower($drive['skills'] ?? ''))));
    $eligibleBranches = array_filter(array_map('trim', explode(',', strtolower($drive['eligible_branches'] ?? ''))));
    $minCgpa = (float)($drive['min_cgpa'] ?? 0);

    // 1. Academic eligibility
    $cgpaEligible = ($studentCgpa >= $minCgpa);
    $branchEligible = false;
    foreach ($eligibleBranches as $eb) {
        if (strpos($studentBranch, $eb) !== false || strpos($eb, $studentBranch) !== false || strpos($eb, 'all') !== false) {
            $branchEligible = true;
            break;
        }
    }

    // 2. Skill overlap calculation
    $matchingSkills = [];
    $missingSkills = [];
    foreach ($driveSkills as $ds) {
        $found = false;
        foreach ($rawStudentSkills as $ss) {
            if (strpos($ss, $ds) !== false || strpos($ds, $ss) !== false) {
                $found = true;
                break;
            }
        }
        if ($found) {
            $matchingSkills[] = ucwords($ds);
        } else {
            $missingSkills[] = ucwords($ds);
        }
    }

    $totalSkillsCount = count($driveSkills);
    $skillScore = ($totalSkillsCount > 0) ? (count($matchingSkills) / $totalSkillsCount) * 60 : 40;
    $cgpaScore = $cgpaEligible ? 25 : max(0, 25 - ($minCgpa - $studentCgpa) * 10);
    $branchScore = $branchEligible ? 15 : 5;

    $overallMatch = round($skillScore + $cgpaScore + $branchScore);
    $overallMatch = min(100, max(15, $overallMatch));

    // Learning roadmap suggestions for missing skills
    $learningRoadmap = [];
    foreach ($missingSkills as $ms) {
        $learningRoadmap[] = [
            'skill' => $ms,
            'suggestion' => "Practice core concepts and build a hands-on project utilizing {$ms}.",
            'priority' => in_array(strtolower($ms), ['java', 'python', 'sql', 'dsa', 'react', 'spring boot']) ? 'High' : 'Medium'
        ];
    }

    $matches[] = [
        'drive_id' => (int)$drive['id'],
        'company_name' => $drive['company_name'],
        'job_role' => $drive['job_role'],
        'package' => (float)$drive['package'],
        'location' => $drive['location'],
        'drive_date' => $drive['drive_date'],
        'deadline' => $drive['deadline'],
        'match_percentage' => $overallMatch,
        'cgpa_eligible' => $cgpaEligible,
        'branch_eligible' => $branchEligible,
        'student_cgpa' => $studentCgpa,
        'min_cgpa' => $minCgpa,
        'matching_skills' => $matchingSkills,
        'missing_skills' => $missingSkills,
        'learning_roadmap' => $learningRoadmap
    ];
}

// Sort matches descending by match percentage
usort($matches, function ($a, $b) {
    return $b['match_percentage'] <=> $a['match_percentage'];
});

sendJson([
    'success' => true,
    'data' => $matches,
    'total_matches' => count($matches)
]);
