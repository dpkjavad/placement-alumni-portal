<?php
/**
 * API: Comprehensive Administrator Analytics & System Overview
 * Implements Phase 10: Complete Administrator Control Dashboard
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireRole(['admin', 'officer']);
$pdo = Database::getConnection();

// System KPIs
$stats = [];

$stats['total_students'] = (int)$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$stats['total_alumni'] = (int)$pdo->query("SELECT COUNT(*) FROM alumni")->fetchColumn();
$stats['total_companies'] = (int)$pdo->query("SELECT COUNT(*) FROM companies")->fetchColumn();
$stats['total_drives'] = (int)$pdo->query("SELECT COUNT(*) FROM drives")->fetchColumn();
$stats['active_drives'] = (int)$pdo->query("SELECT COUNT(*) FROM drives WHERE status = 'active'")->fetchColumn();
$stats['total_applications'] = (int)$pdo->query("SELECT COUNT(*) FROM applications")->fetchColumn();
$stats['total_placements'] = (int)$pdo->query("SELECT COUNT(*) FROM placements")->fetchColumn();
$stats['upcoming_interviews'] = (int)$pdo->query("SELECT COUNT(*) FROM interview_schedules WHERE status = 'Scheduled' AND interview_date >= CURDATE()")->fetchColumn();
$stats['active_chats'] = (int)$pdo->query("SELECT COUNT(*) FROM chat_requests WHERE status = 'accepted'")->fetchColumn();

// Salary Stats
$pkgStmt = $pdo->query("SELECT MAX(package) AS max_pkg, AVG(package) AS avg_pkg FROM drives");
$pkg = $pkgStmt->fetch();
$stats['highest_package'] = round((float)($pkg['max_pkg'] ?? 0), 1);
$stats['average_package'] = round((float)($pkg['avg_pkg'] ?? 0), 1);

// Recent Audit Logs
$auditStmt = $pdo->query("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 10");
$recentAudits = $auditStmt->fetchAll();

// Recent Placement Offers
$plcStmt = $pdo->query("
    SELECT p.*, s.roll_no, s.branch, u.name AS student_name, c.company_name
    FROM placements p
    JOIN students s ON p.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN companies c ON p.company_id = c.id
    ORDER BY p.id DESC LIMIT 5
");
$recentPlacements = $plcStmt->fetchAll();

sendJson([
    'success' => true,
    'kpis' => $stats,
    'recent_audits' => $recentAudits,
    'recent_placements' => $recentPlacements
]);
