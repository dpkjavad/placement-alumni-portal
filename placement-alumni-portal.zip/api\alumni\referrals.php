<?php
/**
 * API: Alumni Job Referral Network
 * Implements Phase 11: Feature 5 (Alumni Referral System)
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireLogin();
$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

// 1. GET: Fetch active referrals
if ($method === 'GET') {
    $stmt = $pdo->query("
        SELECT r.*, u.name AS alumni_name, u.avatar AS alumni_avatar, a.company AS alumni_company, a.job_role AS alumni_role,
               (SELECT COUNT(*) FROM referral_applications ra WHERE ra.referral_id = r.id) AS applicants_count
        FROM alumni_referrals r
        JOIN alumni a ON r.alumni_id = a.id
        JOIN users u ON a.user_id = u.id
        WHERE r.status = 'open'
        ORDER BY r.id DESC
    ");
    $referrals = $stmt->fetchAll();

    // If student, check which referrals they've already applied for
    if ($user['role'] === 'student') {
        $studentId = (int)($user['student_profile']['id'] ?? 0);
        $appStmt = $pdo->prepare("SELECT referral_id, status FROM referral_applications WHERE student_id = :sid");
        $appStmt->execute(['sid' => $studentId]);
        $appliedMap = [];
        while ($row = $appStmt->fetch()) {
            $appliedMap[$row['referral_id']] = $row['status'];
        }

        foreach ($referrals as &$ref) {
            $ref['has_applied'] = isset($appliedMap[$ref['id']]);
            $ref['application_status'] = $appliedMap[$ref['id']] ?? null;
        }
        unset($ref);
    }

    sendJson(['success' => true, 'data' => $referrals]);
}

// 2. POST: Alumni publishes referral OR Student applies
if ($method === 'POST') {
    $data = getRequestData();
    $action = $data['action'] ?? 'create';

    // Student applying for referral
    if ($action === 'apply') {
        $user = requireRole('student');
        $studentId = (int)($user['student_profile']['id'] ?? 0);
        $referralId = (int)($data['referral_id'] ?? 0);
        $notes = trim($data['notes'] ?? '');

        if ($referralId <= 0) sendError('Referral ID is required.');

        // Check if student has active resume
        $st = $user['student_profile'];
        if (empty($st['resume'])) {
            sendError('Please upload your resume in the Student Profile before applying for a referral.');
        }

        // Check if already applied
        $chk = $pdo->prepare("SELECT id FROM referral_applications WHERE referral_id = :rid AND student_id = :sid LIMIT 1");
        $chk->execute(['rid' => $referralId, 'sid' => $studentId]);
        if ($chk->fetch()) {
            sendError('You have already submitted an application for this referral.');
        }

        $ins = $pdo->prepare("
            INSERT INTO referral_applications (referral_id, student_id, resume_url, notes, status)
            VALUES (:rid, :sid, :res, :notes, 'applied')
        ");
        $ins->execute([
            'rid' => $referralId,
            'sid' => $studentId,
            'res' => $st['resume'],
            'notes' => sanitizeString($notes)
        ]);

        // Get alumni user_id to notify them
        $alStmt = $pdo->prepare("SELECT a.user_id, r.company_name, r.job_title FROM alumni_referrals r JOIN alumni a ON r.alumni_id = a.id WHERE r.id = :rid LIMIT 1");
        $alStmt->execute(['rid' => $referralId]);
        $alRecord = $alStmt->fetch();
        if ($alRecord) {
            createNotification(
                (int)$alRecord['user_id'],
                'New Referral Application',
                "Student {$user['name']} applied for your referral opening: {$alRecord['job_title']} at {$alRecord['company_name']}.",
                'system',
                $referralId
            );
        }

        sendJson(['success' => true, 'message' => 'Referral application submitted successfully!']);
    }

    // Alumni creating a new referral opening
    $user = requireRole(['alumni', 'admin']);
    $alumniId = ($user['role'] === 'alumni') ? (int)($user['alumni_profile']['id'] ?? 0) : (int)($data['alumni_id'] ?? 1);
    $companyName = trim($data['company_name'] ?? '');
    $jobTitle = trim($data['job_title'] ?? '');
    $jobUrl = trim($data['job_url'] ?? '');
    $requirements = trim($data['requirements'] ?? '');
    $location = trim($data['location'] ?? 'Pune / Hybrid');
    $deadline = !empty($data['deadline']) ? $data['deadline'] : null;

    if (empty($companyName) || empty($jobTitle) || empty($requirements)) {
        sendError('Company Name, Job Title, and Requirements are required.');
    }

    $stmt = $pdo->prepare("
        INSERT INTO alumni_referrals (alumni_id, company_name, job_title, job_url, requirements, location, deadline, status)
        VALUES (:aid, :comp, :role, :url, :req, :loc, :dl, 'open')
    ");
    $stmt->execute([
        'aid' => $alumniId,
        'comp' => sanitizeString($companyName),
        'role' => sanitizeString($jobTitle),
        'url' => $jobUrl,
        'req' => sanitizeString($requirements),
        'loc' => sanitizeString($location),
        'dl' => $deadline
    ]);
    $newRefId = (int)$pdo->lastInsertId();

    logAudit('Create Referral', "Alumni {$alumniId} posted referral opening for {$jobTitle} at {$companyName}", $user['id']);

    sendJson([
        'success' => true,
        'message' => 'Alumni referral opportunity posted successfully!',
        'id' => $newRefId
    ], 201);
}

sendError('Method Not Allowed', 405);
