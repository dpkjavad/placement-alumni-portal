<?php
/**
 * API: Get Student Portfolio
 * GET: Fetches complete portfolio for authenticated student (or specified student_id for admin/officer)
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireRole(['student', 'admin', 'officer']);
$pdo = Database::getConnection();

$studentId = 0;
if ($user['role'] === 'student') {
    $studentId = (int)($user['student_profile']['id'] ?? 0);
} else {
    $studentId = (int)($_GET['student_id'] ?? 0);
}

if ($studentId <= 0) {
    sendError('Student profile not found or invalid student ID.', 404);
}

// Fetch student details
$sStmt = $pdo->prepare("SELECT s.*, u.name, u.email, u.avatar FROM students s JOIN users u ON s.user_id = u.id WHERE s.id = :id LIMIT 1");
$sStmt->execute(['id' => $studentId]);
$student = $sStmt->fetch();
if (!$student) {
    sendError('Student not found.', 404);
}

// Fetch or initialize portfolio
$pStmt = $pdo->prepare("SELECT * FROM student_portfolios WHERE student_id = :sid LIMIT 1");
$pStmt->execute(['sid' => $studentId]);
$portfolio = $pStmt->fetch();

if (!$portfolio) {
    // Generate unique slug
    $cleanName = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $student['name']));
    $slug = trim($cleanName, '-') . '-' . rand(1000, 9999);

    $initStmt = $pdo->prepare("
        INSERT INTO student_portfolios (student_id, slug, headline, about_me, location, phone, email, is_published, template, primary_color)
        VALUES (:sid, :slug, :head, :about, :loc, :phone, :email, 1, 'modern', '#4f46e5')
    ");
    $initStmt->execute([
        'sid' => $studentId,
        'slug' => $slug,
        'head' => "Aspiring Engineer | {$student['branch']} | Sanjivani University",
        'about' => "Enthusiastic and results-oriented {$student['branch']} undergraduate at Sanjivani University, Kopargaon with a strong foundation in core engineering principles and modern technology frameworks.",
        'loc' => 'Kopargaon, Maharashtra',
        'phone' => $student['phone'] ?: '+91 98220 00000',
        'email' => $student['email']
    ]);
    $portfolioId = (int)$pdo->lastInsertId();

    // Add default education
    $eIns = $pdo->prepare("INSERT INTO portfolio_education (portfolio_id, degree, institution, field_of_study, start_year, end_year, grade_cgpa, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $eIns->execute([
        $portfolioId,
        'B.Tech in ' . $student['branch'],
        'Sanjivani University, Kopargaon',
        $student['branch'],
        2022,
        2026,
        $student['cgpa'] ? "{$student['cgpa']} CGPA" : 'Pursuing',
        'Focused on algorithmic problem solving, software engineering, and industry-oriented projects.'
    ]);

    // Add student's existing skills if available
    if (!empty($student['skills'])) {
        $skList = array_filter(array_map('trim', explode(',', $student['skills'])));
        $skIns = $pdo->prepare("INSERT INTO portfolio_skills (portfolio_id, skill_name, skill_type, proficiency_level) VALUES (?, ?, 'technical', 'advanced')");
        foreach ($skList as $sk) {
            $skIns->execute([$portfolioId, $sk]);
        }
    }

    $pStmt->execute(['sid' => $studentId]);
    $portfolio = $pStmt->fetch();
}

$portfolioId = (int)$portfolio['id'];

// Fetch all child components
$eduStmt = $pdo->prepare("SELECT * FROM portfolio_education WHERE portfolio_id = :pid ORDER BY start_year DESC, id DESC");
$eduStmt->execute(['pid' => $portfolioId]);
$education = $eduStmt->fetchAll();

$skStmt = $pdo->prepare("SELECT * FROM portfolio_skills WHERE portfolio_id = :pid ORDER BY skill_type ASC, id ASC");
$skStmt->execute(['pid' => $portfolioId]);
$skills = $skStmt->fetchAll();

$prStmt = $pdo->prepare("SELECT * FROM portfolio_projects WHERE portfolio_id = :pid ORDER BY featured DESC, id DESC");
$prStmt->execute(['pid' => $portfolioId]);
$projects = $prStmt->fetchAll();

$expStmt = $pdo->prepare("SELECT * FROM portfolio_experiences WHERE portfolio_id = :pid ORDER BY id DESC");
$expStmt->execute(['pid' => $portfolioId]);
$experiences = $expStmt->fetchAll();

$certStmt = $pdo->prepare("SELECT * FROM portfolio_certifications WHERE portfolio_id = :pid ORDER BY id DESC");
$certStmt->execute(['pid' => $portfolioId]);
$certifications = $certStmt->fetchAll();

$achStmt = $pdo->prepare("SELECT * FROM portfolio_achievements WHERE portfolio_id = :pid ORDER BY id DESC");
$achStmt->execute(['pid' => $portfolioId]);
$achievements = $achStmt->fetchAll();

// Calculate Completeness Score
$score = 0;
if (!empty($portfolio['headline']) && strlen($portfolio['about_me'] ?? '') > 30) $score += 20;
if (count($education) > 0) $score += 15;
if (count($skills) >= 3) $score += 20;
if (count($projects) > 0) $score += 20;
if (count($experiences) > 0) $score += 15;
if (count($certifications) > 0 || count($achievements) > 0) $score += 10;
$completeness = min(100, $score);

// Public URL calculation
$baseUrl = defined('APP_URL') ? APP_URL : 'http://127.0.0.1:8000';
$publicUrl = "{$baseUrl}/#public-portfolio?slug=" . urlencode($portfolio['slug']);

sendJson([
    'success' => true,
    'student' => [
        'id' => (int)$student['id'],
        'name' => $student['name'],
        'email' => $student['email'],
        'roll_no' => $student['roll_no'],
        'branch' => $student['branch'],
        'cgpa' => (float)$student['cgpa'],
        'avatar' => $student['avatar']
    ],
    'portfolio' => [
        'id' => $portfolioId,
        'student_id' => $studentId,
        'slug' => $portfolio['slug'],
        'headline' => $portfolio['headline'],
        'about_me' => $portfolio['about_me'],
        'location' => $portfolio['location'],
        'phone' => $portfolio['phone'],
        'email' => $portfolio['email'],
        'github_url' => $portfolio['github_url'],
        'linkedin_url' => $portfolio['linkedin_url'],
        'website_url' => $portfolio['website_url'],
        'profile_photo' => $portfolio['profile_photo'],
        'template' => $portfolio['template'] ?: 'modern',
        'primary_color' => $portfolio['primary_color'] ?: '#4f46e5',
        'is_published' => (int)$portfolio['is_published'] === 1,
        'views_count' => (int)$portfolio['views_count'],
        'completeness_percentage' => $completeness,
        'public_url' => $publicUrl,
        'education' => $education,
        'skills' => $skills,
        'projects' => $projects,
        'experiences' => $experiences,
        'certifications' => $certifications,
        'achievements' => $achievements
    ]
]);
