<?php
/**
 * Migration Script: Execute Portfolio & ATS Tables Creation & Seed Demo Data
 */

require_once __DIR__ . '/../config/database.php';

try {
    $pdo = Database::getConnection();
    echo "[INFO] Running migration database/portfolio_ats_schema.sql..." . PHP_EOL;

    $sql = file_get_contents(__DIR__ . '/portfolio_ats_schema.sql');
    
    // Execute multiple statements
    $pdo->setAttribute(PDO::MYSQL_ATTR_MULTI_STATEMENTS, true);
    $pdo->exec($sql);
    echo "[SUCCESS] Tables created successfully!" . PHP_EOL;

    // Seed Sample Portfolio for Student 1 (Rohan Kulkarni)
    $sStmt = $pdo->query("SELECT s.id, u.name, u.email, s.branch, s.cgpa, s.roll_no, s.phone, s.skills FROM students s JOIN users u ON s.user_id = u.id WHERE s.id = 1 LIMIT 1");
    $student = $sStmt->fetch();

    if ($student) {
        $pCheck = $pdo->prepare("SELECT id FROM student_portfolios WHERE student_id = :sid");
        $pCheck->execute(['sid' => $student['id']]);
        $existingPort = $pCheck->fetch();

        if (!$existingPort) {
            echo "[INFO] Seeding initial portfolio for {$student['name']}..." . PHP_EOL;
            $slug = 'rohan-kulkarni-4821';
            $insPort = $pdo->prepare("
                INSERT INTO student_portfolios (student_id, slug, headline, about_me, location, phone, email, github_url, linkedin_url, website_url, template, primary_color, is_published, views_count)
                VALUES (:sid, :slug, :headline, :about, :loc, :phone, :email, :gh, :li, :web, 'modern', '#4f46e5', 1, 14)
            ");
            $insPort->execute([
                'sid' => $student['id'],
                'slug' => $slug,
                'headline' => 'Full-Stack Software Engineer | Cloud & Distributed Systems Enthusiast',
                'about' => 'Final year Computer Engineering undergraduate at Sanjivani University, Kopargaon. Passionate about architecting scalable microservices, high-throughput cloud infrastructure, and modern web applications. Solved 450+ LeetCode problems.',
                'loc' => 'Kopargaon / Pune, Maharashtra',
                'phone' => '+91 98220 11221',
                'email' => $student['email'],
                'gh' => 'https://github.com/rohan-sanjivani',
                'li' => 'https://linkedin.com/in/rohan-kulkarni-eng',
                'web' => 'https://rohankulkarni.tech'
            ]);
            $portId = (int)$pdo->lastInsertId();

            // Education
            $insEdu = $pdo->prepare("INSERT INTO portfolio_education (portfolio_id, degree, institution, field_of_study, start_year, end_year, grade_cgpa, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $insEdu->execute([$portId, 'B.Tech in Computer Engineering', 'Sanjivani University, Kopargaon', 'Computer Science & Engineering', 2022, 2026, '8.90 CGPA', 'Specializing in Distributed Computing, Operating Systems, Advanced Database Design, and Cloud Architecture. Member of CodeChef Chapter.']);
            $insEdu->execute([$portId, 'Higher Secondary Certificate (HSC)', 'Sanjivani Junior College, Kopargaon', 'Science (PCM & Electronics)', 2020, 2022, '94.20%', 'Completed 12th Board examinations with distinction in Mathematics and Computer Science.']);

            // Skills
            $insSkill = $pdo->prepare("INSERT INTO portfolio_skills (portfolio_id, skill_name, skill_type, proficiency_level) VALUES (?, ?, ?, ?)");
            $skillsList = [
                ['Java', 'technical', 'expert'],
                ['Spring Boot', 'technical', 'advanced'],
                ['MySQL / PostgreSQL', 'technical', 'advanced'],
                ['JavaScript ES6 / React', 'technical', 'advanced'],
                ['AngularJS', 'technical', 'advanced'],
                ['Docker & Kubernetes', 'technical', 'intermediate'],
                ['Data Structures & Algorithms', 'technical', 'expert'],
                ['RESTful API Design', 'technical', 'advanced'],
                ['Problem Solving', 'soft', 'expert'],
                ['Team Leadership', 'soft', 'advanced'],
                ['Effective Technical Communication', 'soft', 'advanced'],
                ['Agile Scrum Methodologies', 'soft', 'intermediate']
            ];
            foreach ($skillsList as $sk) {
                $insSkill->execute([$portId, $sk[0], $sk[1], $sk[2]]);
            }

            // Projects
            $insProj = $pdo->prepare("INSERT INTO portfolio_projects (portfolio_id, title, description, tech_stack, live_url, github_url, featured) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $insProj->execute([
                $portId,
                'AgriSmart: Real-time Agricultural IoT & Telemetry Platform',
                'Designed and developed an end-to-end IoT sensor platform monitoring soil moisture, micro-climate humidity, and automated drip irrigation for farmers in Kopargaon region. Handled 5,000+ telemetry events per second using Redis and Node.js.',
                'Node.js, Express, Redis, MQTT, React, MySQL, Chart.js',
                'https://agrismart.demo.sanjivani.edu.in',
                'https://github.com/rohan-sanjivani/agrismart-iot',
                1
            ]);
            $insProj->execute([
                $portId,
                'High-Throughput Distributed Cache Server in Java',
                'Implemented an in-memory distributed key-value cache engine from scratch supporting LRU eviction, TCP socket connection pooling, and multi-threaded write locking with 99.9% sub-millisecond latency.',
                'Java 17, Concurrency API, Netty, TCP Sockets, JUnit 5',
                'https://github.com/rohan-sanjivani/distributed-cache',
                'https://github.com/rohan-sanjivani/distributed-cache',
                1
            ]);
            $insProj->execute([
                $portId,
                'Automated Placement Portal & Drive Tracker',
                'Built responsive placement management system with real-time academic eligibility evaluation, candidate pipeline stages, and multi-format accreditation reports.',
                'PHP 8, AngularJS, MySQL, Bootstrap 5, Chart.js',
                'https://placement.sanjivani.edu.in',
                'https://github.com/rohan-sanjivani/placement-portal',
                0
            ]);

            // Experiences
            $insExp = $pdo->prepare("INSERT INTO portfolio_experiences (portfolio_id, type, title, company, location, start_date, end_date, is_current, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $insExp->execute([
                $portId,
                'internship',
                'Software Engineering Intern',
                'Godavari Infotech Solutions',
                'Kopargaon / Pune, Maharashtra',
                'June 2025',
                'August 2025',
                0,
                'Refactored enterprise Java Spring microservices, reduced API query response times by 38% through MySQL indexing, and authored comprehensive unit test suites with 92% code coverage.'
            ]);
            $insExp->execute([
                $portId,
                'internship',
                'Full Stack Developer Intern',
                'Sanjivani Tech Incubator',
                'Kopargaon Campus',
                'January 2025',
                'May 2025',
                0,
                'Created responsive departmental administrative portals and built RESTful endpoints integrating student fee management and automated grade card generation.'
            ]);

            // Certifications
            $insCert = $pdo->prepare("INSERT INTO portfolio_certifications (portfolio_id, title, issuing_org, issue_date, credential_url) VALUES (?, ?, ?, ?, ?)");
            $insCert->execute([$portId, 'AWS Certified Solutions Architect – Associate', 'Amazon Web Services', 'July 2025', 'https://aws.amazon.com/verification/123456']);
            $insCert->execute([$portId, 'Oracle Certified Professional: Java SE 17 Developer', 'Oracle Corporation', 'March 2025', 'https://oracle.com/cert/789101']);
            $insCert->execute([$portId, 'Meta Front-End Developer Professional Certificate', 'Coursera / Meta', 'November 2024', 'https://coursera.org/verify/meta-frontend']);

            // Achievements
            $insAch = $pdo->prepare("INSERT INTO portfolio_achievements (portfolio_id, title, description, date_awarded) VALUES (?, ?, ?, ?)");
            $insAch->execute([$portId, 'First Prize - Smart India Hackathon (College Level)', 'Led team of 6 engineers to build an AI soil prediction prototype.', 'October 2025']);
            $insAch->execute([$portId, 'Academic Excellence Award - Sanjivani University', 'Ranked in the top 3% of the Computer Engineering department with 8.90 CGPA.', 'August 2025']);

            echo "[SUCCESS] Demo portfolio populated for Rohan Kulkarni!" . PHP_EOL;
        }

        // Check if sample resume exists in resumes table
        $rCheck = $pdo->prepare("SELECT id FROM resumes WHERE student_id = :sid");
        $rCheck->execute(['sid' => $student['id']]);
        if (!$rCheck->fetch()) {
            echo "[INFO] Registering sample resume for ATS testing..." . PHP_EOL;
            $insRes = $pdo->prepare("
                INSERT INTO resumes (student_id, original_filename, stored_filename, file_path, file_type, file_size, extracted_text)
                VALUES (:sid, :orig, :stored, :path, 'pdf', :size, :text)
            ");
            $sampleText = "ROHAN KULKARNI
Email: rohan.kulkarni@sanjivani.edu.in | Phone: +91 98220 11221 | Location: Kopargaon, Maharashtra
LinkedIn: linkedin.com/in/rohan-kulkarni-eng | GitHub: github.com/rohan-sanjivani

PROFESSIONAL SUMMARY
Highly motivated Computer Engineering final year undergraduate at Sanjivani University with an 8.90 CGPA. Demonstrates deep proficiency in Java, Spring Boot, MySQL, RESTful API architecture, and microservices. Proven track record in solving 450+ algorithmic challenges and delivering scalable web applications. Eager to contribute as a Software Development Engineer.

EDUCATION
Sanjivani University, Kopargaon, Maharashtra
Bachelor of Technology in Computer Engineering (2022 - 2026)
Current CGPA: 8.90 / 10.00
Relevant Coursework: Data Structures & Algorithms, Object-Oriented Programming, Database Management Systems, Operating Systems, Computer Networks, Cloud Computing.

TECHNICAL SKILLS
- Languages: Java 17, Python, JavaScript (ES6+), SQL, C++
- Frameworks & Libraries: Spring Boot, Hibernate, React, AngularJS, Express.js
- Databases: MySQL, PostgreSQL, Redis, MongoDB
- Tools & Cloud: Git, Docker, Kubernetes, AWS (EC2, S3, RDS), Linux, Postman, Maven

WORK & INTERNSHIP EXPERIENCE
Software Engineering Intern | Godavari Infotech Solutions, Pune / Kopargaon (June 2025 - August 2025)
- Architected and deployed 8 RESTful microservice endpoints in Java Spring Boot supporting 10,000+ daily requests.
- Optimized slow SQL queries through composite indexing, reducing database latency by 38%.
- Integrated automated JUnit and Mockito test suites, achieving 92% code coverage across core business logic.

Full Stack Developer Intern | Sanjivani Tech Incubator, Kopargaon (January 2025 - May 2025)
- Developed responsive web portals using PHP 8, MySQL, and Bootstrap 5 for university administration.
- Implemented secure JWT and session-based authentication guarding sensitive student academic records.

PROJECTS
AgriSmart: Real-time Agricultural IoT & Telemetry Platform
- Engineered distributed telemetry processing system handling 5,000 sensor messages per second using Redis and MQTT.
- Built interactive frontend visualization dashboards using React and Chart.js for real-time soil moisture monitoring.
- Technologies: Node.js, Express, Redis, React, MySQL, MQTT, Docker.

Distributed In-Memory Cache Engine in Java
- Designed high-performance key-value caching system supporting LRU eviction policies and multi-threaded locks.
- Benchmarked sub-millisecond retrieval latency with 99.9% uptime in multi-threaded concurrency stress tests.
- Technologies: Java 17, Concurrency API, Netty, TCP Sockets, Maven.

CERTIFICATIONS
- AWS Certified Solutions Architect - Associate (Amazon Web Services, 2025)
- Oracle Certified Professional: Java SE 17 Developer (Oracle Corporation, 2025)";

            $insRes->execute([
                'sid' => $student['id'],
                'orig' => 'Rohan_Kulkarni_Resume.pdf',
                'stored' => 'sample_resume_rahul.pdf',
                'path' => 'uploads/resumes/sample_resume_rahul.pdf',
                'size' => 45200,
                'text' => $sampleText
            ]);
            $resId = (int)$pdo->lastInsertId();

            // Insert Initial ATS Analysis
            $secScores = json_encode([
                'contact' => ['score' => 10, 'max' => 10, 'label' => 'Contact Information'],
                'summary' => ['score' => 9, 'max' => 10, 'label' => 'Professional Summary'],
                'education' => ['score' => 15, 'max' => 15, 'label' => 'Education & Academics'],
                'skills' => ['score' => 23, 'max' => 25, 'label' => 'Technical & Soft Skills'],
                'experience' => ['score' => 18, 'max' => 20, 'label' => 'Experience & Projects'],
                'formatting' => ['score' => 18, 'max' => 20, 'label' => 'Formatting & Structure']
            ]);
            $extData = json_encode([
                'email' => 'rohan.kulkarni@sanjivani.edu.in',
                'phone' => '+91 98220 11221',
                'linkedin' => 'linkedin.com/in/rohan-kulkarni-eng',
                'github' => 'github.com/rohan-sanjivani',
                'detected_skills' => ['Java', 'Spring Boot', 'Python', 'SQL', 'MySQL', 'PostgreSQL', 'Redis', 'Docker', 'Kubernetes', 'AWS', 'React', 'AngularJS', 'Git', 'Linux'],
                'word_count' => 380,
                'action_verbs_count' => 14
            ]);
            $strengths = json_encode([
                'Complete contact information including verified institutional email, phone, LinkedIn, and GitHub links.',
                'Clear quantifiable accomplishments with numerical impact (e.g. 38% latency reduction, 10,000+ daily requests, 92% coverage).',
                'Strong density of high-impact action verbs (Architected, Engineered, Optimized, Deployed, Benchmarked).',
                'Standard chronological layout with recognizable ATS section headers.'
            ]);
            $weaknesses = json_encode([
                'Soft skills section could explicitly highlight collaborative cross-functional teamwork and agile methodologies.',
                'Ensure all project descriptions follow the Google XYZ formula (Accomplished X, as measured by Y, by doing Z).'
            ]);
            $suggestions = json_encode([
                'Consider adding a dedicated Soft Skills subsection mentioning Agile, Team Collaboration, and Code Reviews.',
                'Mention specific AWS services used in the certification title or project bullets (e.g. AWS Lambda, S3, ECS).',
                'Keep total resume length strictly within 1 page for undergraduate campus drives.'
            ]);
            $formatting = json_encode([
                'Word count: 380 words (ideal for single-page student resume: 350-500 words).',
                'Section headers clearly identifiable by standard ATS scanners.',
                'No complex tables, multi-column text boxes, or embedded graphics detected.'
            ]);

            $insAts = $pdo->prepare("
                INSERT INTO ats_analyses (student_id, resume_id, overall_score, section_scores, extracted_data, strengths, weaknesses, suggestions, formatting_feedback)
                VALUES (?, ?, 93, ?, ?, ?, ?, ?, ?)
            ");
            $insAts->execute([$student['id'], $resId, $secScores, $extData, $strengths, $weaknesses, $suggestions, $formatting]);
            echo "[SUCCESS] Sample ATS analysis seeded with 93% compatibility score!" . PHP_EOL;
        }
    }

    echo "=== Portfolio & ATS Migration Completed Successfully! ===" . PHP_EOL;
} catch (Exception $e) {
    echo "[ERROR] Migration failed: " . $e->getMessage() . PHP_EOL;
    exit(1);
}
