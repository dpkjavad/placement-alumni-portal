<?php
/**
 * Authentication, Authorization (RBAC), Security & Utility Helpers
 * SU T&P (Sanjivani Placement & Alumni Portal)
 */

require_once __DIR__ . '/database.php';

function sendJson($data, int $statusCode = 200): void {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function sendError(string $message, int $statusCode = 400, array $errors = []): void {
    $response = [
        'success' => false,
        'message' => $message
    ];
    if (!empty($errors)) {
        $response['errors'] = $errors;
    }
    sendJson($response, $statusCode);
}

function getRequestData(): array {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (stripos($contentType, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        $json = json_decode($raw, true);
        return is_array($json) ? $json : [];
    }
    return $_POST;
}

function getCurrentUser(): ?array {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }

    $pdo = Database::getConnection();
    $stmt = $pdo->prepare("SELECT id, name, email, role, avatar, is_active FROM users WHERE id = :id LIMIT 1");
    $stmt->execute(['id' => $_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user || (int)$user['is_active'] !== 1) {
        unset($_SESSION['user_id'], $_SESSION['user_role']);
        return null;
    }

    // Attach role-specific IDs and profiles
    if ($user['role'] === 'student') {
        $stStmt = $pdo->prepare("SELECT * FROM students WHERE user_id = :uid LIMIT 1");
        $stStmt->execute(['uid' => $user['id']]);
        $user['student_profile'] = $stStmt->fetch() ?: null;
    } elseif ($user['role'] === 'alumni') {
        $alStmt = $pdo->prepare("SELECT * FROM alumni WHERE user_id = :uid LIMIT 1");
        $alStmt->execute(['uid' => $user['id']]);
        $user['alumni_profile'] = $alStmt->fetch() ?: null;
    }

    return $user;
}

function requireLogin(): array {
    $user = getCurrentUser();
    if (!$user) {
        sendError('Unauthorized. Please log in.', 401);
    }
    return $user;
}

function requireRole($roles): array {
    $user = requireLogin();
    $allowed = is_array($roles) ? $roles : [$roles];
    if (!in_array($user['role'], $allowed, true)) {
        sendError('Forbidden. Insufficient permissions for role: ' . $user['role'], 403);
    }
    return $user;
}

function sanitizeString(?string $str): string {
    if ($str === null) return '';
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

/**
 * Automatically calculate dynamic experience in years & months from joining date
 * e.g., '2021-07-15' -> '5 yrs, 4 mos'
 */
function calculateDynamicExperience(?string $joiningDate): string {
    if (empty($joiningDate) || $joiningDate === '0000-00-00') {
        return 'Experience not specified';
    }
    try {
        $start = new DateTime($joiningDate);
        $now = new DateTime();
        if ($start > $now) {
            return 'Joining soon';
        }
        $diff = $start->diff($now);
        $years = $diff->y;
        $months = $diff->m;
        
        $parts = [];
        if ($years > 0) {
            $parts[] = $years . ' ' . ($years === 1 ? 'yr' : 'yrs');
        }
        if ($months > 0 || empty($parts)) {
            $parts[] = $months . ' ' . ($months === 1 ? 'mo' : 'mos');
        }
        return implode(', ', $parts) . ' experience';
    } catch (Exception $e) {
        return 'Experience not specified';
    }
}

/**
 * Enterprise Audit Logging
 */
function logAudit(string $action, string $details = '', ?int $userId = null, ?string $userEmail = null): void {
    try {
        $pdo = Database::getConnection();
        if ($userId === null && isset($_SESSION['user_id'])) {
            $userId = (int)$_SESSION['user_id'];
        }
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, user_email, action, details, ip_address) VALUES (:uid, :email, :action, :details, :ip)");
        $stmt->execute([
            'uid' => $userId,
            'email' => $userEmail,
            'action' => $action,
            'details' => $details,
            'ip' => $ip
        ]);
    } catch (Exception $e) {
        // Non-blocking for audit failure
    }
}

/**
 * Personalized User Notification Dispatcher
 */
function createNotification(int $userId, string $title, string $message, string $type = 'system', ?int $refId = null): void {
    try {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type, reference_id, is_read) VALUES (:uid, :title, :msg, :type, :ref, 0)");
        $stmt->execute([
            'uid' => $userId,
            'title' => $title,
            'msg' => $message,
            'type' => $type,
            'ref' => $refId
        ]);
    } catch (Exception $e) {
        // Non-blocking
    }
}

/**
 * Simple session/IP rate limiter for security-sensitive endpoints (login, register)
 */
function checkRateLimit(string $actionKey, int $maxAttempts = 15, int $decaySeconds = 60): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'local';
    $sessionKey = 'rate_' . md5($actionKey . '_' . $ip);
    $now = time();

    if (!isset($_SESSION[$sessionKey])) {
        $_SESSION[$sessionKey] = ['count' => 1, 'start_time' => $now];
        return;
    }

    $record = $_SESSION[$sessionKey];
    if ($now - $record['start_time'] > $decaySeconds) {
        $_SESSION[$sessionKey] = ['count' => 1, 'start_time' => $now];
        return;
    }

    if ($record['count'] >= $maxAttempts) {
        sendError('Too many attempts. Please wait 60 seconds before trying again.', 429);
    }

    $_SESSION[$sessionKey]['count']++;
}
