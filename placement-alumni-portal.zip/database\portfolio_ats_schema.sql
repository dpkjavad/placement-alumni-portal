-- ==========================================================
-- Database Migration: Portfolio Builder & ATS Resume Checker
-- Database: placement_alumni_portal
-- ==========================================================

USE `placement_alumni_portal`;

-- 1. Student Portfolios Master Table
CREATE TABLE IF NOT EXISTS `student_portfolios` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `student_id` INT NOT NULL UNIQUE,
    `slug` VARCHAR(100) NOT NULL UNIQUE,
    `headline` VARCHAR(150) DEFAULT 'Aspiring Software Engineer & Tech Innovator',
    `about_me` TEXT DEFAULT NULL,
    `location` VARCHAR(120) DEFAULT 'Kopargaon, Maharashtra',
    `phone` VARCHAR(25) DEFAULT NULL,
    `email` VARCHAR(120) DEFAULT NULL,
    `github_url` VARCHAR(255) DEFAULT NULL,
    `linkedin_url` VARCHAR(255) DEFAULT NULL,
    `website_url` VARCHAR(255) DEFAULT NULL,
    `profile_photo` VARCHAR(255) DEFAULT NULL,
    `template` ENUM('modern', 'tech_dark', 'minimal', 'executive') DEFAULT 'modern',
    `primary_color` VARCHAR(30) DEFAULT '#4f46e5',
    `is_published` TINYINT(1) DEFAULT 1,
    `views_count` INT DEFAULT 0,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_portfolio_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Portfolio Education
CREATE TABLE IF NOT EXISTS `portfolio_education` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `portfolio_id` INT NOT NULL,
    `degree` VARCHAR(120) NOT NULL,
    `institution` VARCHAR(150) NOT NULL,
    `field_of_study` VARCHAR(120) DEFAULT NULL,
    `start_year` INT NOT NULL,
    `end_year` INT DEFAULT NULL,
    `grade_cgpa` VARCHAR(20) DEFAULT NULL,
    `description` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_edu_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `student_portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Portfolio Skills
CREATE TABLE IF NOT EXISTS `portfolio_skills` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `portfolio_id` INT NOT NULL,
    `skill_name` VARCHAR(80) NOT NULL,
    `skill_type` ENUM('technical', 'soft') DEFAULT 'technical',
    `proficiency_level` ENUM('beginner', 'intermediate', 'advanced', 'expert') DEFAULT 'advanced',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_skill_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `student_portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Portfolio Projects
CREATE TABLE IF NOT EXISTS `portfolio_projects` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `portfolio_id` INT NOT NULL,
    `title` VARCHAR(150) NOT NULL,
    `description` TEXT NOT NULL,
    `tech_stack` VARCHAR(255) NOT NULL,
    `live_url` VARCHAR(255) DEFAULT NULL,
    `github_url` VARCHAR(255) DEFAULT NULL,
    `featured` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_proj_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `student_portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Portfolio Experiences (Internships & Work Experience)
CREATE TABLE IF NOT EXISTS `portfolio_experiences` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `portfolio_id` INT NOT NULL,
    `type` ENUM('job', 'internship') DEFAULT 'internship',
    `title` VARCHAR(120) NOT NULL,
    `company` VARCHAR(150) NOT NULL,
    `location` VARCHAR(120) DEFAULT 'Remote / On-site',
    `start_date` VARCHAR(50) NOT NULL,
    `end_date` VARCHAR(50) DEFAULT 'Present',
    `is_current` TINYINT(1) DEFAULT 0,
    `description` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_exp_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `student_portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Portfolio Certifications
CREATE TABLE IF NOT EXISTS `portfolio_certifications` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `portfolio_id` INT NOT NULL,
    `title` VARCHAR(150) NOT NULL,
    `issuing_org` VARCHAR(150) NOT NULL,
    `issue_date` VARCHAR(50) DEFAULT NULL,
    `credential_url` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_cert_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `student_portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Portfolio Achievements & Awards
CREATE TABLE IF NOT EXISTS `portfolio_achievements` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `portfolio_id` INT NOT NULL,
    `title` VARCHAR(150) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `date_awarded` VARCHAR(50) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_achieve_portfolio` FOREIGN KEY (`portfolio_id`) REFERENCES `student_portfolios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Resumes Table (For ATS Scanner and storage)
CREATE TABLE IF NOT EXISTS `resumes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `student_id` INT NOT NULL,
    `original_filename` VARCHAR(255) NOT NULL,
    `stored_filename` VARCHAR(255) NOT NULL,
    `file_path` VARCHAR(255) NOT NULL,
    `file_type` ENUM('pdf', 'docx') NOT NULL,
    `file_size` INT NOT NULL,
    `extracted_text` LONGTEXT DEFAULT NULL,
    `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_res_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. ATS Analyses Table (Audit history & scored reports)
CREATE TABLE IF NOT EXISTS `ats_analyses` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `student_id` INT NOT NULL,
    `resume_id` INT NOT NULL,
    `overall_score` INT NOT NULL,
    `section_scores` LONGTEXT NOT NULL COMMENT 'JSON encoded breakdown',
    `extracted_data` LONGTEXT NOT NULL COMMENT 'JSON detected contact, skills, etc.',
    `strengths` LONGTEXT DEFAULT NULL COMMENT 'JSON array',
    `weaknesses` LONGTEXT DEFAULT NULL COMMENT 'JSON array',
    `suggestions` LONGTEXT DEFAULT NULL COMMENT 'JSON array',
    `formatting_feedback` LONGTEXT DEFAULT NULL COMMENT 'JSON array',
    `analyzed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_ats_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_ats_resume` FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Job Description Comparisons Table
CREATE TABLE IF NOT EXISTS `job_comparisons` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `student_id` INT NOT NULL,
    `resume_id` INT NOT NULL,
    `ats_analysis_id` INT DEFAULT NULL,
    `job_title` VARCHAR(150) DEFAULT NULL,
    `job_company` VARCHAR(150) DEFAULT NULL,
    `job_description` LONGTEXT NOT NULL,
    `match_percentage` INT NOT NULL,
    `matching_skills` LONGTEXT DEFAULT NULL COMMENT 'JSON array',
    `missing_skills` LONGTEXT DEFAULT NULL COMMENT 'JSON array',
    `matching_keywords` LONGTEXT DEFAULT NULL COMMENT 'JSON array',
    `missing_keywords` LONGTEXT DEFAULT NULL COMMENT 'JSON array',
    `suggestions` LONGTEXT DEFAULT NULL COMMENT 'JSON array',
    `compared_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_jc_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_jc_resume` FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexing for fast lookups
CREATE INDEX IF NOT EXISTS idx_port_slug ON `student_portfolios`(`slug`);
CREATE INDEX IF NOT EXISTS idx_res_student ON `resumes`(`student_id`);
CREATE INDEX IF NOT EXISTS idx_ats_student ON `ats_analyses`(`student_id`);
CREATE INDEX IF NOT EXISTS idx_jc_student ON `job_comparisons`(`student_id`);
