<?php
/**
 * API: Interview Preparation Hub
 * Implements Phase 11: Feature 6 (Interview Preparation Hub)
 */

require_once __DIR__ . '/../../config/auth.php';

$pdo = Database::getConnection();

$category = trim($_GET['category'] ?? '');
$company = trim($_GET['company'] ?? '');
$search = trim($_GET['search'] ?? '');

$sql = "SELECT * FROM interview_prep_materials WHERE 1=1";
$params = [];

if (!empty($category) && strcasecmp($category, 'all') !== 0) {
    $sql .= " AND category = :cat";
    $params['cat'] = $category;
}
if (!empty($company)) {
    $sql .= " AND (company_tag LIKE :comp OR title LIKE :comp)";
    $params['comp'] = "%{$company}%";
}
if (!empty($search)) {
    $sql .= " AND (title LIKE :s OR question LIKE :s OR answer_guide LIKE :s)";
    $params['s'] = "%{$search}%";
}

$sql .= " ORDER BY category ASC, id ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$materials = $stmt->fetchAll();

// Get category counts
$countsStmt = $pdo->query("SELECT category, COUNT(*) AS count FROM interview_prep_materials GROUP BY category");
$categoryCounts = [];
while ($row = $countsStmt->fetch()) {
    $categoryCounts[$row['category']] = (int)$row['count'];
}

sendJson([
    'success' => true,
    'data' => $materials,
    'category_counts' => $categoryCounts,
    'total' => count($materials)
]);
