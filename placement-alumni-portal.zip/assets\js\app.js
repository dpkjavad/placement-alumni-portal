/**
 * SU T&P (Sanjivani Placement & Alumni Portal)
 * Enterprise Production Application Controller
 * AngularJS 1.8 + ES6 Architecture
 */

const portalApp = angular.module('placementPortalApp', []);

portalApp.controller('PortalCtrl', ['$scope', '$http', '$timeout', '$window', function($scope, $http, $timeout, $window) {
  // Official Institutional Contact
  $scope.officialContact = '8668680085';

  // Global State
  $scope.currentUser = null;
  $scope.activeView = 'home';
  $scope.kpis = {};
  $scope.chartsData = {};

  // Data Collections
  $scope.drives = [];
  $scope.alumni = [];
  $scope.companies = [];
  $scope.applications = [];
  $scope.studentApplications = [];
  $scope.placements = [];
  $scope.adminUsers = [];
  $scope.studentProfile = {};
  $scope.alumniProfile = {};

  // Notifications State
  $scope.notifications = [];
  $scope.unreadNotificationsCount = 0;

  // Student-Alumni Direct Chat State
  $scope.chatRequests = [];
  $scope.activeChatThread = null;
  $scope.chatMessages = [];
  $scope.newChatMessage = '';
  $scope.chatRequestModalData = { alumni_id: 0, alumni_name: '', message: '' };

  // Interview Scheduling State
  $scope.studentInterviews = [];
  $scope.allScheduledInterviews = [];
  $scope.interviewForm = {
    id: 0,
    student_id: '',
    drive_id: '',
    application_id: '',
    company_name: '',
    job_designation: '',
    interview_date: '',
    interview_time: '',
    interview_mode: 'Online',
    location_or_link: '',
    instructions: ''
  };

  // Resume Versioning State
  $scope.resumeHistory = [];
  $scope.resumeUploading = false;

  // Smart Matching & Readiness State
  $scope.smartMatches = [];
  $scope.selectedMatch = null;
  $scope.readinessData = { overall_score: 0, tier: 'Needs Preparation', badge_color: 'danger', breakdown: {} };

  // Interview Prep Hub State
  $scope.prepMaterials = [];
  $scope.prepCategories = {};
  $scope.prepFilter = { category: 'all', search: '', company: '' };

  // Alumni Referral System State
  $scope.alumniReferrals = [];
  $scope.newReferralForm = { company_name: '', job_title: '', job_url: '', requirements: '', location: 'Pune / Kopargaon', deadline: '' };

  // Admin & Announcements State
  $scope.adminKPIs = {};
  $scope.auditLogs = [];
  $scope.announcements = [];
  $scope.announcementForm = { title: '', content: '', target_role: 'all' };

  // Portfolio Builder State
  $scope.portfolio = {
    headline: '',
    about_me: '',
    location: '',
    phone: '',
    email: '',
    github_url: '',
    linkedin_url: '',
    website_url: '',
    template: 'modern',
    primary_color: '#4f46e5',
    is_published: true,
    views_count: 0,
    completeness_percentage: 0,
    education: [],
    skills: [],
    projects: [],
    experiences: [],
    certifications: [],
    achievements: []
  };
  $scope.activePortfolioTab = 'profile';
  $scope.publicPortfolio = null;
  $scope.newSkill = { name: '', type: 'technical', level: 'advanced' };

  // ATS Resume Checker State
  $scope.atsResumes = [];
  $scope.atsActiveResume = null;
  $scope.atsAnalysis = null;
  $scope.atsRecentComparisons = [];
  $scope.atsJD = { job_title: '', job_company: '', job_description: '' };
  $scope.atsMatchResult = null;
  $scope.atsUploading = false;
  $scope.atsMatching = false;

  // Filters & Search
  $scope.driveFilter = { search: '', branch: '', status: 'active' };
  $scope.alumniFilter = { search: '', branch: '', year: '', mentorshipOnly: false };
  $scope.appFilterStatus = '';

  // Forms State
  $scope.loginData = { email: '', password: '', role: '' };
  $scope.regData = { role: 'student', name: '', email: '', password: '', branch: 'Computer Engineering', year: 4, cgpa: '', phone: '', roll_no: '', graduation_year: 2022, company: '', job_role: '', linkedin: '' };
  $scope.activeDrive = {};
  $scope.driveForm = { id: 0, company_id: '', job_role: '', package: '', location: '', drive_date: '', deadline: '', min_cgpa: 7.0, eligible_branches: 'Computer Engineering, Information Technology, Electronics & Telecommunication', skills: '', vacancies: 10, status: 'active' };
  $scope.statusModalData = { application_id: 0, status: 'Applied', notes: '' };

  // =========================================================================
  // TOAST NOTIFICATION SYSTEM
  // =========================================================================
  $scope.showToast = function(message, type = 'info') {
    const toastEl = document.getElementById('portalToast');
    const toastBody = document.getElementById('toastBody');
    const toastIcon = document.getElementById('toastIcon');

    if (!toastEl || !toastBody) {
      alert(message);
      return;
    }

    const iconMap = {
      success: 'bi-check-circle-fill text-success',
      danger: 'bi-x-circle-fill text-danger',
      warning: 'bi-exclamation-triangle-fill text-warning',
      info: 'bi-info-circle-fill text-primary'
    };

    if (toastIcon) {
      toastIcon.className = `bi ${iconMap[type] || iconMap.info} me-2 fs-5`;
    }
    toastBody.textContent = message;

    const bsToast = bootstrap.Toast.getOrCreateInstance(toastEl);
    bsToast.show();
  };

  // =========================================================================
  // NAVIGATION & ROUTING
  // =========================================================================
  $scope.navigate = function(viewName, updateHash = true) {
    if (!viewName) viewName = 'home';
    const baseView = viewName.split('?')[0];

    // Role-based route guard
    const studentViews = ['student-dashboard', 'student-applications', 'student-profile', 'student-portfolio', 'student-ats', 'student-chat', 'smart-matching', 'prep-hub', 'alumni-referrals'];
    const alumniViews = ['alumni-dashboard', 'alumni-profile', 'alumni-chat', 'alumni-referrals'];
    const officerViews = ['officer-dashboard', 'officer-drives', 'officer-applications', 'officer-placements', 'officer-interviews'];
    const adminViews = ['admin-dashboard', 'admin-students', 'admin-alumni', 'admin-companies', 'admin-users', 'admin-audit'];

    if (studentViews.includes(baseView) && (!$scope.currentUser || $scope.currentUser.role !== 'student')) {
      $scope.showToast('Please log in with a student account to access this section.', 'warning');
      $scope.activeView = 'login';
      if (updateHash) $window.location.hash = 'login';
      return;
    }

    if (alumniViews.includes(baseView) && (!$scope.currentUser || ($scope.currentUser.role !== 'alumni' && baseView !== 'alumni-referrals'))) {
      $scope.showToast('Alumni account required for this section.', 'warning');
      $scope.activeView = 'login';
      if (updateHash) $window.location.hash = 'login';
      return;
    }

    if (officerViews.includes(baseView) && (!$scope.currentUser || !['officer', 'admin'].includes($scope.currentUser.role))) {
      $scope.showToast('Placement Officer authorization required.', 'danger');
      $scope.activeView = 'login';
      if (updateHash) $window.location.hash = 'login';
      return;
    }

    if (adminViews.includes(baseView) && (!$scope.currentUser || $scope.currentUser.role !== 'admin')) {
      $scope.showToast('Administrator authorization required.', 'danger');
      $scope.activeView = 'login';
      if (updateHash) $window.location.hash = 'login';
      return;
    }

    $scope.activeView = baseView;
    if (updateHash) {
      $window.location.hash = viewName;
    }

    // Scroll to top
    $window.scrollTo(0, 0);

    // Auto-load view data
    $scope.handleViewLoad(viewName);
  };

  $scope.handleViewLoad = function(viewName) {
    const baseView = viewName.split('?')[0];
    switch (baseView) {
      case 'home':
        $scope.loadHomeData();
        $scope.loadAnnouncements();
        break;
      case 'drives':
        $scope.loadDrives();
        break;
      case 'alumni':
        $scope.loadAlumni();
        break;
      case 'statistics':
        $scope.loadStatistics();
        break;
      case 'student-dashboard':
        $scope.loadStudentDashboard();
        $scope.loadNotifications();
        $scope.loadStudentInterviews();
        $scope.loadReadinessScore();
        break;
      case 'student-applications':
        $scope.loadStudentApplications();
        break;
      case 'student-profile':
        $scope.loadStudentProfile();
        $scope.loadResumeHistory();
        break;
      case 'student-portfolio':
        $scope.loadStudentPortfolio();
        break;
      case 'student-ats':
        $scope.loadAtsHistory();
        break;
      case 'student-chat':
      case 'alumni-chat':
        $scope.loadChatRequests();
        break;
      case 'smart-matching':
        $scope.loadSmartMatches();
        break;
      case 'prep-hub':
        $scope.loadPrepMaterials();
        break;
      case 'alumni-referrals':
        $scope.loadAlumniReferrals();
        break;
      case 'public-portfolio':
        $scope.loadPublicPortfolioByHash(viewName);
        break;
      case 'alumni-dashboard':
        $scope.loadAlumniDashboard();
        $scope.loadNotifications();
        break;
      case 'alumni-profile':
        $scope.loadAlumniProfile();
        break;
      case 'officer-dashboard':
        $scope.loadOfficerDashboard();
        $scope.loadOfficerInterviews();
        break;
      case 'officer-drives':
        $scope.loadOfficerDrives();
        break;
      case 'officer-applications':
        $scope.loadOfficerApplications();
        break;
      case 'officer-placements':
        $scope.loadOfficerPlacements();
        break;
      case 'officer-interviews':
        $scope.loadOfficerInterviews();
        break;
      case 'admin-dashboard':
        $scope.loadAdminAnalytics();
        $scope.loadAnnouncements();
        break;
      case 'admin-students':
        $scope.loadAdminStudents();
        break;
      case 'admin-alumni':
        $scope.loadAdminAlumni();
        break;
      case 'admin-companies':
        $scope.loadAdminCompanies();
        break;
      case 'admin-users':
        $scope.loadAdminUsers();
        break;
      case 'admin-audit':
        $scope.loadAuditLogs();
        break;
    }
  };

  // =========================================================================
  // AUTHENTICATION & SESSION MANAGEMENT
  // =========================================================================
  $scope.checkAuth = function() {
    return $http.get('api/auth/me.php').then(function(res) {
      if (res.data && res.data.authenticated) {
        $scope.currentUser = res.data.user;
        $scope.loadNotifications();
      } else {
        $scope.currentUser = null;
      }
    });
  };

  $scope.login = function() {
    $http.post('api/auth/login.php', $scope.loginData).then(function(res) {
      if (res.data && res.data.success) {
        $scope.currentUser = res.data.user;
        $scope.showToast(`Welcome, ${$scope.currentUser.name}!`, 'success');
        $scope.loginData = { email: '', password: '', role: '' };

        if ($scope.currentUser.role === 'student') {
          $scope.navigate('student-dashboard');
        } else if ($scope.currentUser.role === 'alumni') {
          $scope.navigate('alumni-dashboard');
        } else if ($scope.currentUser.role === 'officer') {
          $scope.navigate('officer-dashboard');
        } else if ($scope.currentUser.role === 'admin') {
          $scope.navigate('admin-dashboard');
        } else {
          $scope.navigate('home');
        }
      } else {
        $scope.showToast(res.data.message || 'Login failed', 'danger');
      }
    }, function(err) {
      $scope.showToast(err.data?.message || 'Invalid email or password.', 'danger');
    });
  };

  $scope.logout = function() {
    $http.post('api/auth/logout.php', {}).then(function() {
      $scope.currentUser = null;
      $scope.notifications = [];
      $scope.unreadNotificationsCount = 0;
      $scope.showToast('You have been logged out securely.', 'info');
      $scope.navigate('home');
    });
  };

  $scope.register = function() {
    $http.post('api/auth/register.php', $scope.regData).then(function(res) {
      if (res.data && res.data.success) {
        $scope.currentUser = res.data.user;
        $scope.showToast('Registration successful! Welcome to SU T&P Portal.', 'success');
        if ($scope.currentUser.role === 'student') {
          $scope.navigate('student-dashboard');
        } else {
          $scope.navigate('alumni-dashboard');
        }
      } else {
        $scope.showToast(res.data.message || 'Registration failed.', 'danger');
      }
    }, function(err) {
      $scope.showToast(err.data?.message || 'Registration failed.', 'danger');
    });
  };

  // =========================================================================
  // NOTIFICATIONS CENTER (PHASE 9 & 11)
  // =========================================================================
  $scope.loadNotifications = function() {
    if (!$scope.currentUser) return;
    $http.get('api/notifications/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.notifications = res.data.data;
        $scope.unreadNotificationsCount = res.data.unread_count;
      }
    });
  };

  $scope.markNotificationRead = function(notif) {
    if (notif.is_read) return;
    $http.post('api/notifications/index.php', { id: notif.id }).then(function(res) {
      if (res.data && res.data.success) {
        notif.is_read = 1;
        $scope.unreadNotificationsCount = Math.max(0, $scope.unreadNotificationsCount - 1);
      }
    });
  };

  $scope.markAllNotificationsRead = function() {
    $http.post('api/notifications/index.php', { action: 'mark_all_read' }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.notifications.forEach(n => n.is_read = 1);
        $scope.unreadNotificationsCount = 0;
        $scope.showToast('All notifications marked as read.', 'success');
      }
    });
  };

  // =========================================================================
  // PUBLIC HOMEPAGE & ANNOUNCEMENTS
  // =========================================================================
  $scope.loadHomeData = function() {
    $http.get('api/statistics/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.kpis = res.data.kpis;
      }
    });
    $http.get('api/drives/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.latestDrives = res.data.data.slice(0, 3);
      }
    });
    $http.get('api/companies/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.companies = res.data.data;
      }
    });
  };

  $scope.loadAnnouncements = function() {
    $http.get('api/admin/announcements.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.announcements = res.data.data;
      }
    });
  };

  // =========================================================================
  // PLACEMENT DRIVES
  // =========================================================================
  $scope.loadDrives = function() {
    const params = {
      search: $scope.driveFilter.search || '',
      branch: $scope.driveFilter.branch || '',
      status: $scope.driveFilter.status || 'active'
    };
    $http.get('api/drives/index.php', { params: params }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.drives = res.data.data;
      }
    });
  };

  $scope.showDriveDetails = function(drive) {
    $scope.activeDrive = drive;
    const modal = new bootstrap.Modal(document.getElementById('driveDetailsModal'));
    modal.show();
  };

  $scope.openApplyModal = function(drive) {
    $scope.applyDriveTarget = drive;
    const modal = new bootstrap.Modal(document.getElementById('applyDriveModal'));
    modal.show();
  };

  $scope.submitApplication = function() {
    if (!$scope.applyDriveTarget) return;
    $http.post('api/applications/apply.php', { drive_id: $scope.applyDriveTarget.id }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Application submitted successfully!', 'success');
        bootstrap.Modal.getInstance(document.getElementById('applyDriveModal')).hide();
        $scope.loadDrives();
        if ($scope.activeView === 'student-dashboard') $scope.loadStudentDashboard();
      } else {
        $scope.showToast(res.data.message || 'Application failed.', 'danger');
      }
    }, function(err) {
      $scope.showToast(err.data?.message || 'Error submitting application.', 'danger');
    });
  };

  // =========================================================================
  // ALUMNI DIRECTORY & ENHANCEMENT (PHASE 3)
  // =========================================================================
  $scope.loadAlumni = function() {
    const params = {
      search: $scope.alumniFilter.search || '',
      branch: $scope.alumniFilter.branch || '',
      graduation_year: $scope.alumniFilter.year || '',
      mentorship_only: $scope.alumniFilter.mentorshipOnly
    };
    $http.get('api/alumni/index.php', { params: params }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.alumni = res.data.data;
      }
    });
  };

  // =========================================================================
  // STUDENT-ALUMNI DIRECT CHAT SYSTEM (PHASE 8)
  // =========================================================================
  $scope.openChatRequestModal = function(alum) {
    if (!$scope.currentUser) {
      $scope.showToast('Please log in as a student to connect with alumni.', 'warning');
      $scope.navigate('login');
      return;
    }
    if ($scope.currentUser.role !== 'student') {
      $scope.showToast('Only registered students can send chat requests.', 'warning');
      return;
    }
    $scope.chatRequestModalData = {
      alumni_id: alum.id,
      alumni_name: alum.name,
      message: `Hello ${alum.name}, I am a student at Sanjivani University seeking your guidance regarding career paths and technical placement preparation.`
    };
    const modal = new bootstrap.Modal(document.getElementById('chatRequestModal'));
    modal.show();
  };

  $scope.submitChatRequest = function() {
    $http.post('api/chat/requests.php', {
      alumni_id: $scope.chatRequestModalData.alumni_id,
      message: $scope.chatRequestModalData.message
    }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast(res.data.message, 'success');
        bootstrap.Modal.getInstance(document.getElementById('chatRequestModal')).hide();
        $scope.loadChatRequests();
      } else {
        $scope.showToast(res.data.message || 'Request failed.', 'danger');
      }
    }, function(err) {
      $scope.showToast(err.data?.message || 'Failed to send request.', 'danger');
    });
  };

  $scope.loadChatRequests = function() {
    $http.get('api/chat/requests.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.chatRequests = res.data.data;
        if ($scope.chatRequests.length > 0 && !$scope.activeChatThread) {
          const accepted = $scope.chatRequests.find(r => r.status === 'accepted');
          if (accepted) {
            $scope.openChatThread(accepted);
          }
        }
      }
    });
  };

  $scope.respondChatRequest = function(req, status) {
    const note = prompt(`Enter optional reply note (Action: ${status}):`, status === 'accepted' ? 'Happy to connect! Let us discuss your career goals.' : 'Unable to take mentorship at this time.');
    $http.put('api/chat/requests.php', {
      request_id: req.id,
      status: status,
      response_message: note
    }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast(res.data.message, 'success');
        $scope.loadChatRequests();
      }
    });
  };

  $scope.openChatThread = function(thread) {
    $scope.activeChatThread = thread;
    $http.get(`api/chat/messages.php?request_id=${thread.id}`).then(function(res) {
      if (res.data && res.data.success) {
        $scope.chatMessages = res.data.data;
        $timeout(function() {
          const el = document.getElementById('chatMessagesScroll');
          if (el) el.scrollTop = el.scrollHeight;
        }, 100);
      }
    });
  };

  $scope.sendChatMessage = function() {
    if (!$scope.newChatMessage || !$scope.activeChatThread) return;
    $http.post('api/chat/messages.php', {
      request_id: $scope.activeChatThread.id,
      message: $scope.newChatMessage
    }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.chatMessages.push(res.data.data);
        $scope.newChatMessage = '';
        $timeout(function() {
          const el = document.getElementById('chatMessagesScroll');
          if (el) el.scrollTop = el.scrollHeight;
        }, 50);
      }
    }, function(err) {
      $scope.showToast(err.data?.message || 'Failed to deliver message.', 'danger');
    });
  };

  $scope.reportChat = function(msg) {
    const reason = prompt('Please enter the reason for reporting this communication:', 'Unprofessional content');
    if (!reason) return;
    $http.post('api/chat/messages.php', {
      action: 'report',
      request_id: $scope.activeChatThread.id,
      message_id: msg.id,
      reason: reason
    }).then(function(res) {
      $scope.showToast(res.data.message || 'Report submitted.', 'info');
    });
  };

  // =========================================================================
  // INTERVIEW SCHEDULING (PHASE 9)
  // =========================================================================
  $scope.loadStudentInterviews = function() {
    $http.get('api/interviews/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.studentInterviews = res.data.data;
      }
    });
  };

  $scope.loadOfficerInterviews = function() {
    $http.get('api/interviews/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.allScheduledInterviews = res.data.data;
      }
    });
  };

  $scope.openScheduleInterviewModal = function(app = null) {
    if (app) {
      $scope.interviewForm = {
        id: 0,
        student_id: app.student_id,
        drive_id: app.drive_id,
        application_id: app.id,
        company_name: app.company_name,
        job_designation: app.job_role,
        interview_date: '',
        interview_time: '10:00',
        interview_mode: 'Online',
        location_or_link: 'https://meet.google.com/sanjivani-placement',
        instructions: 'Please be formal and join 5 minutes early with your portfolio link and resume ready.'
      };
    }
    const modal = new bootstrap.Modal(document.getElementById('scheduleInterviewModal'));
    modal.show();
  };

  $scope.saveInterview = function() {
    $http.post('api/interviews/index.php', $scope.interviewForm).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast(res.data.message, 'success');
        bootstrap.Modal.getInstance(document.getElementById('scheduleInterviewModal')).hide();
        $scope.loadOfficerInterviews();
        if ($scope.activeView === 'officer-applications') $scope.loadOfficerApplications();
      } else {
        $scope.showToast(res.data.message || 'Failed to schedule.', 'danger');
      }
    }, function(err) {
      $scope.showToast(err.data?.message || 'Error scheduling interview.', 'danger');
    });
  };

  $scope.updateInterviewStatus = function(iv, newStatus) {
    $http.put('api/interviews/index.php', { id: iv.id, status: newStatus }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast(`Interview status set to ${newStatus}.`, 'success');
        $scope.loadOfficerInterviews();
      }
    });
  };

  // =========================================================================
  // STUDENT PROFILE & RESUME VERSIONING (PHASE 4)
  // =========================================================================
  $scope.loadStudentDashboard = function() {
    $http.get('api/students/profile.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.studentProfile = res.data.data;
      }
    });
    $http.get('api/applications/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.studentApplications = res.data.data;
        $scope.studentInterviewsCount = $scope.studentApplications.filter(a => a.status === 'Interview').length;
        $scope.studentSelectedCount = $scope.studentApplications.filter(a => a.status === 'Selected').length;
      }
    });
    $http.get('api/drives/eligibility.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.studentEligibleDrives = res.data.data.filter(d => d.is_eligible);
      }
    });
  };

  $scope.loadStudentApplications = function() {
    $http.get('api/applications/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.studentApplications = res.data.data;
      }
    });
  };

  $scope.loadStudentProfile = function() {
    $http.get('api/students/profile.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.studentProfile = res.data.data;
      }
    });
  };

  $scope.saveStudentProfile = function() {
    $http.post('api/students/profile.php', $scope.studentProfile).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Profile and coding links saved successfully!', 'success');
        $scope.loadStudentProfile();
        $scope.checkAuth();
      } else {
        $scope.showToast(res.data.message || 'Save failed.', 'danger');
      }
    }, function(err) {
      $scope.showToast(err.data?.message || 'Error updating profile.', 'danger');
    });
  };

  $scope.loadResumeHistory = function() {
    $http.get('api/students/resume_manage.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.resumeHistory = res.data.data;
      }
    });
  };

  $scope.uploadNewResumeVersion = function() {
    const fileInput = document.getElementById('newResumeVersionInput');
    if (!fileInput || !fileInput.files.length) {
      $scope.showToast('Please select a PDF or DOCX file.', 'warning');
      return;
    }
    const file = fileInput.files[0];
    if (file.size > 5 * 1024 * 1024) {
      $scope.showToast('Resume exceeds 5MB limit.', 'danger');
      return;
    }

    $scope.resumeUploading = true;
    const formData = new FormData();
    formData.append('resume', file);

    $http.post('api/students/resume_manage.php', formData, {
      transformRequest: angular.identity,
      headers: { 'Content-Type': undefined }
    }).then(function(res) {
      $scope.resumeUploading = false;
      if (res.data && res.data.success) {
        $scope.showToast(res.data.message, 'success');
        fileInput.value = '';
        $scope.loadResumeHistory();
        $scope.loadStudentProfile();
        $scope.loadReadinessScore();
      } else {
        $scope.showToast(res.data.message || 'Upload failed.', 'danger');
      }
    }, function(err) {
      $scope.resumeUploading = false;
      $scope.showToast(err.data?.message || 'Upload failed.', 'danger');
    });
  };

  $scope.setActiveResume = function(resId) {
    const fd = new FormData();
    fd.append('action', 'set_active');
    fd.append('resume_id', resId);
    $http.post('api/students/resume_manage.php', fd, {
      transformRequest: angular.identity,
      headers: { 'Content-Type': undefined }
    }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast(res.data.message, 'success');
        $scope.loadResumeHistory();
        $scope.loadStudentProfile();
      }
    });
  };

  $scope.deleteResumeRecord = function(resId) {
    if (!confirm('Are you sure you want to delete this resume version?')) return;
    const fd = new FormData();
    fd.append('action', 'delete');
    fd.append('resume_id', resId);
    $http.post('api/students/resume_manage.php', fd, {
      transformRequest: angular.identity,
      headers: { 'Content-Type': undefined }
    }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast(res.data.message, 'success');
        $scope.loadResumeHistory();
        $scope.loadStudentProfile();
      }
    });
  };

  // =========================================================================
  // UNIQUE FEATURES: SMART MATCHING & READINESS (PHASE 11)
  // =========================================================================
  $scope.loadSmartMatches = function() {
    $http.get('api/smart_matching/jobs.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.smartMatches = res.data.data;
        if ($scope.smartMatches.length > 0 && !$scope.selectedMatch) {
          $scope.selectedMatch = $scope.smartMatches[0];
        }
      }
    });
  };

  $scope.selectMatchDrive = function(match) {
    $scope.selectedMatch = match;
  };

  $scope.loadReadinessScore = function() {
    $http.get('api/smart_matching/readiness.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.readinessData = res.data;
      }
    });
  };

  $scope.loadPrepMaterials = function() {
    const params = {
      category: $scope.prepFilter.category || 'all',
      search: $scope.prepFilter.search || '',
      company: $scope.prepFilter.company || ''
    };
    $http.get('api/prep_hub/index.php', { params: params }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.prepMaterials = res.data.data;
        $scope.prepCategories = res.data.category_counts;
      }
    });
  };

  $scope.loadAlumniReferrals = function() {
    $http.get('api/alumni/referrals.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.alumniReferrals = res.data.data;
      }
    });
  };

  $scope.applyForReferral = function(ref) {
    const notes = prompt(`Apply for referral at ${ref.company_name} for role "${ref.job_title}". Enter a brief note for the alumnus:`, 'I am passionate about this role and my technical skill set aligns with your requirements.');
    if (notes === null) return;
    $http.post('api/alumni/referrals.php', {
      action: 'apply',
      referral_id: ref.id,
      notes: notes
    }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast(res.data.message, 'success');
        $scope.loadAlumniReferrals();
      } else {
        $scope.showToast(res.data.message || 'Application failed.', 'danger');
      }
    }, function(err) {
      $scope.showToast(err.data?.message || 'Error submitting referral application.', 'danger');
    });
  };

  $scope.publishAlumniReferral = function() {
    $http.post('api/alumni/referrals.php', $scope.newReferralForm).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Referral opportunity posted successfully!', 'success');
        $scope.newReferralForm = { company_name: '', job_title: '', job_url: '', requirements: '', location: 'Pune / Kopargaon', deadline: '' };
        $scope.loadAlumniReferrals();
      }
    });
  };

  // =========================================================================
  // ATS RESUME CHECKER (PHASE 5)
  // =========================================================================
  $scope.loadAtsHistory = function() {
    $http.get('api/ats/history.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.atsResumes = res.data.resumes;
        $scope.atsRecentComparisons = res.data.recent_comparisons;
        if ($scope.atsResumes.length > 0 && !$scope.atsActiveResume) {
          $scope.atsActiveResume = $scope.atsResumes[0];
          $scope.atsAnalysis = $scope.atsResumes[0].latest_analysis;
        }
      }
    });
  };

  $scope.selectAtsResume = function(resItem) {
    $scope.atsActiveResume = resItem;
    $scope.atsAnalysis = resItem.latest_analysis;
    $scope.atsMatchResult = null;
  };

  $scope.uploadAtsResumeFile = function(files) {
    if (!files || !files.length) return;
    const file = files[0];
    const allowed = ['pdf', 'doc', 'docx'];
    const ext = file.name.split('.').pop().toLowerCase();
    if (!allowed.includes(ext)) {
      $scope.showToast('Invalid file format. Please upload PDF or DOCX.', 'danger');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      $scope.showToast('Resume exceeds 5MB limit.', 'danger');
      return;
    }

    $scope.atsUploading = true;
    const formData = new FormData();
    formData.append('resume', file);

    $http.post('api/ats/upload.php', formData, {
      transformRequest: angular.identity,
      headers: { 'Content-Type': undefined }
    }).then(function(res) {
      $scope.atsUploading = false;
      if (res.data && res.data.success) {
        $scope.showToast('Resume uploaded and audited successfully!', 'success');
        $scope.atsActiveResume = res.data.resume;
        $scope.atsAnalysis = res.data.analysis;
        $scope.loadAtsHistory();
      } else {
        $scope.showToast(res.data.message || 'Upload failed.', 'danger');
      }
    }, function(err) {
      $scope.atsUploading = false;
      $scope.showToast(err.data?.message || 'Resume upload failed.', 'danger');
    });
  };

  $scope.compareWithJobDescription = function() {
    if (!$scope.atsJD.job_description || $scope.atsJD.job_description.trim().length < 50) {
      $scope.showToast('Please paste a complete job description (minimum 50 characters).', 'warning');
      return;
    }
    $scope.atsMatching = true;
    $http.post('api/ats/match_jd.php', {
      resume_id: $scope.atsActiveResume ? $scope.atsActiveResume.id : 0,
      job_title: $scope.atsJD.job_title || 'Software Engineer',
      job_company: $scope.atsJD.job_company || 'Target Employer',
      job_description: $scope.atsJD.job_description
    }).then(function(res) {
      $scope.atsMatching = false;
      if (res.data && res.data.success) {
        $scope.atsMatchResult = res.data.match_report;
        $scope.showToast('Job Description match report generated!', 'success');
        $scope.loadAtsHistory();
      } else {
        $scope.showToast(res.data.message || 'Comparison failed.', 'danger');
      }
    }, function(err) {
      $scope.atsMatching = false;
      $scope.showToast(err.data?.message || 'Comparison failed.', 'danger');
    });
  };

  $scope.downloadAtsReportPdf = function() {
    $window.print();
  };

  // =========================================================================
  // PORTFOLIO BUILDER
  // =========================================================================
  $scope.loadStudentPortfolio = function() {
    $http.get('api/portfolio/get.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.portfolio = res.data.portfolio;
        $scope.publicPortfolio = res.data.portfolio;
      }
    });
  };

  $scope.savePortfolio = function() {
    $http.post('api/portfolio/save.php', $scope.portfolio).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Portfolio changes saved successfully!', 'success');
        $scope.loadStudentPortfolio();
      }
    });
  };

  $scope.togglePublishPortfolio = function() {
    const next = !$scope.portfolio.is_published;
    $http.post('api/portfolio/publish.php', { is_published: next }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.portfolio.is_published = next;
        $scope.showToast(res.data.message, 'success');
      }
    });
  };

  $scope.addSkill = function() {
    if (!$scope.newSkill.name) return;
    $scope.portfolio.skills.push({
      skill_name: $scope.newSkill.name,
      skill_type: $scope.newSkill.type,
      proficiency: $scope.newSkill.level
    });
    $scope.newSkill.name = '';
    $scope.savePortfolio();
  };

  $scope.removeSkill = function(idx) {
    $scope.portfolio.skills.splice(idx, 1);
    $scope.savePortfolio();
  };

  $scope.addProject = function() {
    $scope.portfolio.projects.push({
      title: 'New Technical Project',
      description: 'Describe the problem statement, architecture, and institutional outcome.',
      technologies: 'Java, MySQL, HTML5',
      github_url: '',
      live_url: '',
      featured: 1
    });
  };

  $scope.removeProject = function(idx) {
    $scope.portfolio.projects.splice(idx, 1);
    $scope.savePortfolio();
  };

  $scope.copyPortfolioUrl = function() {
    const url = `${window.location.origin}${window.location.pathname}#public-portfolio?slug=${$scope.portfolio.slug}`;
    navigator.clipboard.writeText(url).then(function() {
      $scope.showToast('Portfolio link copied to clipboard!', 'success');
    });
  };

  $scope.loadPublicPortfolioByHash = function(hash) {
    const parts = hash.split('?slug=');
    const slug = (parts.length > 1) ? parts[1] : '';
    if (!slug) return;
    $http.get(`api/portfolio/public.php?slug=${slug}`).then(function(res) {
      if (res.data && res.data.success) {
        $scope.publicPortfolio = res.data.portfolio;
      }
    });
  };

  // =========================================================================
  // ALUMNI DASHBOARD & PROFILE
  // =========================================================================
  $scope.loadAlumniDashboard = function() {
    $http.get('api/chat/requests.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.chatRequests = res.data.data;
        $scope.alumniPendingCount = $scope.chatRequests.filter(r => r.status === 'pending').length;
        $scope.alumniAcceptedCount = $scope.chatRequests.filter(r => r.status === 'accepted').length;
      }
    });
  };

  $scope.loadAlumniProfile = function() {
    $http.get('api/alumni/profile.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.alumniProfile = res.data.data;
        $scope.alumniProfile.available_for_mentorship = ($scope.alumniProfile.available_for_mentorship == 1);
      }
    });
  };

  $scope.saveAlumniProfile = function() {
    const payload = Object.assign({}, $scope.alumniProfile);
    payload.available_for_mentorship = payload.available_for_mentorship ? 1 : 0;
    $http.post('api/alumni/profile.php', payload).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Alumni profile updated successfully!', 'success');
        $scope.checkAuth();
      }
    });
  };

  // =========================================================================
  // PLACEMENT OFFICER DASHBOARD
  // =========================================================================
  $scope.loadOfficerDashboard = function() {
    $http.get('api/statistics/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.kpis = res.data.kpis;
      }
    });
    $http.get('api/applications/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.officerRecentApplications = res.data.data.slice(0, 6);
      }
    });
  };

  $scope.loadOfficerDrives = function() {
    $http.get('api/drives/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.officerDrives = res.data.data;
      }
    });
  };

  $scope.openDriveModal = function(drive = null) {
    $http.get('api/companies/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.companiesList = res.data.data;
      }
    });

    if (drive) {
      $scope.driveForm = Object.assign({}, drive);
      $scope.driveFormModalTitle = 'Edit Placement Drive';
    } else {
      $scope.driveForm = {
        id: 0,
        company_id: '',
        job_role: '',
        package: '',
        location: 'Pune / Mumbai',
        drive_date: '',
        deadline: '',
        min_cgpa: 7.0,
        eligible_branches: 'Computer Engineering, Information Technology, Electronics & Telecommunication',
        skills: 'Java, MySQL, Problem Solving',
        vacancies: 10,
        status: 'active'
      };
      $scope.driveFormModalTitle = 'Add New Placement Drive';
    }
    const modal = new bootstrap.Modal(document.getElementById('driveModal'));
    modal.show();
  };

  $scope.saveDrive = function() {
    const method = ($scope.driveForm.id > 0) ? 'PUT' : 'POST';
    $http({
      method: method,
      url: 'api/drives/index.php',
      data: $scope.driveForm
    }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Drive saved successfully!', 'success');
        bootstrap.Modal.getInstance(document.getElementById('driveModal')).hide();
        $scope.loadOfficerDrives();
      } else {
        $scope.showToast(res.data.message || 'Failed to save drive.', 'danger');
      }
    });
  };

  $scope.deleteDrive = function(drive) {
    if (!confirm('Are you sure you want to delete this placement drive?')) return;
    $http.delete(`api/drives/index.php?id=${drive.id}`).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Drive deleted.', 'success');
        $scope.loadOfficerDrives();
      }
    });
  };

  $scope.loadOfficerApplications = function() {
    const params = { status: $scope.appFilterStatus || '' };
    $http.get('api/applications/index.php', { params: params }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.officerApplications = res.data.data;
      }
    });
  };

  $scope.openStatusModal = function(app) {
    $scope.statusModalData = {
      application_id: app.id,
      status: app.status,
      notes: ''
    };
    const modal = new bootstrap.Modal(document.getElementById('updateStatusModal'));
    modal.show();
  };

  $scope.saveApplicationStatus = function() {
    $http.post('api/applications/status.php', $scope.statusModalData).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast(res.data.message, 'success');
        bootstrap.Modal.getInstance(document.getElementById('updateStatusModal')).hide();
        $scope.loadOfficerApplications();
        if ($scope.activeView === 'officer-dashboard') $scope.loadOfficerDashboard();
      }
    });
  };

  $scope.loadOfficerPlacements = function() {
    $http.get('api/placements/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.placements = res.data.data;
      }
    });
  };

  // =========================================================================
  // COMPLETE ADMINISTRATOR CONTROL (PHASE 10)
  // =========================================================================
  $scope.loadAdminAnalytics = function() {
    $http.get('api/admin/dashboard_stats.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.adminKPIs = res.data.kpis;
        $scope.auditLogs = res.data.recent_audits;
      }
    });
  };

  $scope.loadAdminStudents = function() {
    $http.get('api/students/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.adminStudents = res.data.data;
      }
    });
  };

  $scope.deleteAdminStudent = function(s) {
    if (!confirm(`Delete student account "${s.name}"? This action is permanent.`)) return;
    $http.delete(`api/students/index.php?id=${s.id}`).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Student account deleted.', 'success');
        $scope.loadAdminStudents();
      }
    });
  };

  $scope.loadAdminAlumni = function() {
    $http.get('api/alumni/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.adminAlumni = res.data.data;
      }
    });
  };

  $scope.deleteAdminAlumni = function(a) {
    if (!confirm(`Delete alumni record "${a.name}"?`)) return;
    $http.delete(`api/alumni/index.php?id=${a.id}`).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Alumni record deleted.', 'success');
        $scope.loadAdminAlumni();
      }
    });
  };

  $scope.loadAdminCompanies = function() {
    $http.get('api/companies/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.adminCompanies = res.data.data;
      }
    });
  };

  $scope.loadAdminUsers = function() {
    $http.get('api/auth/users.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.adminUsers = res.data.data;
      }
    });
  };

  $scope.toggleUserStatus = function(u) {
    $http.put('api/auth/users.php', { id: u.id, action: 'toggle_status' }).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast(res.data.message, 'success');
        $scope.loadAdminUsers();
      }
    });
  };

  $scope.loadAuditLogs = function() {
    $http.get('api/admin/audit_logs.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.auditLogs = res.data.data;
      }
    });
  };

  $scope.saveAnnouncement = function() {
    $http.post('api/admin/announcements.php', $scope.announcementForm).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Announcement published successfully!', 'success');
        $scope.announcementForm = { title: '', content: '', target_role: 'all' };
        $scope.loadAnnouncements();
      }
    });
  };

  $scope.deleteAnnouncement = function(a) {
    if (!confirm('Delete this announcement?')) return;
    $http.delete(`api/admin/announcements.php?id=${a.id}`).then(function(res) {
      if (res.data && res.data.success) {
        $scope.showToast('Announcement removed.', 'success');
        $scope.loadAnnouncements();
      }
    });
  };

  // =========================================================================
  // STATISTICS & CHARTS
  // =========================================================================
  $scope.loadStatistics = function() {
    $http.get('api/statistics/index.php').then(function(res) {
      if (res.data && res.data.success) {
        $scope.kpis = res.data.kpis;
        $timeout(function() {
          if (window.PortalCharts) {
            PortalCharts.renderAll(res.data.charts);
          }
        }, 100);
      }
    });
  };

  $scope.downloadReport = function(type, format) {
    $window.location.href = `api/reports/export.php?type=${type}&format=${format}`;
  };

  // Global Bridge
  $window.App = {
    navigate: (v) => $scope.$apply(() => $scope.navigate(v)),
    logout: () => $scope.$apply(() => $scope.logout()),
    downloadReport: (t, f) => $scope.downloadReport(t, f)
  };

  // Hash listener
  $window.addEventListener('hashchange', function() {
    const rawHash = $window.location.hash.replace('#', '');
    if (rawHash) {
      $scope.$apply(function() {
        $scope.navigate(rawHash, false);
      });
    }
  });

  // App Startup
  $scope.checkAuth().then(function() {
    const hash = $window.location.hash.replace('#', '');
    $scope.navigate(hash || 'home', false);
  });
}]);
