<?php
/**
 * API: Centralized Personalized Notification Center
 * Implements Phase 9 & 11: Notification Alerts & Unread Badges
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireLogin();
$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->prepare("
        SELECT id, title, message, type, reference_id, is_read, created_at
        FROM notifications
        WHERE user_id = :uid
        ORDER BY is_read ASC, created_at DESC
        LIMIT 30
    ");
    $stmt->execute(['uid' => $user['id']]);
    $notifications = $stmt->fetchAll();

    $unreadStmt = $pdo->prepare("SELECT COUNT(*) AS unread FROM notifications WHERE user_id = :uid AND is_read = 0");
    $unreadStmt->execute(['uid' => $user['id']]);
    $unreadCount = (int)($unreadStmt->fetch()['unread'] ?? 0);

    sendJson([
        'success' => true,
        'data' => $notifications,
        'unread_count' => $unreadCount
    ]);
}

if ($method === 'POST') {
    $data = getRequestData();
    $action = $data['action'] ?? 'mark_read';
    $notifId = (int)($data['id'] ?? 0);

    if ($action === 'mark_all_read') {
        $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = :uid")->execute(['uid' => $user['id']]);
        sendJson(['success' => true, 'message' => 'All notifications marked as read.']);
    }

    if ($notifId > 0) {
        $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = :id AND user_id = :uid")->execute(['id' => $notifId, 'uid' => $user['id']]);
        sendJson(['success' => true, 'message' => 'Notification marked as read.']);
    }

    sendError('Notification ID or action required.', 400);
}

sendError('Method Not Allowed', 405);
