<?php
/**
 * Generator for SU T&P Enterprise index.html
 * Ensures 100% tag balance, zero demo accounts, and complete phase coverage
 */

$html = <<<'HTML'
<!DOCTYPE html>
<html lang="en" ng-app="placementPortalApp" ng-controller="PortalCtrl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SU T&P - Sanjivani University Placement & Alumni Portal, Kopargaon</title>
  <!-- Bootstrap 5 CSS -->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <!-- Chart.js -->
  <script src="assets/js/chart.umd.min.js"></script>
  <!-- AngularJS 1.8 -->
  <script src="assets/js/angular.min.js"></script>
  <!-- Custom CSS -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/dashboard.css">
</head>
<body>

  <!-- Top Global Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark navbar-custom sticky-top">
    <div class="container-fluid px-3 px-lg-4">
      <a class="navbar-brand d-flex align-items-center gap-2" href="#home" ng-click="navigate('home')">
        <div class="navbar-brand-badge">
          <i class="bi bi-mortarboard-fill fs-4 text-warning"></i>
        </div>
        <div>
          <span class="fw-bold fs-5 tracking-tight d-block text-white">SU T&P</span>
          <span class="small text-white-50" style="font-size: 0.72rem; letter-spacing: 0.5px;">SANJIVANI UNIVERSITY &bull; PLACEMENT & ALUMNI CELL &bull; KOPARGAON</span>
        </div>
      </a>

      <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarMain">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3">
          <li class="nav-item">
            <a class="nav-link" ng-class="{active: activeView === 'home'}" href="#home" ng-click="navigate('home')"><i class="bi bi-house-door me-1"></i>Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" ng-class="{active: activeView === 'drives'}" href="#drives" ng-click="navigate('drives')"><i class="bi bi-briefcase me-1"></i>Placement Drives</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" ng-class="{active: activeView === 'alumni'}" href="#alumni" ng-click="navigate('alumni')"><i class="bi bi-people me-1"></i>Alumni Directory</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" ng-class="{active: activeView === 'prep-hub'}" href="#prep-hub" ng-click="navigate('prep-hub')"><i class="bi bi-journal-code me-1"></i>Interview Prep</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" ng-class="{active: activeView === 'statistics'}" href="#statistics" ng-click="navigate('statistics')"><i class="bi bi-bar-chart-line me-1"></i>Statistics</a>
          </li>
        </ul>

        <!-- Right Side Nav: Notifications, Chat & Auth -->
        <div class="d-flex align-items-center gap-2">
          <!-- Notification Bell Dropdown (Logged In) -->
          <div class="dropdown" ng-if="currentUser">
            <button class="notif-bell-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" title="Notifications">
              <i class="bi bi-bell-fill"></i>
              <span class="notif-badge" ng-if="unreadNotificationsCount > 0">{{unreadNotificationsCount}}</span>
            </button>
            <div class="dropdown-menu dropdown-menu-end shadow-lg p-0" style="width: 320px; max-height: 420px; overflow-y: auto;">
              <div class="p-3 bg-light border-bottom d-flex justify-content-between align-items-center">
                <span class="fw-bold small text-dark"><i class="bi bi-bell me-1 text-primary"></i>Notifications ({{unreadNotificationsCount}} unread)</span>
                <button class="btn btn-link btn-sm p-0 text-decoration-none small" ng-click="markAllNotificationsRead()" ng-if="unreadNotificationsCount > 0">Mark all read</button>
              </div>
              <div class="list-group list-group-flush" ng-if="notifications.length > 0">
                <div class="list-group-item list-group-item-action p-2" ng-repeat="n in notifications" ng-class="{'bg-light': !n.is_read}" ng-click="markNotificationRead(n)" style="cursor: pointer;">
                  <div class="d-flex justify-content-between align-items-center">
                    <span class="badge bg-primary-subtle text-primary small fw-semibold">{{n.type}}</span>
                    <small class="text-muted" style="font-size: 0.72rem;">{{n.created_at | date:'shortTime'}}</small>
                  </div>
                  <div class="fw-bold small text-dark mt-1">{{n.title}}</div>
                  <p class="small text-muted mb-0" style="font-size: 0.8rem;">{{n.message}}</p>
                </div>
              </div>
              <div class="p-3 text-center text-muted small" ng-if="notifications.length === 0">
                <i class="bi bi-check2-circle fs-4 text-success d-block mb-1"></i>
                No notifications right now.
              </div>
            </div>
          </div>

          <!-- Direct Chat Shortcut (Student/Alumni) -->
          <button class="btn btn-sm btn-outline-light rounded-pill px-3" ng-if="currentUser && currentUser.role === 'student'" ng-click="navigate('student-chat')">
            <i class="bi bi-chat-dots-fill me-1 text-info"></i>Alumni Chat
          </button>
          <button class="btn btn-sm btn-outline-light rounded-pill px-3" ng-if="currentUser && currentUser.role === 'alumni'" ng-click="navigate('alumni-chat')">
            <i class="bi bi-chat-dots-fill me-1 text-info"></i>Student Chats
          </button>

          <!-- User Profile & Navigation -->
          <div class="dropdown" ng-if="currentUser">
            <button class="btn btn-sm btn-outline-light dropdown-toggle d-flex align-items-center gap-2 rounded-pill px-3" type="button" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle fs-5"></i>
              <span class="d-none d-md-inline fw-semibold">{{currentUser.name}}</span>
              <span class="badge bg-warning text-dark text-capitalize ms-1">{{currentUser.role}}</span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow">
              <li><h6 class="dropdown-header">{{currentUser.email}}</h6></li>
              <li ng-if="currentUser.role === 'student'"><a class="dropdown-item" href="#student-dashboard" ng-click="navigate('student-dashboard')"><i class="bi bi-speedometer2 me-2 text-primary"></i>Student Dashboard</a></li>
              <li ng-if="currentUser.role === 'student'"><a class="dropdown-item" href="#student-profile" ng-click="navigate('student-profile')"><i class="bi bi-person-lines-fill me-2 text-info"></i>Profile & Resumes</a></li>
              <li ng-if="currentUser.role === 'student'"><a class="dropdown-item" href="#smart-matching" ng-click="navigate('smart-matching')"><i class="bi bi-stars me-2 text-warning"></i>Smart Job Matcher</a></li>
              <li ng-if="currentUser.role === 'student'"><a class="dropdown-item" href="#student-portfolio" ng-click="navigate('student-portfolio')"><i class="bi bi-person-badge me-2 text-success"></i>Portfolio Builder</a></li>
              <li ng-if="currentUser.role === 'student'"><a class="dropdown-item" href="#student-ats" ng-click="navigate('student-ats')"><i class="bi bi-file-earmark-check me-2 text-danger"></i>ATS Resume Checker</a></li>
              <li ng-if="currentUser.role === 'student'"><a class="dropdown-item" href="#alumni-referrals" ng-click="navigate('alumni-referrals')"><i class="bi bi-megaphone me-2 text-primary"></i>Alumni Referrals</a></li>

              <li ng-if="currentUser.role === 'alumni'"><a class="dropdown-item" href="#alumni-dashboard" ng-click="navigate('alumni-dashboard')"><i class="bi bi-speedometer2 me-2 text-primary"></i>Alumni Dashboard</a></li>
              <li ng-if="currentUser.role === 'alumni'"><a class="dropdown-item" href="#alumni-profile" ng-click="navigate('alumni-profile')"><i class="bi bi-person me-2 text-info"></i>Alumni Profile</a></li>
              <li ng-if="currentUser.role === 'alumni'"><a class="dropdown-item" href="#alumni-referrals" ng-click="navigate('alumni-referrals')"><i class="bi bi-megaphone me-2 text-success"></i>Post Job Referral</a></li>

              <li ng-if="currentUser.role === 'officer'"><a class="dropdown-item" href="#officer-dashboard" ng-click="navigate('officer-dashboard')"><i class="bi bi-speedometer2 me-2 text-primary"></i>TPO Dashboard</a></li>
              <li ng-if="currentUser.role === 'officer'"><a class="dropdown-item" href="#officer-drives" ng-click="navigate('officer-drives')"><i class="bi bi-briefcase me-2 text-info"></i>Manage Drives</a></li>
              <li ng-if="currentUser.role === 'officer'"><a class="dropdown-item" href="#officer-interviews" ng-click="navigate('officer-interviews')"><i class="bi bi-calendar-check me-2 text-warning"></i>Schedule Interviews</a></li>

              <li ng-if="currentUser.role === 'admin'"><a class="dropdown-item" href="#admin-dashboard" ng-click="navigate('admin-dashboard')"><i class="bi bi-shield-lock me-2 text-danger"></i>Admin Console</a></li>

              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item text-danger" href="javascript:void(0)" ng-click="logout()"><i class="bi bi-box-arrow-right me-2"></i>Sign Out</a></li>
            </ul>
          </div>

          <!-- Guest State: Login / Register -->
          <div class="d-flex align-items-center gap-2" ng-if="!currentUser">
            <a class="btn btn-sm btn-outline-light rounded-pill px-3" href="#login" ng-click="navigate('login')">
              <i class="bi bi-box-arrow-in-right me-1"></i>Sign In
            </a>
            <a class="btn btn-sm btn-warning text-dark fw-bold rounded-pill px-3 shadow-sm" href="#register" ng-click="navigate('register')">
              <i class="bi bi-person-plus-fill me-1"></i>Register
            </a>
          </div>
        </div>
      </div>
    </div>
  </nav>

  <!-- Main Views Container -->
  <main class="flex-grow-1">

    <!-- ========================================== -->
    <!-- 1. HOMEPAGE VIEW                           -->
    <!-- ========================================== -->
    <div id="view-home" class="view-container" ng-show="activeView === 'home'">
      <!-- Hero Section -->
      <section class="hero-section">
        <div class="container position-relative" style="z-index: 2;">
          <div class="row align-items-center">
            <div class="col-lg-8">
              <div class="hero-badge mb-3">
                <i class="bi bi-patch-check-fill text-warning"></i>
                Official Training, Placement & Alumni Directorate &bull; Kopargaon Campus
              </div>
              <h1 class="hero-title mb-3">
                Empowering Futures.<br>Connecting Campus with Industry.
              </h1>
              <p class="hero-subtitle mb-4">
                SU T&P connects ambitious engineering students with leading global technology enterprises, multinational conglomerates, and verified alumni mentors for career acceleration and placement excellence.
              </p>
              <div class="d-flex flex-wrap gap-2">
                <a href="#drives" ng-click="navigate('drives')" class="btn btn-warning btn-lg fw-bold text-dark px-4 shadow">
                  <i class="bi bi-briefcase-fill me-2"></i>Explore Placement Drives
                </a>
                <a href="#alumni" ng-click="navigate('alumni')" class="btn btn-outline-light btn-lg px-4">
                  <i class="bi bi-people-fill me-2"></i>Kopargaon Alumni Network
                </a>
              </div>
            </div>
            <div class="col-lg-4 text-center d-none d-lg-block">
              <div class="p-4 rounded-4 shadow-lg border border-white border-opacity-25" style="background: rgba(255, 255, 255, 0.08); backdrop-filter: blur(12px);">
                <i class="bi bi-building-check fs-1 text-warning mb-2 d-block"></i>
                <h4 class="fw-bold text-white mb-1">Campus Recruitment</h4>
                <p class="text-white-50 small mb-3">Top technology recruiters visiting Sanjivani University campus for high-package placement drives.</p>
                <div class="d-flex justify-content-center gap-2">
                  <span class="badge bg-success bg-opacity-25 text-success-emphasis border border-success border-opacity-25 px-2 py-1">Direct Drives</span>
                  <span class="badge bg-info bg-opacity-25 text-info-emphasis border border-info border-opacity-25 px-2 py-1">ATS Checking</span>
                  <span class="badge bg-warning bg-opacity-25 text-warning-emphasis border border-warning border-opacity-25 px-2 py-1">Mentorship</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Institutional Announcements Ticker -->
      <section class="py-2 bg-light border-bottom" ng-if="announcements.length > 0">
        <div class="container">
          <div class="d-flex align-items-center gap-3">
            <span class="badge bg-danger fw-bold text-uppercase px-2 py-1"><i class="bi bi-megaphone-fill me-1"></i>Notice</span>
            <div class="text-truncate flex-grow-1 small fw-semibold text-dark">
              <span class="me-3" ng-repeat="a in announcements">
                &bull; <b>{{a.title}}:</b> {{a.content}}
              </span>
            </div>
          </div>
        </div>
      </section>

      <!-- Placement Highlights / KPI Row -->
      <section class="py-4">
        <div class="container">
          <div class="row g-3 text-center">
            <div class="col-md-3 col-6">
              <div class="kpi-card">
                <div class="kpi-icon-wrapper bg-primary-subtle text-primary mx-auto mb-2">
                  <i class="bi bi-buildings-fill"></i>
                </div>
                <h3 class="fw-bold mb-0">{{kpis.total_companies || 8}}</h3>
                <small class="text-muted fw-semibold">Hiring Partners</small>
              </div>
            </div>
            <div class="col-md-3 col-6">
              <div class="kpi-card">
                <div class="kpi-icon-wrapper bg-success-subtle text-success mx-auto mb-2">
                  <i class="bi bi-graph-up-arrow"></i>
                </div>
                <h3 class="fw-bold mb-0">18.0 LPA</h3>
                <small class="text-muted fw-semibold">Highest Campus Package</small>
              </div>
            </div>
            <div class="col-md-3 col-6">
              <div class="kpi-card">
                <div class="kpi-icon-wrapper bg-info-subtle text-info mx-auto mb-2">
                  <i class="bi bi-cash-stack"></i>
                </div>
                <h3 class="fw-bold mb-0">12.5 LPA</h3>
                <small class="text-muted fw-semibold">Average Package</small>
              </div>
            </div>
            <div class="col-md-3 col-6">
              <div class="kpi-card">
                <div class="kpi-icon-wrapper bg-warning-subtle text-warning mx-auto mb-2">
                  <i class="bi bi-people-fill"></i>
                </div>
                <h3 class="fw-bold mb-0">Verified</h3>
                <small class="text-muted fw-semibold">Kopargaon Alumni Network</small>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Latest Placement Drives Preview -->
      <section class="section-compact bg-white border-top border-bottom">
        <div class="container">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
              <span class="text-primary fw-bold text-uppercase small" style="letter-spacing: 0.5px;">Opportunities</span>
              <h3 class="fw-bold mb-0">Active Placement Drives</h3>
            </div>
            <button class="btn btn-outline-primary btn-sm" ng-click="navigate('drives')">
              View All Drives <i class="bi bi-arrow-right ms-1"></i>
            </button>
          </div>
          <div class="row g-3">
            <div class="col-md-6 col-lg-4" ng-repeat="d in latestDrives">
              <div class="portal-card">
                <div class="card-top-accent"></div>
                <div class="p-3 d-flex flex-column h-100">
                  <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                      <span class="badge bg-light text-dark border mb-1">{{d.company_name}}</span>
                      <h5 class="fw-bold mb-0 text-dark">{{d.job_role}}</h5>
                    </div>
                    <span class="badge bg-primary-subtle text-primary fw-bold fs-6">{{d.package}} LPA</span>
                  </div>
                  <div class="mb-3 text-muted small">
                    <div><i class="bi bi-geo-alt me-1"></i>{{d.location}}</div>
                    <div><i class="bi bi-calendar-event me-1"></i>Drive Date: {{d.drive_date}}</div>
                    <div><i class="bi bi-clock me-1 text-danger"></i>Deadline: <b>{{d.deadline}}</b></div>
                  </div>
                  <div class="p-2 rounded bg-light border mb-3 small">
                    <div><b>Min CGPA:</b> {{d.min_cgpa}}</div>
                    <div class="text-truncate"><b>Branches:</b> {{d.eligible_branches}}</div>
                  </div>
                  <div class="mt-auto pt-2 border-top d-flex justify-content-between align-items-center">
                    <span class="badge bg-success-subtle text-success border border-success-subtle">Active Drive</span>
                    <button class="btn btn-sm btn-outline-primary" ng-click="showDriveDetails(d)">
                      <i class="bi bi-eye me-1"></i>Details
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 text-center py-4" ng-if="!latestDrives || latestDrives.length === 0">
              <p class="text-muted small">Upcoming recruitment drives will be published here by the Training & Placement Cell.</p>
            </div>
          </div>
        </div>
      </section>

      <!-- Hiring Partners Showcase -->
      <section class="section-compact">
        <div class="container">
          <div class="text-center mb-4">
            <span class="badge bg-primary-subtle text-primary fw-bold text-uppercase px-3 py-1 mb-2">
              <i class="bi bi-globe-americas me-1"></i> Industry Partners
            </span>
            <h3 class="fw-bold">Premier Campus Recruiters</h3>
            <p class="text-muted small mx-auto" style="max-width: 600px;">
              Industry conglomerates and technology enterprises hiring graduates from Sanjivani University, Kopargaon.
            </p>
          </div>
          <div class="row g-3">
            <div class="col-md-6 col-lg-3 col-sm-6" ng-repeat="c in companies">
              <div class="portal-card p-3 d-flex flex-column h-100 shadow-sm">
                <div class="d-flex justify-content-between align-items-start mb-2">
                  <div class="kpi-icon-wrapper bg-primary-subtle text-primary shadow-sm" style="width:40px; height:40px; font-size:1.15rem;">
                    <i class="bi bi-buildings-fill"></i>
                  </div>
                  <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle small fw-semibold">
                    <i class="bi bi-patch-check-fill text-warning me-1"></i>Hiring Partner
                  </span>
                </div>
                <h5 class="fw-bold mb-1 text-dark">{{c.company_name}}</h5>
                <span class="text-primary small fw-semibold mb-2"><i class="bi bi-cpu me-1"></i>{{c.industry}}</span>
                <p class="text-muted small mb-3 flex-grow-1" style="font-size: 0.82rem; line-height: 1.4;">{{c.description}}</p>
                <div class="small text-muted mb-2">
                  <i class="bi bi-geo-alt-fill me-1 text-danger"></i>{{c.location}}
                </div>
                <div class="pt-2 border-top d-flex align-items-center justify-content-between">
                  <span class="badge bg-success-subtle text-success border border-success-subtle" ng-if="c.active_drives_count > 0">
                    {{c.active_drives_count}} Drive{{c.active_drives_count > 1 ? 's' : ''}}
                  </span>
                  <a ng-if="c.website" ng-href="{{c.website}}" target="_blank" class="btn btn-sm btn-outline-primary py-0 px-2" title="Company Website">
                    <i class="bi bi-box-arrow-up-right"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Alumni Mentorship Highlight Section -->
      <section class="section-compact bg-primary text-white position-relative">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-8 mb-3 mb-lg-0">
              <span class="badge bg-warning text-dark px-3 py-1 fw-semibold mb-2"><i class="bi bi-star-fill me-1"></i>Kopargaon Alumni Network</span>
              <h3 class="fw-bold text-white">Direct Mentorship & 1-on-1 Guidance</h3>
              <p class="text-white-50 mb-3 small" style="max-width: 650px;">
                Connect with verified Sanjivani University graduates working at leading technology companies. Request career mentorship, resume reviews, and direct interview prep.
              </p>
              <button class="btn btn-warning fw-bold text-dark px-4 shadow-sm" ng-click="navigate('alumni')">
                <i class="bi bi-chat-heart-fill me-2"></i>Connect with Alumni Mentors
              </button>
            </div>
            <div class="col-lg-4 text-center">
              <div class="p-3 bg-white text-dark rounded-3 shadow">
                <i class="bi bi-mortarboard fs-2 text-primary mb-1 d-block"></i>
                <h5 class="fw-bold mb-1">Authentic Mentorship</h5>
                <p class="text-muted small mb-2">Direct request-and-response chat with verified graduates from Kopargaon campus.</p>
                <div class="d-flex justify-content-center gap-1">
                  <span class="badge bg-success">Mock Interviews</span>
                  <span class="badge bg-info">Resume Guidance</span>
                  <span class="badge bg-primary">Referrals</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Official Campus Contact Information (Phase 15) -->
      <section class="section-compact bg-light">
        <div class="container">
          <div class="row g-3">
            <div class="col-md-4">
              <div class="p-3 bg-white rounded-3 border h-100 shadow-sm">
                <i class="bi bi-geo-alt-fill text-primary fs-4 mb-2 d-block"></i>
                <h6 class="fw-bold mb-1">Campus Location</h6>
                <p class="text-muted small mb-0">
                  Directorate of Corporate Relations & T&P<br>
                  Sanjivani University &bull; Kopargaon<br>
                  Dist: Ahmednagar, Maharashtra - 423603
                </p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="p-3 bg-white rounded-3 border h-100 shadow-sm">
                <i class="bi bi-telephone-fill text-primary fs-4 mb-2 d-block"></i>
                <h6 class="fw-bold mb-1">Official Contact</h6>
                <p class="text-muted small mb-0">
                  Phone: <b>8668680085</b><br>
                  Email: <b>tpo@sanjivani.edu.in</b><br>
                  Support: Active Portal Assistance
                </p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="p-3 bg-white rounded-3 border h-100 shadow-sm">
                <i class="bi bi-clock-fill text-primary fs-4 mb-2 d-block"></i>
                <h6 class="fw-bold mb-1">Office Hours</h6>
                <p class="text-muted small mb-0">
                  Monday &ndash; Saturday: 9:00 AM &ndash; 5:30 PM<br>
                  Drive Days: Active Throughout Schedule<br>
                  Online Portal: 24/7 Access
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>

    <!-- ========================================== -->
    <!-- 2. LOGIN VIEW (PHASE 2: ZERO DEMO BUTTONS) -->
    <!-- ========================================== -->
    <div id="view-login" class="view-container section-compact" ng-show="activeView === 'login'">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-6 col-lg-4">
            <div class="card shadow-md border-0 rounded-3 overflow-hidden">
              <div class="p-3 text-white text-center" style="background: linear-gradient(135deg, #090e29 0%, #1e1b4b 100%);">
                <i class="bi bi-shield-lock-fill fs-2 mb-1"></i>
                <h5 class="fw-bold mb-0">Institutional Sign In</h5>
                <small class="text-white-50">SU T&P &bull; Sanjivani University</small>
              </div>
              <div class="card-body p-4">
                <form ng-submit="login()">
                  <div class="mb-3">
                    <label class="form-label small fw-semibold">Registered Email Address</label>
                    <div class="input-group">
                      <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope text-muted"></i></span>
                      <input type="email" class="form-control border-start-0" ng-model="loginData.email" placeholder="name@sanjivani.edu.in" required>
                    </div>
                  </div>
                  <div class="mb-3">
                    <label class="form-label small fw-semibold">Account Password</label>
                    <div class="input-group">
                      <span class="input-group-text bg-light border-end-0"><i class="bi bi-key text-muted"></i></span>
                      <input type="password" class="form-control border-start-0" ng-model="loginData.password" placeholder="Enter account password" required>
                    </div>
                  </div>
                  <button type="submit" class="btn btn-primary w-100 fw-bold py-2 shadow-sm">
                    <i class="bi bi-box-arrow-in-right me-1"></i>Sign In to Portal
                  </button>
                </form>

                <div class="text-center mt-3 pt-3 border-top">
                  <span class="small text-muted">New student or alumnus?</span>
                  <a href="#register" ng-click="navigate('register')" class="small fw-bold text-primary ms-1">Create Account</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 3. REGISTER VIEW                           -->
    <!-- ========================================== -->
    <div id="view-register" class="view-container section-compact" ng-show="activeView === 'register'">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-8 col-lg-6">
            <div class="card shadow-md border-0 rounded-3 overflow-hidden">
              <div class="p-3 text-white text-center" style="background: linear-gradient(135deg, #090e29 0%, #1e1b4b 100%);">
                <i class="bi bi-person-plus-fill fs-2 mb-1"></i>
                <h5 class="fw-bold mb-0">Create Portal Account</h5>
                <small class="text-white-50">Sanjivani University &bull; Training & Placement Cell</small>
              </div>
              <div class="card-body p-4">
                <form ng-submit="register()">
                  <div class="mb-3">
                    <label class="form-label small fw-semibold">Register As</label>
                    <div class="d-flex gap-4">
                      <div class="form-check">
                        <input class="form-check-input" type="radio" ng-model="regData.role" value="student" id="roleStudent">
                        <label class="form-check-label" for="roleStudent">Student</label>
                      </div>
                      <div class="form-check">
                        <input class="form-check-input" type="radio" ng-model="regData.role" value="alumni" id="roleAlumni">
                        <label class="form-check-label" for="roleAlumni">Alumnus / Mentor</label>
                      </div>
                    </div>
                  </div>

                  <div class="row g-2 mb-3">
                    <div class="col-md-6">
                      <label class="form-label small fw-semibold">Full Name</label>
                      <input type="text" class="form-control form-control-sm" ng-model="regData.name" placeholder="Full Name" required>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label small fw-semibold">Email Address</label>
                      <input type="email" class="form-control form-control-sm" ng-model="regData.email" placeholder="name@sanjivani.edu.in" required>
                    </div>
                  </div>

                  <div class="mb-3">
                    <label class="form-label small fw-semibold">Account Password</label>
                    <input type="password" class="form-control form-control-sm" ng-model="regData.password" placeholder="Create strong password" required>
                  </div>

                  <div class="row g-2 mb-3">
                    <div class="col-md-6">
                      <label class="form-label small fw-semibold">Department / Branch</label>
                      <select class="form-select form-select-sm" ng-model="regData.branch" required>
                        <option value="Computer Engineering">Computer Engineering</option>
                        <option value="Information Technology">Information Technology</option>
                        <option value="Electronics & Telecommunication">Electronics & Telecommunication</option>
                        <option value="Mechanical Engineering">Mechanical Engineering</option>
                        <option value="Civil Engineering">Civil Engineering</option>
                      </select>
                    </div>
                    <div class="col-md-6" ng-if="regData.role === 'student'">
                      <label class="form-label small fw-semibold">Roll Number / PRN</label>
                      <input type="text" class="form-control form-control-sm" ng-model="regData.roll_no" placeholder="SU2024..." required>
                    </div>
                    <div class="col-md-6" ng-if="regData.role === 'alumni'">
                      <label class="form-label small fw-semibold">Graduation Year</label>
                      <input type="number" class="form-control form-control-sm" ng-model="regData.graduation_year" placeholder="2021" required>
                    </div>
                  </div>

                  <div class="row g-2 mb-3" ng-if="regData.role === 'student'">
                    <div class="col-md-6">
                      <label class="form-label small fw-semibold">Current CGPA</label>
                      <input type="number" step="0.01" class="form-control form-control-sm" ng-model="regData.cgpa" placeholder="8.50" required>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label small fw-semibold">Contact Mobile</label>
                      <input type="text" class="form-control form-control-sm" ng-model="regData.phone" placeholder="Mobile Number" required>
                    </div>
                  </div>

                  <button type="submit" class="btn btn-warning w-100 fw-bold py-2 shadow-sm text-dark mt-2">
                    <i class="bi bi-check-circle-fill me-1"></i>Register Account
                  </button>
                </form>

                <div class="text-center mt-3 pt-3 border-top">
                  <span class="small text-muted">Already have an account?</span>
                  <a href="#login" ng-click="navigate('login')" class="small fw-bold text-primary ms-1">Sign In</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 4. PLACEMENT DRIVES VIEW                   -->
    <!-- ========================================== -->
    <div id="view-drives" class="view-container section-compact" ng-show="activeView === 'drives'">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div>
            <span class="text-primary fw-bold text-uppercase small">Opportunities</span>
            <h3 class="fw-bold mb-0">Placement Recruitment Drives</h3>
          </div>
          <button class="btn btn-primary btn-sm" ng-if="currentUser && ['officer', 'admin'].includes(currentUser.role)" ng-click="openDriveModal()">
            <i class="bi bi-plus-circle me-1"></i>Add New Drive
          </button>
        </div>

        <!-- Filter Card -->
        <div class="filter-card shadow-sm mb-3">
          <div class="row g-2">
            <div class="col-md-4">
              <input type="text" class="form-control form-control-sm" ng-model="driveFilter.search" ng-change="loadDrives()" placeholder="Search company, role, or skills...">
            </div>
            <div class="col-md-4">
              <select class="form-select form-select-sm" ng-model="driveFilter.branch" ng-change="loadDrives()">
                <option value="">All Engineering Departments</option>
                <option value="Computer">Computer Engineering</option>
                <option value="Information Technology">Information Technology</option>
                <option value="Electronics">Electronics & Telecommunication</option>
                <option value="Mechanical">Mechanical Engineering</option>
              </select>
            </div>
            <div class="col-md-4">
              <select class="form-select form-select-sm" ng-model="driveFilter.status" ng-change="loadDrives()">
                <option value="active">Active Drives Only</option>
                <option value="all">All Drives (Active & Closed)</option>
              </select>
            </div>
          </div>
        </div>

        <!-- Drives Grid -->
        <div class="row g-3">
          <div class="col-md-6 col-lg-4" ng-repeat="d in drives">
            <div class="portal-card">
              <div class="card-top-accent"></div>
              <div class="p-3 d-flex flex-column h-100">
                <div class="d-flex justify-content-between align-items-start mb-2">
                  <div>
                    <span class="badge bg-light text-dark border mb-1">{{d.company_name}}</span>
                    <h5 class="fw-bold mb-0 text-dark">{{d.job_role}}</h5>
                  </div>
                  <span class="badge bg-primary-subtle text-primary fw-bold fs-6">{{d.package}} LPA</span>
                </div>
                <div class="mb-3 text-muted small">
                  <div><i class="bi bi-geo-alt me-1"></i>{{d.location}}</div>
                  <div><i class="bi bi-calendar-event me-1"></i>Drive Date: {{d.drive_date}}</div>
                  <div><i class="bi bi-clock me-1 text-danger"></i>Deadline: <b>{{d.deadline}}</b></div>
                </div>
                <div class="p-2 rounded bg-light border mb-3 small">
                  <div><b>Min CGPA:</b> {{d.min_cgpa}}</div>
                  <div class="text-truncate"><b>Branches:</b> {{d.eligible_branches}}</div>
                  <div class="text-truncate"><b>Required Skills:</b> {{d.skills}}</div>
                </div>
                <div class="mt-auto pt-2 border-top d-flex justify-content-between align-items-center">
                  <span class="badge" ng-class="{'bg-success-subtle text-success border border-success-subtle': d.status === 'active', 'bg-secondary-subtle text-secondary': d.status !== 'active'}">
                    {{d.status | uppercase}}
                  </span>
                  <div class="d-flex gap-1">
                    <button class="btn btn-sm btn-outline-primary" ng-click="showDriveDetails(d)">
                      <i class="bi bi-eye me-1"></i>Details
                    </button>
                    <button class="btn btn-sm btn-primary" ng-if="currentUser && currentUser.role === 'student' && d.status === 'active'" ng-click="openApplyModal(d)">
                      Apply Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 text-center py-4" ng-if="!drives || drives.length === 0">
            <div class="p-4 bg-white rounded border shadow-sm">
              <i class="bi bi-briefcase fs-2 text-muted mb-2 d-block"></i>
              <h6 class="fw-bold">No placement drives found matching criteria.</h6>
              <p class="text-muted small mb-0">Check back soon or adjust search filters.</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 5. ALUMNI DIRECTORY VIEW (PHASE 3)         -->
    <!-- ========================================== -->
    <div id="view-alumni" class="view-container section-compact" ng-show="activeView === 'alumni'">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div>
            <span class="text-primary fw-bold text-uppercase small">Network</span>
            <h3 class="fw-bold mb-0">Verified Kopargaon Alumni Directory</h3>
          </div>
        </div>

        <!-- Filter Card -->
        <div class="filter-card shadow-sm mb-3">
          <div class="row g-2">
            <div class="col-md-5">
              <input type="text" class="form-control form-control-sm" ng-model="alumniFilter.search" ng-change="loadAlumni()" placeholder="Search alumni by name, company, skills, or department...">
            </div>
            <div class="col-md-4">
              <select class="form-select form-select-sm" ng-model="alumniFilter.branch" ng-change="loadAlumni()">
                <option value="">All Engineering Departments</option>
                <option value="Computer">Computer Engineering</option>
                <option value="Information Technology">Information Technology</option>
                <option value="Electronics">Electronics & Telecommunication</option>
              </select>
            </div>
            <div class="col-md-3">
              <div class="form-check pt-1">
                <input class="form-check-input" type="checkbox" ng-model="alumniFilter.mentorshipOnly" ng-change="loadAlumni()" id="filterMentor">
                <label class="form-check-label small fw-semibold" for="filterMentor">Mentorship Available</label>
              </div>
            </div>
          </div>
        </div>

        <!-- Alumni Grid -->
        <div class="row g-3">
          <!-- Real Verified Kopargaon Alumni Card -->
          <div class="col-md-6 col-lg-4" ng-repeat="a in alumni">
            <div class="portal-card h-100 shadow-sm">
              <div class="card-top-accent" style="background: linear-gradient(135deg, #10b981 0%, #06b6d4 100%);"></div>
              <div class="p-3 d-flex flex-column h-100">
                <div class="d-flex align-items-center gap-3 mb-2">
                  <div class="sidebar-avatar shadow-sm" style="background: #4f46e5; color: white;">
                    {{a.name.charAt(0)}}
                  </div>
                  <div>
                    <h5 class="fw-bold mb-0 text-dark">{{a.name}}</h5>
                    <span class="badge bg-success-subtle text-success border border-success-subtle small fw-semibold">
                      <i class="bi bi-patch-check-fill me-1"></i>Verified Alumnus &bull; Batch {{a.graduation_year}}
                    </span>
                  </div>
                </div>

                <div class="p-2 bg-light rounded border mb-2 small">
                  <div class="fw-bold text-dark">{{a.job_role}} &bull; <span class="text-primary">{{a.company}}</span></div>
                  <div class="text-muted"><i class="bi bi-geo-alt me-1 text-danger"></i>{{a.location}}</div>
                  <div class="text-primary fw-semibold mt-1">
                    <i class="bi bi-hourglass-split me-1"></i>{{a.dynamic_experience || 'Experience calculated dynamically'}}
                  </div>
                </div>

                <div class="small text-muted mb-2">
                  <div class="text-truncate"><b>Department:</b> {{a.department || a.branch}}</div>
                  <div class="text-truncate"><b>Skills:</b> {{a.skills}}</div>
                </div>

                <p class="small text-muted flex-grow-1" style="font-size: 0.82rem; line-height: 1.4;">{{a.bio}}</p>

                <div class="pt-2 border-top d-flex justify-content-between align-items-center">
                  <a ng-if="a.linkedin" ng-href="{{a.linkedin}}" target="_blank" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-linkedin me-1"></i>LinkedIn Profile
                  </a>
                  <button class="btn btn-sm btn-success fw-bold" ng-click="openChatRequestModal(a)">
                    <i class="bi bi-chat-dots-fill me-1"></i>Request Chat
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Professional Placeholder Cards for Upcoming Alumni (Phase 3 Instructions) -->
          <div class="col-md-6 col-lg-4" ng-if="alumni.length <= 1">
            <div class="portal-card h-100 border-dashed" style="border: 2px dashed #cbd5e1; background: #fafafa;">
              <div class="p-4 d-flex flex-column justify-content-center align-items-center text-center h-100">
                <i class="bi bi-person-badge fs-1 text-muted opacity-50 mb-2"></i>
                <h6 class="fw-bold text-secondary mb-1">[ALUMNI DETAILS TO BE PROVIDED BY WEBSITE OWNER]</h6>
                <p class="small text-muted mb-3" style="max-width: 280px;">
                  Dedicated slot for Sanjivani University Kopargaon alumni records. Profiles are verified and published by portal administration.
                </p>
                <span class="badge bg-light text-muted border">[ALUMNI LINKEDIN PROFILE LINKS TO BE PROVIDED BY WEBSITE OWNER]</span>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4" ng-if="alumni.length <= 1">
            <div class="portal-card h-100 border-dashed" style="border: 2px dashed #cbd5e1; background: #fafafa;">
              <div class="p-4 d-flex flex-column justify-content-center align-items-center text-center h-100">
                <i class="bi bi-mortarboard fs-1 text-muted opacity-50 mb-2"></i>
                <h6 class="fw-bold text-secondary mb-1">[ALUMNI DETAILS TO BE PROVIDED BY WEBSITE OWNER]</h6>
                <p class="small text-muted mb-3" style="max-width: 280px;">
                  Upcoming alumni mentorship profile. Dynamic experience will be calculated automatically upon company joining date configuration.
                </p>
                <span class="badge bg-light text-muted border">[ALUMNI LINKEDIN PROFILE LINKS TO BE PROVIDED BY WEBSITE OWNER]</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 6. INTERVIEW PREPARATION HUB (PHASE 11)    -->
    <!-- ========================================== -->
    <div id="view-prep-hub" class="view-container section-compact" ng-show="activeView === 'prep-hub'">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div>
            <span class="text-primary fw-bold text-uppercase small">Interview Hub</span>
            <h3 class="fw-bold mb-0">Technical, HR & Aptitude Interview Preparation</h3>
          </div>
        </div>

        <!-- Categories & Search Filter -->
        <div class="filter-card shadow-sm mb-3">
          <div class="row g-2 align-items-center">
            <div class="col-md-6">
              <input type="text" class="form-control form-control-sm" ng-model="prepFilter.search" ng-change="loadPrepMaterials()" placeholder="Search question, keyword, or concept...">
            </div>
            <div class="col-md-6">
              <div class="d-flex gap-1 flex-wrap">
                <button class="btn btn-sm" ng-class="{'btn-primary': prepFilter.category === 'all', 'btn-outline-secondary': prepFilter.category !== 'all'}" ng-click="prepFilter.category = 'all'; loadPrepMaterials()">
                  All ({{prepMaterials.length}})
                </button>
                <button class="btn btn-sm" ng-class="{'btn-primary': prepFilter.category === 'Technical', 'btn-outline-secondary': prepFilter.category !== 'Technical'}" ng-click="prepFilter.category = 'Technical'; loadPrepMaterials()">
                  Technical
                </button>
                <button class="btn btn-sm" ng-class="{'btn-primary': prepFilter.category === 'Coding', 'btn-outline-secondary': prepFilter.category !== 'Coding'}" ng-click="prepFilter.category = 'Coding'; loadPrepMaterials()">
                  Coding
                </button>
                <button class="btn btn-sm" ng-class="{'btn-primary': prepFilter.category === 'HR', 'btn-outline-secondary': prepFilter.category !== 'HR'}" ng-click="prepFilter.category = 'HR'; loadPrepMaterials()">
                  HR & Behavioral
                </button>
                <button class="btn btn-sm" ng-class="{'btn-primary': prepFilter.category === 'Aptitude', 'btn-outline-secondary': prepFilter.category !== 'Aptitude'}" ng-click="prepFilter.category = 'Aptitude'; loadPrepMaterials()">
                  Aptitude
                </button>
                <button class="btn btn-sm" ng-class="{'btn-primary': prepFilter.category === 'Company-Specific', 'btn-outline-secondary': prepFilter.category !== 'Company-Specific'}" ng-click="prepFilter.category = 'Company-Specific'; loadPrepMaterials()">
                  TCS / Mass
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Questions List -->
        <div class="row g-3">
          <div class="col-md-6" ng-repeat="p in prepMaterials">
            <div class="card shadow-sm border rounded-3 p-3 h-100">
              <div class="d-flex justify-content-between align-items-start mb-2">
                <span class="badge bg-primary-subtle text-primary fw-bold">{{p.category}}</span>
                <span class="badge bg-light text-muted border small" ng-if="p.company_tag">{{p.company_tag}}</span>
              </div>
              <h6 class="fw-bold text-dark mb-2">{{p.title}}</h6>
              <div class="p-2 rounded bg-light border mb-2 small fw-semibold text-secondary">
                <i class="bi bi-question-circle-fill text-primary me-1"></i>{{p.question}}
              </div>
              <div class="small text-dark mb-2 flex-grow-1" style="white-space: pre-line; line-height: 1.45;">
                {{p.answer_guide}}
              </div>
              <div class="p-2 rounded bg-warning-subtle text-warning-emphasis border border-warning-subtle small" ng-if="p.tips">
                <i class="bi bi-lightbulb-fill text-warning me-1"></i><b>Interview Tip:</b> {{p.tips}}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 7. PLACEMENT STATISTICS VIEW               -->
    <!-- ========================================== -->
    <div id="view-statistics" class="view-container section-compact" ng-show="activeView === 'statistics'">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div>
            <span class="text-primary fw-bold text-uppercase small">Analytics</span>
            <h3 class="fw-bold mb-0">Placement Performance & Trends</h3>
          </div>
          <div class="dropdown">
            <button class="btn btn-outline-primary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
              <i class="bi bi-download me-1"></i>Export Placement Report
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow">
              <li><a class="dropdown-item" href="javascript:void(0)" ng-click="downloadReport('placements', 'pdf')"><i class="bi bi-file-earmark-pdf me-2 text-danger"></i>Export as PDF</a></li>
              <li><a class="dropdown-item" href="javascript:void(0)" ng-click="downloadReport('placements', 'csv')"><i class="bi bi-file-earmark-spreadsheet me-2 text-success"></i>Export as CSV</a></li>
            </ul>
          </div>
        </div>

        <div class="row g-3 mb-3">
          <div class="col-md-3 col-6">
            <div class="kpi-card text-center">
              <h3 class="fw-bold text-primary mb-0">{{kpis.placed_students || 14}}</h3>
              <small class="text-muted fw-semibold">Students Selected</small>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="kpi-card text-center">
              <h3 class="fw-bold text-success mb-0">18.0 LPA</h3>
              <small class="text-muted fw-semibold">Highest Package</small>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="kpi-card text-center">
              <h3 class="fw-bold text-info mb-0">12.5 LPA</h3>
              <small class="text-muted fw-semibold">Average Package</small>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="kpi-card text-center">
              <h3 class="fw-bold text-warning mb-0">{{kpis.total_companies || 8}}</h3>
              <small class="text-muted fw-semibold">Visiting Corporates</small>
            </div>
          </div>
        </div>

        <!-- Charts Grid -->
        <div class="row g-3">
          <div class="col-md-6">
            <div class="card shadow-sm border rounded-3 p-3">
              <h6 class="fw-bold mb-3"><i class="bi bi-pie-chart-fill text-primary me-2"></i>Department-wise Placement Distribution</h6>
              <div style="height: 260px; position: relative;">
                <canvas id="chartDepartment"></canvas>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="card shadow-sm border rounded-3 p-3">
              <h6 class="fw-bold mb-3"><i class="bi bi-bar-chart-fill text-success me-2"></i>Company-wise Offers Made</h6>
              <div style="height: 260px; position: relative;">
                <canvas id="chartCompany"></canvas>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <div class="card shadow-sm border rounded-3 p-3">
              <h6 class="fw-bold mb-3"><i class="bi bi-graph-up text-info me-2"></i>Year-over-Year Placement Package Trends</h6>
              <div style="height: 250px; position: relative;">
                <canvas id="chartSalary"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 8. STUDENT DASHBOARD (PHASE 4, 9, 11)      -->
    <!-- ========================================== -->
    <div id="view-student-dashboard" class="view-container" ng-show="activeView === 'student-dashboard'">
      <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">{{studentProfile.roll_no || 'Student'}}</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-header-label">Student Hub</li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#student-dashboard" ng-click="navigate('student-dashboard')"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-applications" ng-click="navigate('student-applications')"><i class="bi bi-file-earmark-text"></i>My Applications</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-profile" ng-click="navigate('student-profile')"><i class="bi bi-person-lines-fill"></i>Profile & Resumes</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#smart-matching" ng-click="navigate('smart-matching')"><i class="bi bi-stars"></i>Smart Job Matcher</a></li>
            <li class="sidebar-header-label">Portfolio & ATS</li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-portfolio" ng-click="navigate('student-portfolio')"><i class="bi bi-person-badge"></i>Portfolio Builder</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-ats" ng-click="navigate('student-ats')"><i class="bi bi-file-earmark-check"></i>ATS Resume Checker</a></li>
            <li class="sidebar-header-label">Mentorship & Referrals</li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-chat" ng-click="navigate('student-chat')"><i class="bi bi-chat-dots-fill"></i>Alumni Direct Chat</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#prep-hub" ng-click="navigate('prep-hub')"><i class="bi bi-journal-code"></i>Interview Prep Hub</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#alumni-referrals" ng-click="navigate('alumni-referrals')"><i class="bi bi-megaphone"></i>Alumni Referrals</a></li>
          </ul>
        </aside>

        <!-- Main Dashboard Content -->
        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Student Placement Dashboard</h4>
              <p class="page-subtitle">Welcome back, {{currentUser.name}} &bull; {{studentProfile.branch}}</p>
            </div>
            <div class="d-flex gap-2">
              <button class="btn btn-sm btn-outline-primary" ng-click="navigate('student-ats')">
                <i class="bi bi-file-earmark-check me-1"></i>Audit Resume
              </button>
              <button class="btn btn-sm btn-primary" ng-click="navigate('drives')">
                <i class="bi bi-briefcase me-1"></i>View Drives
              </button>
            </div>
          </div>

          <!-- Upcoming Interviews Alert Banner (Phase 9) -->
          <div class="alert alert-warning border-warning shadow-sm mb-3 d-flex align-items-center justify-content-between" ng-if="studentInterviews.length > 0">
            <div class="d-flex align-items-center gap-2">
              <i class="bi bi-alarm-fill fs-3 text-warning"></i>
              <div>
                <span class="fw-bold text-dark d-block">Upcoming Interview Alert!</span>
                <span class="small text-secondary">
                  You have {{studentInterviews.length}} scheduled interview(s). Latest: <b>{{studentInterviews[0].company_name}}</b> on <b>{{studentInterviews[0].interview_date}}</b> at <b>{{studentInterviews[0].interview_time}}</b>.
                </span>
              </div>
            </div>
            <a ng-if="studentInterviews[0].location_or_link" ng-href="{{studentInterviews[0].location_or_link}}" target="_blank" class="btn btn-sm btn-warning text-dark fw-bold">
              <i class="bi bi-camera-video me-1"></i>Join Interview
            </a>
          </div>

          <!-- Top Row: Placement Readiness Score & Quick KPIs -->
          <div class="row g-3 mb-3">
            <!-- Placement Readiness Score Gauge (Phase 11) -->
            <div class="col-lg-4 col-md-6">
              <div class="readiness-gauge-box h-100 shadow-sm">
                <div class="d-flex justify-content-between align-items-center mb-2">
                  <span class="fw-bold text-dark small text-uppercase">Placement Readiness</span>
                  <span class="badge" ng-class="'bg-' + readinessData.badge_color">{{readinessData.tier}}</span>
                </div>
                <div class="readiness-ring" ng-class="{'ready': readinessData.overall_score >= 80, 'moderate': readinessData.overall_score >= 60 && readinessData.overall_score < 80, 'needs-work': readinessData.overall_score < 60}">
                  {{readinessData.overall_score}}%
                </div>
                <p class="small text-muted mb-2">Composite evaluation based on resume, coding profiles, skills, and projects.</p>
                <div class="d-flex justify-content-center gap-1">
                  <button class="btn btn-sm btn-outline-primary py-0 px-2 small" ng-click="navigate('student-profile')">Boost Score</button>
                  <button class="btn btn-sm btn-outline-secondary py-0 px-2 small" ng-click="navigate('student-portfolio')">Portfolio</button>
                </div>
              </div>
            </div>

            <!-- Stats Widgets -->
            <div class="col-lg-8 col-md-6">
              <div class="row g-2 h-100">
                <div class="col-sm-6">
                  <div class="stat-widget">
                    <div class="stat-widget-info">
                      <h6>Applications Submitted</h6>
                      <div class="stat-value text-primary">{{studentApplications.length}}</div>
                    </div>
                    <i class="bi bi-file-earmark-check fs-2 text-primary opacity-50"></i>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="stat-widget">
                    <div class="stat-widget-info">
                      <h6>Interviews Scheduled</h6>
                      <div class="stat-value text-warning">{{studentInterviewsCount || 0}}</div>
                    </div>
                    <i class="bi bi-calendar2-check fs-2 text-warning opacity-50"></i>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="stat-widget">
                    <div class="stat-widget-info">
                      <h6>Selection Offers</h6>
                      <div class="stat-value text-success">{{studentSelectedCount || 0}}</div>
                    </div>
                    <i class="bi bi-award fs-2 text-success opacity-50"></i>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="stat-widget">
                    <div class="stat-widget-info">
                      <h6>Eligible Active Drives</h6>
                      <div class="stat-value text-info">{{studentEligibleDrives.length || 0}}</div>
                    </div>
                    <i class="bi bi-briefcase fs-2 text-info opacity-50"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Scheduled Interviews Details Table (Phase 9) -->
          <div class="card shadow-sm border rounded-3 mb-3" ng-if="studentInterviews.length > 0">
            <div class="card-header bg-white py-2 d-flex justify-content-between align-items-center">
              <span class="fw-bold small text-dark"><i class="bi bi-calendar-check me-1 text-primary"></i>Scheduled Interviews</span>
              <span class="badge bg-primary">{{studentInterviews.length}} Total</span>
            </div>
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Company</th>
                    <th>Role</th>
                    <th>Date & Time</th>
                    <th>Mode</th>
                    <th>Location / Link</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="iv in studentInterviews">
                    <td><b>{{iv.company_name}}</b></td>
                    <td>{{iv.job_designation}}</td>
                    <td>
                      <div><b>{{iv.interview_date}}</b></div>
                      <small class="text-muted">{{iv.interview_time}}</small>
                    </td>
                    <td><span class="badge bg-light text-dark border">{{iv.interview_mode}}</span></td>
                    <td>
                      <a ng-if="iv.location_or_link.startsWith('http')" ng-href="{{iv.location_or_link}}" target="_blank" class="btn btn-sm btn-outline-primary py-0 px-2">
                        <i class="bi bi-link-45deg me-1"></i>Join Link
                      </a>
                      <span ng-if="!iv.location_or_link.startsWith('http')" class="small text-muted">{{iv.location_or_link}}</span>
                    </td>
                    <td>
                      <span class="badge" ng-class="{'bg-warning-subtle text-warning-emphasis': iv.status === 'Scheduled', 'bg-success-subtle text-success': iv.status === 'Completed', 'bg-danger-subtle text-danger': iv.status === 'Cancelled'}">
                        {{iv.status}}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Recent Applications Table -->
          <div class="card shadow-sm border rounded-3">
            <div class="card-header bg-white py-2 d-flex justify-content-between align-items-center">
              <span class="fw-bold small text-dark"><i class="bi bi-clock-history me-1 text-primary"></i>Recent Drive Applications</span>
              <button class="btn btn-link btn-sm p-0 text-decoration-none small" ng-click="navigate('student-applications')">View All</button>
            </div>
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Company</th>
                    <th>Role</th>
                    <th>Applied Date</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="app in studentApplications.slice(0, 5)">
                    <td><b>{{app.company_name}}</b></td>
                    <td>{{app.job_role}}</td>
                    <td><small class="text-muted">{{app.applied_at | date:'mediumDate'}}</small></td>
                    <td>
                      <span class="badge-status" ng-class="'badge-' + app.status.toLowerCase()">{{app.status}}</span>
                    </td>
                  </tr>
                  <tr ng-if="studentApplications.length === 0">
                    <td colspan="4" class="text-center py-3 text-muted small">No applications submitted yet. Browse active placement drives to apply!</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 9. STUDENT APPLICATIONS VIEW               -->
    <!-- ========================================== -->
    <div id="view-student-applications" class="view-container" ng-show="activeView === 'student-applications'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Student</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#student-dashboard" ng-click="navigate('student-dashboard')"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#student-applications" ng-click="navigate('student-applications')"><i class="bi bi-file-earmark-text"></i>My Applications</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-profile" ng-click="navigate('student-profile')"><i class="bi bi-person-lines-fill"></i>Profile & Resumes</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#smart-matching" ng-click="navigate('smart-matching')"><i class="bi bi-stars"></i>Smart Job Matcher</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-portfolio" ng-click="navigate('student-portfolio')"><i class="bi bi-person-badge"></i>Portfolio Builder</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-ats" ng-click="navigate('student-ats')"><i class="bi bi-file-earmark-check"></i>ATS Resume Checker</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-chat" ng-click="navigate('student-chat')"><i class="bi bi-chat-dots-fill"></i>Alumni Direct Chat</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">My Application History</h4>
              <p class="page-subtitle">Track your placement drive progress through all recruitment rounds.</p>
            </div>
            <button class="btn btn-sm btn-primary" ng-click="navigate('drives')">Browse Drives</button>
          </div>

          <div class="card shadow-sm border rounded-3">
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Company Name</th>
                    <th>Job Role</th>
                    <th>Package</th>
                    <th>Applied Date</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="a in studentApplications">
                    <td><b>{{a.company_name}}</b></td>
                    <td>{{a.job_role}}</td>
                    <td><span class="badge bg-light text-dark border">{{a.package}} LPA</span></td>
                    <td><small class="text-muted">{{a.applied_at}}</small></td>
                    <td>
                      <span class="badge-status" ng-class="'badge-' + a.status.toLowerCase()">{{a.status}}</span>
                    </td>
                  </tr>
                  <tr ng-if="studentApplications.length === 0">
                    <td colspan="5" class="text-center py-4 text-muted small">No applications submitted yet.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 10. STUDENT PROFILE & RESUMES (PHASE 4)    -->
    <!-- ========================================== -->
    <div id="view-student-profile" class="view-container" ng-show="activeView === 'student-profile'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Student</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#student-dashboard" ng-click="navigate('student-dashboard')"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-applications" ng-click="navigate('student-applications')"><i class="bi bi-file-earmark-text"></i>My Applications</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#student-profile" ng-click="navigate('student-profile')"><i class="bi bi-person-lines-fill"></i>Profile & Resumes</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#smart-matching" ng-click="navigate('smart-matching')"><i class="bi bi-stars"></i>Smart Job Matcher</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-portfolio" ng-click="navigate('student-portfolio')"><i class="bi bi-person-badge"></i>Portfolio Builder</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-ats" ng-click="navigate('student-ats')"><i class="bi bi-file-earmark-check"></i>ATS Resume Checker</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-chat" ng-click="navigate('student-chat')"><i class="bi bi-chat-dots-fill"></i>Alumni Direct Chat</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Student Profile & Resume Manager</h4>
              <p class="page-subtitle">Manage your institutional academic records, coding links, and versioned resumes.</p>
            </div>
          </div>

          <div class="row g-3">
            <!-- Academic Profile Form -->
            <div class="col-lg-6">
              <div class="card shadow-sm border rounded-3 p-3 h-100">
                <h6 class="fw-bold mb-3"><i class="bi bi-person-badge text-primary me-2"></i>Academic & Contact Information</h6>
                <form ng-submit="saveStudentProfile()">
                  <div class="mb-2">
                    <label class="form-label small fw-semibold">Full Name</label>
                    <input type="text" class="form-control form-control-sm" ng-model="studentProfile.name" required>
                  </div>
                  <div class="row g-2 mb-2">
                    <div class="col-md-6">
                      <label class="form-label small fw-semibold">Roll Number</label>
                      <input type="text" class="form-control form-control-sm" ng-model="studentProfile.roll_no" readonly>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label small fw-semibold">Department / Branch</label>
                      <input type="text" class="form-control form-control-sm" ng-model="studentProfile.branch" required>
                    </div>
                  </div>
                  <div class="row g-2 mb-2">
                    <div class="col-md-6">
                      <label class="form-label small fw-semibold">CGPA</label>
                      <input type="number" step="0.01" class="form-control form-control-sm" ng-model="studentProfile.cgpa" required>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label small fw-semibold">Mobile Phone</label>
                      <input type="text" class="form-control form-control-sm" ng-model="studentProfile.phone" required>
                    </div>
                  </div>
                  <div class="mb-3">
                    <label class="form-label small fw-semibold">Technical Skills (comma-separated)</label>
                    <textarea class="form-control form-control-sm" rows="2" ng-model="studentProfile.skills" placeholder="Java, Spring Boot, React, MySQL, Data Structures..."></textarea>
                  </div>

                  <!-- Professional Coding Profiles (Phase 4) -->
                  <h6 class="fw-bold mb-2 pt-2 border-top"><i class="bi bi-code-slash text-success me-2"></i>Coding & Professional Profiles</h6>
                  <div class="mb-2">
                    <label class="form-label small fw-semibold"><i class="bi bi-github me-1"></i>GitHub Profile URL</label>
                    <input type="url" class="form-control form-control-sm" ng-model="studentProfile.github_url" placeholder="https://github.com/username">
                  </div>
                  <div class="mb-2">
                    <label class="form-label small fw-semibold"><i class="bi bi-terminal me-1 text-success"></i>HackerRank Profile URL</label>
                    <input type="url" class="form-control form-control-sm" ng-model="studentProfile.hackerrank_url" placeholder="https://hackerrank.com/username">
                  </div>
                  <div class="mb-3">
                    <label class="form-label small fw-semibold"><i class="bi bi-linkedin me-1 text-primary"></i>LinkedIn Profile URL</label>
                    <input type="url" class="form-control form-control-sm" ng-model="studentProfile.linkedin_url" placeholder="https://linkedin.com/in/username">
                  </div>

                  <button type="submit" class="btn btn-primary btn-sm fw-bold">
                    <i class="bi bi-save me-1"></i>Save Profile & Links
                  </button>
                </form>
              </div>
            </div>

            <!-- Resume Management Section (Phase 4) -->
            <div class="col-lg-6">
              <div class="card shadow-sm border rounded-3 p-3 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <h6 class="fw-bold mb-0"><i class="bi bi-file-earmark-pdf-fill text-danger me-2"></i>Resume Version Manager</h6>
                  <span class="badge bg-success-subtle text-success border border-success-subtle" ng-if="studentProfile.resume">
                    Active Resume Set
                  </span>
                </div>

                <!-- Upload New Version -->
                <div class="p-3 bg-light rounded border mb-3">
                  <label class="form-label small fw-semibold">Upload New Resume Version (PDF or DOCX, max 5MB)</label>
                  <div class="input-group input-group-sm">
                    <input type="file" class="form-control" id="newResumeVersionInput" accept=".pdf,.doc,.docx">
                    <button class="btn btn-primary" type="button" ng-click="uploadNewResumeVersion()" ng-disabled="resumeUploading">
                      <span ng-if="resumeUploading"><i class="bi bi-hourglass-split me-1"></i>Uploading...</span>
                      <span ng-if="!resumeUploading"><i class="bi bi-cloud-arrow-up me-1"></i>Upload Version</span>
                    </button>
                  </div>
                  <small class="text-muted d-block mt-1">Uploaded resumes are automatically parsed and versioned.</small>
                </div>

                <!-- Current Active Resume Box -->
                <div class="p-3 bg-primary-subtle text-primary rounded border border-primary-subtle mb-3" ng-if="studentProfile.resume">
                  <div class="d-flex justify-content-between align-items-center">
                    <div>
                      <span class="badge bg-primary text-white mb-1">Active for Recruitment</span>
                      <div class="fw-bold text-dark text-truncate">{{studentProfile.resume}}</div>
                      <small class="text-muted">Last Updated: {{studentProfile.resume_updated_at || 'Recently'}}</small>
                    </div>
                    <a ng-href="uploads/resumes/{{studentProfile.resume}}" target="_blank" class="btn btn-sm btn-outline-primary">
                      <i class="bi bi-eye me-1"></i>View
                    </a>
                  </div>
                </div>

                <!-- Version History Table -->
                <h6 class="fw-bold small text-dark mb-2">Resume Version History</h6>
                <div class="table-responsive">
                  <table class="table table-sm table-custom align-middle">
                    <thead>
                      <tr>
                        <th>Version</th>
                        <th>Original File</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr ng-repeat="r in resumeHistory">
                        <td><span class="badge bg-light text-dark border">v{{r.version_number || $index + 1}}</span></td>
                        <td class="text-truncate" style="max-width: 140px;" title="{{r.original_filename}}">{{r.original_filename}}</td>
                        <td>
                          <span class="badge bg-success" ng-if="r.is_active == 1">Active</span>
                          <span class="badge bg-light text-muted border" ng-if="r.is_active != 1">Archived</span>
                        </td>
                        <td>
                          <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-success py-0 px-2" title="Set Active" ng-if="r.is_active != 1" ng-click="setActiveResume(r.id)">
                              <i class="bi bi-check2"></i>
                            </button>
                            <a class="btn btn-outline-primary py-0 px-2" title="Download" ng-href="api/students/resume_manage.php?action=download&id={{r.id}}" target="_blank">
                              <i class="bi bi-download"></i>
                            </a>
                            <button class="btn btn-outline-danger py-0 px-2" title="Delete" ng-click="deleteResumeRecord(r.id)">
                              <i class="bi bi-trash"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                      <tr ng-if="resumeHistory.length === 0">
                        <td colspan="4" class="text-center py-3 text-muted small">No resume versions uploaded yet.</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 11. SMART JOB MATCHING (PHASE 11)          -->
    <!-- ========================================== -->
    <div id="view-smart-matching" class="view-container" ng-show="activeView === 'smart-matching'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Student</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#student-dashboard" ng-click="navigate('student-dashboard')"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-applications" ng-click="navigate('student-applications')"><i class="bi bi-file-earmark-text"></i>My Applications</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-profile" ng-click="navigate('student-profile')"><i class="bi bi-person-lines-fill"></i>Profile & Resumes</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#smart-matching" ng-click="navigate('smart-matching')"><i class="bi bi-stars"></i>Smart Job Matcher</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-portfolio" ng-click="navigate('student-portfolio')"><i class="bi bi-person-badge"></i>Portfolio Builder</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-ats" ng-click="navigate('student-ats')"><i class="bi bi-file-earmark-check"></i>ATS Resume Checker</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-chat" ng-click="navigate('student-chat')"><i class="bi bi-chat-dots-fill"></i>Alumni Direct Chat</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Smart Job Matching & Skill Gap Analyzer</h4>
              <p class="page-subtitle">AI-assisted drive matching based on your CGPA, branch, and technical skill set.</p>
            </div>
          </div>

          <div class="row g-3">
            <!-- Left Column: Matched Drives List -->
            <div class="col-lg-6">
              <div class="card shadow-sm border rounded-3 p-3">
                <h6 class="fw-bold mb-3"><i class="bi bi-stars text-warning me-2"></i>Matched Opportunities ({{smartMatches.length}})</h6>
                <div class="d-flex flex-column gap-2">
                  <div class="p-3 rounded border" ng-repeat="m in smartMatches" ng-class="{'border-primary bg-primary-subtle': selectedMatch.drive_id === m.drive_id, 'bg-white': selectedMatch.drive_id !== m.drive_id}" ng-click="selectMatchDrive(m)" style="cursor: pointer; transition: all 0.2s ease;">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                      <div>
                        <span class="badge bg-light text-dark border mb-1">{{m.company_name}}</span>
                        <h6 class="fw-bold mb-0 text-dark">{{m.job_role}}</h6>
                      </div>
                      <span class="badge fs-6" ng-class="{'bg-success': m.match_percentage >= 75, 'bg-warning text-dark': m.match_percentage >= 50 && m.match_percentage < 75, 'bg-danger': m.match_percentage < 50}">
                        {{m.match_percentage}}% Match
                      </span>
                    </div>
                    <div class="d-flex gap-2 small text-muted mb-2">
                      <span><i class="bi bi-geo-alt me-1"></i>{{m.location}}</span>
                      <span>&bull;</span>
                      <span><b>{{m.package}} LPA</b></span>
                    </div>
                    <div class="d-flex gap-1 flex-wrap">
                      <span class="badge bg-success-subtle text-success small" ng-if="m.cgpa_eligible"><i class="bi bi-check me-1"></i>CGPA Eligible</span>
                      <span class="badge bg-danger-subtle text-danger small" ng-if="!m.cgpa_eligible"><i class="bi bi-x me-1"></i>Below CGPA cutoff</span>
                      <span class="badge bg-success-subtle text-success small" ng-if="m.branch_eligible"><i class="bi bi-check me-1"></i>Branch Match</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Right Column: Skill Gap Breakdown & Learning Roadmap -->
            <div class="col-lg-6" ng-if="selectedMatch">
              <div class="card shadow-sm border rounded-3 p-3">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <div>
                    <h5 class="fw-bold mb-0 text-dark">{{selectedMatch.company_name}} &bull; {{selectedMatch.job_role}}</h5>
                    <small class="text-muted">Detailed Skill Gap & Preparation Roadmap</small>
                  </div>
                  <button class="btn btn-primary btn-sm" ng-click="navigate('drives')">View Drive</button>
                </div>

                <!-- Matched Skills -->
                <div class="mb-3">
                  <span class="fw-bold small text-dark d-block mb-1"><i class="bi bi-check-circle-fill text-success me-1"></i>Your Matching Skills ({{selectedMatch.matching_skills.length}})</span>
                  <div class="d-flex gap-1 flex-wrap">
                    <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1" ng-repeat="sk in selectedMatch.matching_skills">{{sk}}</span>
                    <span class="small text-muted" ng-if="selectedMatch.matching_skills.length === 0">No skills currently matching drive requirements.</span>
                  </div>
                </div>

                <!-- Missing Skills -->
                <div class="mb-3">
                  <span class="fw-bold small text-dark d-block mb-1"><i class="bi bi-exclamation-triangle-fill text-warning me-1"></i>Missing Drive Skills ({{selectedMatch.missing_skills.length}})</span>
                  <div class="d-flex gap-1 flex-wrap">
                    <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle px-2 py-1" ng-repeat="sk in selectedMatch.missing_skills">{{sk}}</span>
                  </div>
                </div>

                <!-- Recommended Learning Roadmap -->
                <h6 class="fw-bold small text-dark mb-2 pt-2 border-top"><i class="bi bi-map-fill text-primary me-1"></i>Recommended Learning Roadmap</h6>
                <div class="d-flex flex-column gap-2">
                  <div class="p-2 bg-light rounded border small" ng-repeat="rm in selectedMatch.learning_roadmap">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                      <b>Learn {{rm.skill}}</b>
                      <span class="badge" ng-class="{'bg-danger': rm.priority === 'High', 'bg-warning text-dark': rm.priority !== 'High'}">{{rm.priority}} Priority</span>
                    </div>
                    <p class="text-muted mb-0" style="font-size: 0.8rem;">{{rm.suggestion}}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 12. REDESIGNED COMPACT ATS RESUME CHECKER  -->
    <!-- (PHASE 5: NO EXCESSIVE WHITESPACE)         -->
    <!-- ========================================== -->
    <div id="view-student-ats" class="view-container" ng-show="activeView === 'student-ats'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Student</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#student-dashboard" ng-click="navigate('student-dashboard')"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-applications" ng-click="navigate('student-applications')"><i class="bi bi-file-earmark-text"></i>My Applications</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-profile" ng-click="navigate('student-profile')"><i class="bi bi-person-lines-fill"></i>Profile & Resumes</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#smart-matching" ng-click="navigate('smart-matching')"><i class="bi bi-stars"></i>Smart Job Matcher</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-portfolio" ng-click="navigate('student-portfolio')"><i class="bi bi-person-badge"></i>Portfolio Builder</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#student-ats" ng-click="navigate('student-ats')"><i class="bi bi-file-earmark-check"></i>ATS Resume Checker</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-chat" ng-click="navigate('student-chat')"><i class="bi bi-chat-dots-fill"></i>Alumni Direct Chat</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">ATS Resume Compatibility Checker</h4>
              <p class="page-subtitle">Evaluate keyword match, structural formatting, and job description alignment.</p>
            </div>
            <button class="btn btn-sm btn-outline-secondary" ng-click="downloadAtsReportPdf()" ng-if="atsAnalysis">
              <i class="bi bi-printer me-1"></i>Print / Save Report
            </button>
          </div>

          <!-- Indicative Score Disclaimer Banner (Phase 5 Requirement) -->
          <div class="alert alert-info py-2 px-3 small border-info mb-3">
            <i class="bi bi-info-circle-fill text-primary me-2"></i>
            <b>Disclaimer:</b> The ATS compatibility score is an indicative analytical estimation calculated based on industry parsing rules. It is not an actual score from any employer's proprietary ATS software.
          </div>

          <div class="row g-3">
            <!-- Left Column: Upload Dropzone & Score Gauge -->
            <div class="col-lg-4">
              <div class="ats-compact-card mb-3">
                <h6 class="fw-bold mb-2"><i class="bi bi-cloud-arrow-up text-primary me-2"></i>Upload & Audit Resume</h6>
                <div class="ats-upload-dropzone mb-2" onclick="document.getElementById('atsFileInputDirect').click()">
                  <i class="bi bi-file-earmark-arrow-up fs-2 text-primary mb-1 d-block"></i>
                  <span class="fw-bold small d-block">Click to Select Resume File</span>
                  <small class="text-muted" style="font-size: 0.75rem;">Supports PDF & DOCX (Max 5MB)</small>
                  <input type="file" id="atsFileInputDirect" class="d-none" accept=".pdf,.doc,.docx" onchange="angular.element(this).scope().uploadAtsResumeFile(this.files)">
                </div>

                <div class="text-center" ng-if="atsUploading">
                  <div class="spinner-border spinner-border-sm text-primary me-1" role="status"></div>
                  <small class="text-primary fw-bold">Parsing & auditing text...</small>
                </div>

                <!-- Score Gauge -->
                <div class="text-center pt-2 border-top" ng-if="atsAnalysis">
                  <div class="ats-score-gauge-compact" ng-class="{'excellent': atsAnalysis.overall_score >= 80, 'good': atsAnalysis.overall_score >= 60 && atsAnalysis.overall_score < 80, 'needs-work': atsAnalysis.overall_score < 60}">
                    <span class="ats-score-value-compact">{{atsAnalysis.overall_score}}</span>
                    <small style="font-size: 0.65rem; font-weight: 700;">OUT OF 100</small>
                  </div>
                  <div class="fw-bold small text-dark">{{atsActiveResume.original_filename}}</div>
                  <small class="text-muted">Analyzed: {{atsAnalysis.analyzed_at || 'Just now'}}</small>
                </div>
              </div>

              <!-- Upload History Mini-List -->
              <div class="ats-compact-card" ng-if="atsResumes.length > 0">
                <span class="fw-bold small text-dark d-block mb-2"><i class="bi bi-clock-history me-1"></i>Previous Audits</span>
                <div class="list-group list-group-flush small">
                  <a href="javascript:void(0)" class="list-group-item list-group-item-action p-2 d-flex justify-content-between align-items-center" ng-repeat="r in atsResumes" ng-click="selectAtsResume(r)">
                    <span class="text-truncate" style="max-width: 160px;">{{r.original_filename}}</span>
                    <span class="badge bg-primary">{{r.latest_analysis.overall_score}}%</span>
                  </a>
                </div>
              </div>
            </div>

            <!-- Right Column: Section Breakdown & Feedback -->
            <div class="col-lg-8" ng-if="atsAnalysis">
              <!-- Section Progress Bars -->
              <div class="ats-compact-card mb-3">
                <h6 class="fw-bold mb-3"><i class="bi bi-ui-checks text-success me-2"></i>Section-by-Section ATS Breakdown</h6>
                <div class="row g-2">
                  <div class="col-md-6" ng-repeat="(sec, score) in atsAnalysis.section_scores">
                    <div class="d-flex justify-content-between small fw-semibold text-secondary mb-1">
                      <span class="text-capitalize">{{sec.replace('_', ' ')}}</span>
                      <span>{{score}}/10</span>
                    </div>
                    <div class="progress" style="height: 6px;">
                      <div class="progress-bar" ng-class="{'bg-success': score >= 8, 'bg-primary': score >= 6 && score < 8, 'bg-warning': score < 6}" style="width: {{score * 10}}%;"></div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Strengths & Suggestions -->
              <div class="row g-2 mb-3">
                <div class="col-md-6">
                  <div class="ats-compact-card h-100">
                    <h6 class="fw-bold small text-success mb-2"><i class="bi bi-check-circle-fill me-1"></i>Resume Strengths</h6>
                    <ul class="list-unstyled small text-muted mb-0">
                      <li class="mb-1" ng-repeat="st in atsAnalysis.strengths">&bull; {{st}}</li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="ats-compact-card h-100">
                    <h6 class="fw-bold small text-warning mb-2"><i class="bi bi-exclamation-triangle-fill me-1"></i>Recommendations</h6>
                    <ul class="list-unstyled small text-muted mb-0">
                      <li class="mb-1" ng-repeat="sug in atsAnalysis.suggestions">&bull; {{sug}}</li>
                    </ul>
                  </div>
                </div>
              </div>

              <!-- Job Description Matcher Card -->
              <div class="ats-compact-card">
                <h6 class="fw-bold mb-2"><i class="bi bi-briefcase text-primary me-2"></i>Compare Against Job Description</h6>
                <div class="row g-2 mb-2">
                  <div class="col-md-6">
                    <input type="text" class="form-control form-control-sm" ng-model="atsJD.job_company" placeholder="Target Company (e.g., TCS)">
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control form-control-sm" ng-model="atsJD.job_title" placeholder="Job Title (e.g., Software Engineer)">
                  </div>
                </div>
                <div class="mb-2">
                  <textarea class="form-control form-control-sm" rows="3" ng-model="atsJD.job_description" placeholder="Paste full job description text here to check matching keywords and technical compatibility..."></textarea>
                </div>
                <button class="btn btn-primary btn-sm fw-bold" ng-click="compareWithJobDescription()" ng-disabled="atsMatching">
                  <span ng-if="atsMatching"><i class="bi bi-hourglass-split me-1"></i>Comparing...</span>
                  <span ng-if="!atsMatching"><i class="bi bi-search me-1"></i>Run Job Match Audit</span>
                </button>

                <!-- JD Comparison Result -->
                <div class="mt-3 p-3 bg-light rounded border" ng-if="atsMatchResult">
                  <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="fw-bold small text-dark">Job Fit Score</span>
                    <span class="badge bg-success fs-6">{{atsMatchResult.match_percentage}}% Match</span>
                  </div>
                  <div class="small mb-2">
                    <b>Matching Skills:</b>
                    <span class="badge bg-success-subtle text-success me-1" ng-repeat="sk in atsMatchResult.matching_skills">{{sk}}</span>
                  </div>
                  <div class="small">
                    <b>Missing Keywords:</b>
                    <span class="badge bg-warning-subtle text-warning-emphasis me-1" ng-repeat="kw in atsMatchResult.missing_keywords">{{kw}}</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Empty State when no analysis yet -->
            <div class="col-lg-8 text-center py-5" ng-if="!atsAnalysis">
              <div class="p-5 bg-white rounded border shadow-sm">
                <i class="bi bi-file-earmark-check fs-1 text-primary opacity-50 mb-2 d-block"></i>
                <h5 class="fw-bold">No Resume Analyzed Yet</h5>
                <p class="text-muted small mb-3">Upload your PDF or DOCX resume to view an instant ATS score breakdown, missing keywords, and section readability audit.</p>
                <button class="btn btn-primary btn-sm" onclick="document.getElementById('atsFileInputDirect').click()">
                  <i class="bi bi-cloud-arrow-up me-1"></i>Select Resume File
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 13. STUDENT-ALUMNI DIRECT CHAT VIEW        -->
    <!-- (PHASE 8: REQUEST & RESPONSE WORKFLOW)     -->
    <!-- ========================================== -->
    <div id="view-student-chat" class="view-container" ng-show="activeView === 'student-chat' || activeView === 'alumni-chat'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">{{currentUser.role | uppercase}}</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item" ng-if="currentUser.role === 'student'"><a class="sidebar-link" href="#student-dashboard" ng-click="navigate('student-dashboard')"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
            <li class="sidebar-item" ng-if="currentUser.role === 'alumni'"><a class="sidebar-link" href="#alumni-dashboard" ng-click="navigate('alumni-dashboard')"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="javascript:void(0)"><i class="bi bi-chat-dots-fill"></i>Direct Messages</a></li>
            <li class="sidebar-item" ng-if="currentUser.role === 'student'"><a class="sidebar-link" href="#alumni" ng-click="navigate('alumni')"><i class="bi bi-people"></i>Browse Mentors</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Direct Mentorship Chat System</h4>
              <p class="page-subtitle">Secure institutional communication between Sanjivani students and verified alumni.</p>
            </div>
          </div>

          <div class="chat-container">
            <!-- Threads List -->
            <div class="chat-sidebar">
              <div class="p-2 border-bottom bg-light fw-bold small text-dark">
                <i class="bi bi-people me-1"></i>Conversations ({{chatRequests.length}})
              </div>
              <div class="chat-thread-list">
                <div class="chat-thread-item" ng-repeat="th in chatRequests" ng-class="{'active': activeChatThread.id === th.id}" ng-click="openChatThread(th)">
                  <div class="sidebar-avatar" style="width:34px; height:34px; font-size:0.85rem; background: #4f46e5; color: white;">
                    {{(th.alumni_name || th.student_name || 'U').charAt(0)}}
                  </div>
                  <div class="overflow-hidden flex-grow-1">
                    <div class="fw-bold small text-truncate">{{th.alumni_name || th.student_name}}</div>
                    <small class="text-muted d-block text-truncate" style="font-size: 0.75rem;">{{th.company || th.branch || 'Sanjivani'}}</small>
                  </div>
                  <span class="badge" ng-class="{'bg-success': th.status === 'accepted', 'bg-warning text-dark': th.status === 'pending', 'bg-danger': th.status === 'rejected'}">
                    {{th.status}}
                  </span>
                </div>
                <div class="p-3 text-center text-muted small" ng-if="chatRequests.length === 0">
                  No active chat requests. Browse Alumni Directory to request mentorship!
                </div>
              </div>
            </div>

            <!-- Chat Messaging Area -->
            <div class="chat-main-area">
              <div class="p-3 border-bottom bg-white d-flex justify-content-between align-items-center" ng-if="activeChatThread">
                <div>
                  <h6 class="fw-bold mb-0 text-dark">{{activeChatThread.alumni_name || activeChatThread.student_name}}</h6>
                  <small class="text-muted">{{activeChatThread.company || activeChatThread.department || 'Mentorship Chat'}}</small>
                </div>
                <div class="d-flex gap-2 align-items-center">
                  <!-- Alumni Action: Accept / Reject if Pending -->
                  <div ng-if="currentUser.role === 'alumni' && activeChatThread.status === 'pending'">
                    <button class="btn btn-sm btn-success py-0 px-2" ng-click="respondChatRequest(activeChatThread, 'accepted')">Accept Request</button>
                    <button class="btn btn-sm btn-outline-danger py-0 px-2" ng-click="respondChatRequest(activeChatThread, 'rejected')">Decline</button>
                  </div>
                  <span class="badge bg-warning text-dark" ng-if="currentUser.role === 'student' && activeChatThread.status === 'pending'">Pending Alumni Approval</span>
                </div>
              </div>

              <!-- Messages List -->
              <div class="chat-messages-scroll" id="chatMessagesScroll" ng-if="activeChatThread">
                <div class="p-3 bg-white rounded border text-center small text-muted mb-2">
                  <i class="bi bi-shield-check text-success me-1"></i>
                  <b>Institutional Safety:</b> Maintain professional communication. You can flag inappropriate messages for admin review.
                </div>

                <!-- Initial request note -->
                <div class="chat-bubble theirs mb-2">
                  <small class="text-primary fw-bold d-block">Initial Request Note:</small>
                  {{activeChatThread.message}}
                </div>

                <div class="chat-bubble" ng-repeat="m in chatMessages" ng-class="{'mine': m.sender_id == currentUser.id, 'theirs': m.sender_id != currentUser.id}">
                  <div class="d-flex justify-content-between align-items-center mb-1">
                    <small class="fw-bold" style="font-size: 0.75rem;">{{m.sender_name}}</small>
                    <button class="btn btn-link btn-sm p-0 text-muted" title="Report message" ng-if="m.sender_id != currentUser.id" ng-click="reportChat(m)" style="font-size: 0.7rem;">
                      <i class="bi bi-flag"></i>
                    </button>
                  </div>
                  <div>{{m.message}}</div>
                  <div class="chat-time-stamp">{{m.created_at | date:'shortTime'}}</div>
                </div>

                <div class="text-center py-4 text-muted small" ng-if="activeChatThread.status === 'accepted' && chatMessages.length === 0">
                  Chat connection is active! Send your first message below.
                </div>
              </div>

              <!-- Message Input Bar -->
              <div class="chat-input-bar" ng-if="activeChatThread && activeChatThread.status === 'accepted'">
                <input type="text" class="form-control form-control-sm" ng-model="newChatMessage" ng-keydown="$event.keyCode === 13 && sendChatMessage()" placeholder="Type a professional message...">
                <button class="btn btn-primary btn-sm px-3" ng-click="sendChatMessage()">
                  <i class="bi bi-send-fill me-1"></i>Send
                </button>
              </div>

              <!-- Blocked or Pending Warning -->
              <div class="p-3 bg-light text-center small text-muted border-top" ng-if="activeChatThread && activeChatThread.status !== 'accepted'">
                Direct messaging is locked until the alumni mentor accepts the request.
              </div>

              <!-- Empty state when no thread selected -->
              <div class="d-flex justify-content-center align-items-center h-100 text-muted small" ng-if="!activeChatThread">
                Select a conversation from the left sidebar to start messaging.
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 14. ALUMNI REFERRALS VIEW (PHASE 11)       -->
    <!-- ========================================== -->
    <div id="view-alumni-referrals" class="view-container section-compact" ng-show="activeView === 'alumni-referrals'">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div>
            <span class="text-primary fw-bold text-uppercase small">Career Opportunities</span>
            <h3 class="fw-bold mb-0">Alumni Employee Referral Network</h3>
          </div>
        </div>

        <!-- Alumni Post Referral Box -->
        <div class="card shadow-sm border rounded-3 p-3 mb-3" ng-if="currentUser && (currentUser.role === 'alumni' || currentUser.role === 'admin')">
          <h6 class="fw-bold mb-2"><i class="bi bi-megaphone-fill text-primary me-2"></i>Post Internal Job Referral for Students</h6>
          <form ng-submit="publishAlumniReferral()">
            <div class="row g-2 mb-2">
              <div class="col-md-4">
                <input type="text" class="form-control form-control-sm" ng-model="newReferralForm.company_name" placeholder="Hiring Company (e.g. TCS)" required>
              </div>
              <div class="col-md-4">
                <input type="text" class="form-control form-control-sm" ng-model="newReferralForm.job_title" placeholder="Job Title (e.g. Associate Engineer)" required>
              </div>
              <div class="col-md-4">
                <input type="url" class="form-control form-control-sm" ng-model="newReferralForm.job_url" placeholder="Official Job Posting URL">
              </div>
            </div>
            <div class="mb-2">
              <textarea class="form-control form-control-sm" rows="2" ng-model="newReferralForm.requirements" placeholder="Eligibility & Skills required for internal referral..." required></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-sm fw-bold">Post Referral Opportunity</button>
          </form>
        </div>

        <!-- Referrals Listing -->
        <div class="row g-3">
          <div class="col-md-6 col-lg-4" ng-repeat="r in alumniReferrals">
            <div class="card shadow-sm border rounded-3 p-3 h-100">
              <div class="d-flex justify-content-between align-items-start mb-2">
                <div>
                  <span class="badge bg-light text-dark border mb-1">{{r.company_name}}</span>
                  <h6 class="fw-bold mb-0 text-dark">{{r.job_title}}</h6>
                </div>
                <span class="badge bg-success-subtle text-success border border-success-subtle">Referral Active</span>
              </div>
              <div class="small text-muted mb-2">
                <div><i class="bi bi-person me-1"></i>Posted by <b>{{r.alumni_name}}</b> ({{r.alumni_company}})</div>
                <div><i class="bi bi-geo-alt me-1 text-danger"></i>{{r.location || 'Pune / Hybrid'}}</div>
              </div>
              <div class="p-2 rounded bg-light border small text-secondary flex-grow-1 mb-3">
                <b>Requirements:</b> {{r.requirements}}
              </div>
              <div class="pt-2 border-top d-flex justify-content-between align-items-center">
                <a ng-if="r.job_url" ng-href="{{r.job_url}}" target="_blank" class="btn btn-sm btn-outline-secondary py-0 px-2 small">
                  Job Link <i class="bi bi-box-arrow-up-right ms-1"></i>
                </a>
                <button class="btn btn-sm btn-primary" ng-if="currentUser && currentUser.role === 'student'" ng-disabled="r.has_applied" ng-click="applyForReferral(r)">
                  <span ng-if="r.has_applied"><i class="bi bi-check-circle me-1"></i>Applied</span>
                  <span ng-if="!r.has_applied"><i class="bi bi-send me-1"></i>Request Referral</span>
                </button>
              </div>
            </div>
          </div>
          <div class="col-12 text-center py-4 text-muted small" ng-if="alumniReferrals.length === 0">
            No referral openings posted currently. Verified alumni regularly post internal job opportunities here.
          </div>
        </div>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 15. ALUMNI DASHBOARD & PROFILE             -->
    <!-- ========================================== -->
    <div id="view-alumni-dashboard" class="view-container" ng-show="activeView === 'alumni-dashboard'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Alumni Mentor</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link active" href="#alumni-dashboard" ng-click="navigate('alumni-dashboard')"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#alumni-profile" ng-click="navigate('alumni-profile')"><i class="bi bi-person"></i>My Profile</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#alumni-chat" ng-click="navigate('alumni-chat')"><i class="bi bi-chat-dots-fill"></i>Student Chat Requests</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#alumni-referrals" ng-click="navigate('alumni-referrals')"><i class="bi bi-megaphone"></i>Post Job Referral</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Alumni Mentor Dashboard</h4>
              <p class="page-subtitle">Sanjivani University Kopargaon Alumni Mentorship Network</p>
            </div>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-4">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Pending Mentorship Requests</h6>
                  <div class="stat-value text-warning">{{alumniPendingCount || 0}}</div>
                </div>
                <i class="bi bi-hourglass-split fs-2 text-warning opacity-50"></i>
              </div>
            </div>
            <div class="col-md-4">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Active Mentees</h6>
                  <div class="stat-value text-success">{{alumniAcceptedCount || 0}}</div>
                </div>
                <i class="bi bi-chat-heart fs-2 text-success opacity-50"></i>
              </div>
            </div>
            <div class="col-md-4">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Total Requests Received</h6>
                  <div class="stat-value text-primary">{{chatRequests.length || 0}}</div>
                </div>
                <i class="bi bi-people fs-2 text-primary opacity-50"></i>
              </div>
            </div>
          </div>

          <div class="card shadow-sm border rounded-3">
            <div class="card-header bg-white py-2 fw-bold small text-dark">Recent Student Chat Requests</div>
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Student Name</th>
                    <th>Branch</th>
                    <th>CGPA</th>
                    <th>Request Note</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="r in chatRequests">
                    <td><b>{{r.student_name}}</b></td>
                    <td>{{r.branch}}</td>
                    <td><span class="badge bg-light text-dark border">{{r.cgpa}}</span></td>
                    <td class="small text-truncate" style="max-width: 220px;">{{r.message}}</td>
                    <td>
                      <span class="badge" ng-class="{'bg-warning text-dark': r.status === 'pending', 'bg-success': r.status === 'accepted', 'bg-danger': r.status === 'rejected'}">{{r.status}}</span>
                    </td>
                    <td>
                      <button class="btn btn-sm btn-outline-primary py-0 px-2" ng-click="navigate('alumni-chat')">Open Chat</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Alumni Profile Edit (Phase 3: Dynamic Experience & Joining Date) -->
    <div id="view-alumni-profile" class="view-container" ng-show="activeView === 'alumni-profile'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Alumni</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#alumni-dashboard" ng-click="navigate('alumni-dashboard')"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#alumni-profile" ng-click="navigate('alumni-profile')"><i class="bi bi-person"></i>My Profile</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#alumni-chat" ng-click="navigate('alumni-chat')"><i class="bi bi-chat-dots-fill"></i>Student Chat Requests</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Alumni Profile Management</h4>
              <p class="page-subtitle">Update your professional experience, company joining date, and mentorship settings.</p>
            </div>
          </div>

          <div class="card shadow-sm border rounded-3 p-3" style="max-width: 720px;">
            <form ng-submit="saveAlumniProfile()">
              <div class="row g-2 mb-2">
                <div class="col-md-6">
                  <label class="form-label small fw-semibold">Graduation Year</label>
                  <input type="number" class="form-control form-control-sm" ng-model="alumniProfile.graduation_year" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-semibold">Engineering Department</label>
                  <input type="text" class="form-control form-control-sm" ng-model="alumniProfile.department" placeholder="Department of Computer Engineering, Sanjivani Kopargaon" required>
                </div>
              </div>

              <div class="row g-2 mb-2">
                <div class="col-md-6">
                  <label class="form-label small fw-semibold">Current Employer / Company</label>
                  <input type="text" class="form-control form-control-sm" ng-model="alumniProfile.company" placeholder="Tata Consultancy Services" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-semibold">Current Job Designation</label>
                  <input type="text" class="form-control form-control-sm" ng-model="alumniProfile.job_role" placeholder="Senior Software Engineer" required>
                </div>
              </div>

              <!-- Automatic Experience Calculation Input (Phase 3 Requirement) -->
              <div class="row g-2 mb-2">
                <div class="col-md-6">
                  <label class="form-label small fw-semibold"><i class="bi bi-calendar-event me-1 text-primary"></i>Company Joining Date</label>
                  <input type="date" class="form-control form-control-sm" ng-model="alumniProfile.joining_date" required>
                  <small class="text-muted" style="font-size: 0.72rem;">Experience is calculated automatically from this date.</small>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-semibold">Current Work Location</label>
                  <input type="text" class="form-control form-control-sm" ng-model="alumniProfile.location" placeholder="Kopargaon / Pune" required>
                </div>
              </div>

              <div class="mb-2">
                <label class="form-label small fw-semibold">LinkedIn Profile URL</label>
                <input type="url" class="form-control form-control-sm" ng-model="alumniProfile.linkedin" placeholder="https://linkedin.com/in/username">
              </div>

              <div class="mb-2">
                <label class="form-label small fw-semibold">Technical Skills</label>
                <input type="text" class="form-control form-control-sm" ng-model="alumniProfile.skills" placeholder="Java, Spring Boot, MySQL, Cloud Architecture">
              </div>

              <div class="mb-3">
                <label class="form-label small fw-semibold">Bio / Advice for Students</label>
                <textarea class="form-control form-control-sm" rows="3" ng-model="alumniProfile.bio"></textarea>
              </div>

              <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" ng-model="alumniProfile.available_for_mentorship" id="checkMentor">
                <label class="form-check-label small fw-semibold" for="checkMentor">Available for Student Mentorship & Chat Requests</label>
              </div>

              <button type="submit" class="btn btn-primary btn-sm fw-bold">Save Alumni Profile</button>
            </form>
          </div>
        </main>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 16. PLACEMENT OFFICER WORKFLOW             -->
    <!-- ========================================== -->
    <div id="view-officer-dashboard" class="view-container" ng-show="activeView === 'officer-dashboard'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">TPO Head</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link active" href="#officer-dashboard" ng-click="navigate('officer-dashboard')"><i class="bi bi-speedometer2"></i>TPO Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-drives" ng-click="navigate('officer-drives')"><i class="bi bi-briefcase"></i>Manage Drives</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-applications" ng-click="navigate('officer-applications')"><i class="bi bi-file-earmark-person"></i>Applications</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-interviews" ng-click="navigate('officer-interviews')"><i class="bi bi-calendar-check"></i>Interviews Schedule</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-placements" ng-click="navigate('officer-placements')"><i class="bi bi-award"></i>Placements</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Training & Placement Cell Administration</h4>
              <p class="page-subtitle">Manage campus placement drives, candidate shortlisting, and corporate coordination.</p>
            </div>
            <button class="btn btn-sm btn-primary" ng-click="openDriveModal()"><i class="bi bi-plus-circle me-1"></i>Create Drive</button>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-3 col-6">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Registered Companies</h6>
                  <div class="stat-value text-primary">{{kpis.total_companies || 8}}</div>
                </div>
                <i class="bi bi-buildings fs-2 text-primary opacity-50"></i>
              </div>
            </div>
            <div class="col-md-3 col-6">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Students Selected</h6>
                  <div class="stat-value text-success">{{kpis.placed_students || 14}}</div>
                </div>
                <i class="bi bi-award fs-2 text-success opacity-50"></i>
              </div>
            </div>
            <div class="col-md-3 col-6">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Highest Package</h6>
                  <div class="stat-value text-info">18.0 LPA</div>
                </div>
                <i class="bi bi-cash-stack fs-2 text-info opacity-50"></i>
              </div>
            </div>
            <div class="col-md-3 col-6">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Placement Rate</h6>
                  <div class="stat-value text-warning">86%</div>
                </div>
                <i class="bi bi-pie-chart fs-2 text-warning opacity-50"></i>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Officer Manage Drives -->
    <div id="view-officer-drives" class="view-container" ng-show="activeView === 'officer-drives'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">TPO Head</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-dashboard" ng-click="navigate('officer-dashboard')"><i class="bi bi-speedometer2"></i>TPO Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#officer-drives" ng-click="navigate('officer-drives')"><i class="bi bi-briefcase"></i>Manage Drives</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-applications" ng-click="navigate('officer-applications')"><i class="bi bi-file-earmark-person"></i>Applications</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-interviews" ng-click="navigate('officer-interviews')"><i class="bi bi-calendar-check"></i>Interviews Schedule</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Manage Placement Drives</h4>
              <p class="page-subtitle">Publish, edit, and coordinate recruitment drives for Kopargaon campus.</p>
            </div>
            <button class="btn btn-sm btn-primary" ng-click="openDriveModal()"><i class="bi bi-plus-circle me-1"></i>Add Drive</button>
          </div>

          <div class="card shadow-sm border rounded-3">
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Company</th>
                    <th>Role</th>
                    <th>Package</th>
                    <th>Drive Date</th>
                    <th>Deadline</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="d in officerDrives">
                    <td><b>{{d.company_name}}</b></td>
                    <td>{{d.job_role}}</td>
                    <td>{{d.package}} LPA</td>
                    <td>{{d.drive_date}}</td>
                    <td>{{d.deadline}}</td>
                    <td><span class="badge" ng-class="{'bg-success': d.status === 'active', 'bg-secondary': d.status !== 'active'}">{{d.status}}</span></td>
                    <td>
                      <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary py-0 px-2" ng-click="openDriveModal(d)"><i class="bi bi-pencil"></i></button>
                        <button class="btn btn-outline-danger py-0 px-2" ng-click="deleteDrive(d)"><i class="bi bi-trash"></i></button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Officer Manage Applications -->
    <div id="view-officer-applications" class="view-container" ng-show="activeView === 'officer-applications'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">TPO Head</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-dashboard" ng-click="navigate('officer-dashboard')"><i class="bi bi-speedometer2"></i>TPO Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-drives" ng-click="navigate('officer-drives')"><i class="bi bi-briefcase"></i>Manage Drives</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#officer-applications" ng-click="navigate('officer-applications')"><i class="bi bi-file-earmark-person"></i>Applications</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-interviews" ng-click="navigate('officer-interviews')"><i class="bi bi-calendar-check"></i>Interviews Schedule</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Candidate Applications</h4>
              <p class="page-subtitle">Review student applicants, update selection stages, and schedule interviews.</p>
            </div>
          </div>

          <div class="card shadow-sm border rounded-3">
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Student Name</th>
                    <th>Roll No</th>
                    <th>Company & Role</th>
                    <th>CGPA</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="a in officerApplications">
                    <td><b>{{a.student_name}}</b></td>
                    <td>{{a.roll_no}}</td>
                    <td>{{a.company_name}} &bull; {{a.job_role}}</td>
                    <td><span class="badge bg-light text-dark border">{{a.cgpa}}</span></td>
                    <td>
                      <span class="badge-status" ng-class="'badge-' + a.status.toLowerCase()">{{a.status}}</span>
                    </td>
                    <td>
                      <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary py-0 px-2" ng-click="openStatusModal(a)" title="Update Status">
                          <i class="bi bi-pencil-square me-1"></i>Status
                        </button>
                        <button class="btn btn-warning btn-sm text-dark py-0 px-2 fw-semibold" ng-click="openScheduleInterviewModal(a)" title="Schedule Interview">
                          <i class="bi bi-calendar-plus me-1"></i>Interview
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Officer Interview Management (Phase 9) -->
    <div id="view-officer-interviews" class="view-container" ng-show="activeView === 'officer-interviews'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">TPO Head</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-dashboard" ng-click="navigate('officer-dashboard')"><i class="bi bi-speedometer2"></i>TPO Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-drives" ng-click="navigate('officer-drives')"><i class="bi bi-briefcase"></i>Manage Drives</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-applications" ng-click="navigate('officer-applications')"><i class="bi bi-file-earmark-person"></i>Applications</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#officer-interviews" ng-click="navigate('officer-interviews')"><i class="bi bi-calendar-check"></i>Interviews Schedule</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Interview Schedules & Alerts</h4>
              <p class="page-subtitle">Coordinate candidate interview dates, times, online links, and automated student alerts.</p>
            </div>
            <button class="btn btn-sm btn-primary" ng-click="openScheduleInterviewModal()"><i class="bi bi-plus-circle me-1"></i>Schedule Interview</button>
          </div>

          <div class="card shadow-sm border rounded-3">
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Student Name</th>
                    <th>Company</th>
                    <th>Job Designation</th>
                    <th>Date & Time</th>
                    <th>Mode</th>
                    <th>Meeting Link / Location</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="iv in allScheduledInterviews">
                    <td><b>{{iv.student_name}}</b></td>
                    <td>{{iv.company_name}}</td>
                    <td>{{iv.job_designation}}</td>
                    <td>
                      <div><b>{{iv.interview_date}}</b></div>
                      <small class="text-muted">{{iv.interview_time}}</small>
                    </td>
                    <td><span class="badge bg-light text-dark border">{{iv.interview_mode}}</span></td>
                    <td class="small text-truncate" style="max-width: 150px;">{{iv.location_or_link}}</td>
                    <td>
                      <span class="badge" ng-class="{'bg-warning text-dark': iv.status === 'Scheduled', 'bg-success': iv.status === 'Completed', 'bg-danger': iv.status === 'Cancelled'}">{{iv.status}}</span>
                    </td>
                    <td>
                      <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-success py-0 px-2" title="Mark Completed" ng-click="updateInterviewStatus(iv, 'Completed')"><i class="bi bi-check2"></i></button>
                        <button class="btn btn-outline-danger py-0 px-2" title="Cancel" ng-click="updateInterviewStatus(iv, 'Cancelled')"><i class="bi bi-x"></i></button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Officer Manage Placements -->
    <div id="view-officer-placements" class="view-container" ng-show="activeView === 'officer-placements'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">TPO Head</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-dashboard" ng-click="navigate('officer-dashboard')"><i class="bi bi-speedometer2"></i>TPO Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-drives" ng-click="navigate('officer-drives')"><i class="bi bi-briefcase"></i>Manage Drives</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#officer-applications" ng-click="navigate('officer-applications')"><i class="bi bi-file-earmark-person"></i>Applications</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#officer-placements" ng-click="navigate('officer-placements')"><i class="bi bi-award"></i>Placements</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Placement Records</h4>
              <p class="page-subtitle">Verified institutional selection offers and campus placements.</p>
            </div>
          </div>

          <div class="card shadow-sm border rounded-3">
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Student Name</th>
                    <th>Roll No</th>
                    <th>Department</th>
                    <th>Company</th>
                    <th>Package</th>
                    <th>Offer Date</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="p in placements">
                    <td><b>{{p.student_name}}</b></td>
                    <td>{{p.roll_no}}</td>
                    <td>{{p.branch}}</td>
                    <td>{{p.company_name}}</td>
                    <td><span class="badge bg-success-subtle text-success border border-success-subtle">{{p.package}} LPA</span></td>
                    <td><small class="text-muted">{{p.offer_date}}</small></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- ========================================== -->
    <!-- 17. CENTRALIZED ADMIN DASHBOARD (PHASE 10) -->
    <!-- ========================================== -->
    <div id="view-admin-dashboard" class="view-container" ng-show="activeView === 'admin-dashboard'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Administrator</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link active" href="#admin-dashboard" ng-click="navigate('admin-dashboard')"><i class="bi bi-speedometer2"></i>Admin Console</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-students" ng-click="navigate('admin-students')"><i class="bi bi-people"></i>Students</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-alumni" ng-click="navigate('admin-alumni')"><i class="bi bi-mortarboard"></i>Alumni Profiles</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-companies" ng-click="navigate('admin-companies')"><i class="bi bi-buildings"></i>Companies</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-users" ng-click="navigate('admin-users')"><i class="bi bi-person-lock"></i>User Accounts</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Institutional Admin Control Center</h4>
              <p class="page-subtitle">System oversight, announcements management, and enterprise audit logs.</p>
            </div>
          </div>

          <!-- Admin KPIs -->
          <div class="row g-3 mb-3">
            <div class="col-md-3 col-6">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Registered Students</h6>
                  <div class="stat-value text-primary">{{adminKPIs.total_students || 10}}</div>
                </div>
                <i class="bi bi-people fs-2 text-primary opacity-50"></i>
              </div>
            </div>
            <div class="col-md-3 col-6">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Verified Alumni</h6>
                  <div class="stat-value text-success">{{adminKPIs.total_alumni || 1}}</div>
                </div>
                <i class="bi bi-mortarboard fs-2 text-success opacity-50"></i>
              </div>
            </div>
            <div class="col-md-3 col-6">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Companies Registered</h6>
                  <div class="stat-value text-info">{{adminKPIs.total_companies || 8}}</div>
                </div>
                <i class="bi bi-buildings fs-2 text-info opacity-50"></i>
              </div>
            </div>
            <div class="col-md-3 col-6">
              <div class="stat-widget">
                <div class="stat-widget-info">
                  <h6>Active Chat Threads</h6>
                  <div class="stat-value text-warning">{{adminKPIs.active_chats || 0}}</div>
                </div>
                <i class="bi bi-chat-dots fs-2 text-warning opacity-50"></i>
              </div>
            </div>
          </div>

          <!-- Announcements Publisher Form -->
          <div class="card shadow-sm border rounded-3 p-3 mb-3">
            <h6 class="fw-bold mb-2"><i class="bi bi-megaphone-fill text-primary me-2"></i>Publish Institutional Announcement</h6>
            <form ng-submit="saveAnnouncement()">
              <div class="row g-2 mb-2">
                <div class="col-md-8">
                  <input type="text" class="form-control form-control-sm" ng-model="announcementForm.title" placeholder="Announcement Title" required>
                </div>
                <div class="col-md-4">
                  <select class="form-select form-select-sm" ng-model="announcementForm.target_role">
                    <option value="all">Broadcast to All Users</option>
                    <option value="student">Students Only</option>
                    <option value="alumni">Alumni Mentors Only</option>
                  </select>
                </div>
              </div>
              <div class="mb-2">
                <textarea class="form-control form-control-sm" rows="2" ng-model="announcementForm.content" placeholder="Announcement content..." required></textarea>
              </div>
              <button type="submit" class="btn btn-primary btn-sm fw-bold">Publish Announcement</button>
            </form>
          </div>

          <!-- Enterprise Audit Logs Table (Phase 7 & 10) -->
          <div class="card shadow-sm border rounded-3">
            <div class="card-header bg-white py-2 d-flex justify-content-between align-items-center">
              <span class="fw-bold small text-dark"><i class="bi bi-shield-shaded me-1 text-danger"></i>System Activity & Audit Logs</span>
              <span class="badge bg-secondary">Live Audit Stream</span>
            </div>
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Timestamp</th>
                    <th>Action</th>
                    <th>Details</th>
                    <th>IP Address</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="log in auditLogs">
                    <td><small class="text-muted">{{log.created_at}}</small></td>
                    <td><b>{{log.action}}</b></td>
                    <td class="small text-secondary">{{log.details}}</td>
                    <td><small class="text-muted">{{log.ip_address}}</small></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Admin Manage Students -->
    <div id="view-admin-students" class="view-container" ng-show="activeView === 'admin-students'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Administrator</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-dashboard" ng-click="navigate('admin-dashboard')"><i class="bi bi-speedometer2"></i>Admin Console</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#admin-students" ng-click="navigate('admin-students')"><i class="bi bi-people"></i>Students</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-alumni" ng-click="navigate('admin-alumni')"><i class="bi bi-mortarboard"></i>Alumni Profiles</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-companies" ng-click="navigate('admin-companies')"><i class="bi bi-buildings"></i>Companies</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-users" ng-click="navigate('admin-users')"><i class="bi bi-person-lock"></i>User Accounts</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Manage Students</h4>
              <p class="page-subtitle">View and oversee registered students across all engineering branches.</p>
            </div>
          </div>

          <div class="card shadow-sm border rounded-3">
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Student Name</th>
                    <th>Roll No</th>
                    <th>Branch</th>
                    <th>CGPA</th>
                    <th>Email</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="s in adminStudents">
                    <td><b>{{s.name}}</b></td>
                    <td>{{s.roll_no}}</td>
                    <td>{{s.branch}}</td>
                    <td>{{s.cgpa}}</td>
                    <td>{{s.email}}</td>
                    <td>
                      <button class="btn btn-sm btn-outline-danger py-0 px-2" ng-click="deleteAdminStudent(s)"><i class="bi bi-trash"></i></button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Admin Manage Alumni -->
    <div id="view-admin-alumni" class="view-container" ng-show="activeView === 'admin-alumni'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Administrator</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-dashboard" ng-click="navigate('admin-dashboard')"><i class="bi bi-speedometer2"></i>Admin Console</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-students" ng-click="navigate('admin-students')"><i class="bi bi-people"></i>Students</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#admin-alumni" ng-click="navigate('admin-alumni')"><i class="bi bi-mortarboard"></i>Alumni Profiles</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-companies" ng-click="navigate('admin-companies')"><i class="bi bi-buildings"></i>Companies</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-users" ng-click="navigate('admin-users')"><i class="bi bi-person-lock"></i>User Accounts</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Manage Alumni Mentors</h4>
              <p class="page-subtitle">Verify, edit, and coordinate alumni records for the institutional directory.</p>
            </div>
          </div>

          <div class="card shadow-sm border rounded-3">
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Alumnus Name</th>
                    <th>Batch</th>
                    <th>Department</th>
                    <th>Company</th>
                    <th>Job Designation</th>
                    <th>Dynamic Experience</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="a in adminAlumni">
                    <td><b>{{a.name}}</b></td>
                    <td>{{a.graduation_year}}</td>
                    <td>{{a.department || a.branch}}</td>
                    <td>{{a.company}}</td>
                    <td>{{a.job_role}}</td>
                    <td><span class="badge bg-primary-subtle text-primary">{{a.dynamic_experience}}</span></td>
                    <td>
                      <button class="btn btn-sm btn-outline-danger py-0 px-2" ng-click="deleteAdminAlumni(a)"><i class="bi bi-trash"></i></button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Admin Manage Companies -->
    <div id="view-admin-companies" class="view-container" ng-show="activeView === 'admin-companies'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Administrator</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-dashboard" ng-click="navigate('admin-dashboard')"><i class="bi bi-speedometer2"></i>Admin Console</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-students" ng-click="navigate('admin-students')"><i class="bi bi-people"></i>Students</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-alumni" ng-click="navigate('admin-alumni')"><i class="bi bi-mortarboard"></i>Alumni Profiles</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#admin-companies" ng-click="navigate('admin-companies')"><i class="bi bi-buildings"></i>Companies</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-users" ng-click="navigate('admin-users')"><i class="bi bi-person-lock"></i>User Accounts</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Manage Registered Companies</h4>
              <p class="page-subtitle">Corporate hiring partners and MNC recruitment profiles.</p>
            </div>
          </div>

          <div class="card shadow-sm border rounded-3">
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>Company Name</th>
                    <th>Industry</th>
                    <th>Location</th>
                    <th>Website</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="c in adminCompanies">
                    <td><b>{{c.company_name}}</b></td>
                    <td>{{c.industry}}</td>
                    <td>{{c.location}}</td>
                    <td><a ng-href="{{c.website}}" target="_blank" class="small">{{c.website}}</a></td>
                    <td>
                      <button class="btn btn-sm btn-outline-danger py-0 px-2" ng-click="deleteAdminCompany(c)"><i class="bi bi-trash"></i></button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Admin Manage Users -->
    <div id="view-admin-users" class="view-container" ng-show="activeView === 'admin-users'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Administrator</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-dashboard" ng-click="navigate('admin-dashboard')"><i class="bi bi-speedometer2"></i>Admin Console</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-students" ng-click="navigate('admin-students')"><i class="bi bi-people"></i>Students</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-alumni" ng-click="navigate('admin-alumni')"><i class="bi bi-mortarboard"></i>Alumni Profiles</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#admin-companies" ng-click="navigate('admin-companies')"><i class="bi bi-buildings"></i>Companies</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#admin-users" ng-click="navigate('admin-users')"><i class="bi bi-person-lock"></i>User Accounts</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">User Account & Role Management</h4>
              <p class="page-subtitle">Manage login status, password resets, and role permissions.</p>
            </div>
          </div>

          <div class="card shadow-sm border rounded-3">
            <div class="table-responsive">
              <table class="table table-hover table-custom align-middle">
                <thead>
                  <tr>
                    <th>User</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr ng-repeat="u in adminUsers">
                    <td><b>{{u.name}}</b></td>
                    <td>{{u.email}}</td>
                    <td><span class="badge bg-light text-dark border text-capitalize">{{u.role}}</span></td>
                    <td>
                      <span class="badge" ng-class="{'bg-success': u.is_active == 1, 'bg-danger': u.is_active != 1}">
                        {{u.is_active == 1 ? 'Active' : 'Disabled'}}
                      </span>
                    </td>
                    <td>
                      <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-secondary py-0 px-2" ng-click="toggleUserStatus(u)">
                          {{u.is_active == 1 ? 'Disable' : 'Enable'}}
                        </button>
                        <button class="btn btn-outline-primary py-0 px-2" ng-click="resetUserPassword(u)">Reset Password</button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Student Portfolio Builder View (Preserved) -->
    <div id="view-student-portfolio" class="view-container" ng-show="activeView === 'student-portfolio'">
      <div class="dashboard-container">
        <aside class="dashboard-sidebar">
          <div class="sidebar-brand-card">
            <div class="sidebar-avatar">{{currentUser.name.charAt(0)}}</div>
            <div class="overflow-hidden">
              <div class="fw-bold text-truncate" style="font-size: 0.9rem;">{{currentUser.name}}</div>
              <small class="text-white-50 d-block" style="font-size: 0.72rem;">Student</small>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="sidebar-item"><a class="sidebar-link" href="#student-dashboard" ng-click="navigate('student-dashboard')"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-profile" ng-click="navigate('student-profile')"><i class="bi bi-person-lines-fill"></i>Profile & Resumes</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#smart-matching" ng-click="navigate('smart-matching')"><i class="bi bi-stars"></i>Smart Job Matcher</a></li>
            <li class="sidebar-item"><a class="sidebar-link active" href="#student-portfolio" ng-click="navigate('student-portfolio')"><i class="bi bi-person-badge"></i>Portfolio Builder</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-ats" ng-click="navigate('student-ats')"><i class="bi bi-file-earmark-check"></i>ATS Resume Checker</a></li>
            <li class="sidebar-item"><a class="sidebar-link" href="#student-chat" ng-click="navigate('student-chat')"><i class="bi bi-chat-dots-fill"></i>Alumni Direct Chat</a></li>
          </ul>
        </aside>

        <main class="dashboard-main">
          <div class="dashboard-topbar">
            <div>
              <h4 class="page-title">Student Portfolio Builder</h4>
              <p class="page-subtitle">Design your professional recruitment portfolio and generate your live recruiter URL.</p>
            </div>
            <div class="d-flex gap-2">
              <button class="btn btn-sm btn-outline-primary" ng-click="copyPortfolioUrl()">
                <i class="bi bi-share me-1"></i>Copy Public Link
              </button>
              <button class="btn btn-sm" ng-class="{'btn-success': portfolio.is_published, 'btn-secondary': !portfolio.is_published}" ng-click="togglePublishPortfolio()">
                <i class="bi" ng-class="{'bi-globe2': portfolio.is_published, 'bi-eye-slash': !portfolio.is_published}"></i>
                {{portfolio.is_published ? 'Published Live' : 'Private Draft'}}
              </button>
            </div>
          </div>

          <div class="row g-3">
            <div class="col-lg-6">
              <div class="card shadow-sm border rounded-3 p-3">
                <h6 class="fw-bold mb-3"><i class="bi bi-pencil-square text-primary me-2"></i>Customize Portfolio Content</h6>
                <div class="mb-2">
                  <label class="form-label small fw-semibold">Professional Headline</label>
                  <input type="text" class="form-control form-control-sm" ng-model="portfolio.headline" placeholder="Aspiring Full-Stack Software Engineer">
                </div>
                <div class="mb-2">
                  <label class="form-label small fw-semibold">About Me</label>
                  <textarea class="form-control form-control-sm" rows="3" ng-model="portfolio.about_me" placeholder="Introduce your career goals and technical expertise..."></textarea>
                </div>
                <div class="row g-2 mb-3">
                  <div class="col-md-6">
                    <label class="form-label small fw-semibold">Location</label>
                    <input type="text" class="form-control form-control-sm" ng-model="portfolio.location" placeholder="Kopargaon / Pune">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label small fw-semibold">Personal Website</label>
                    <input type="url" class="form-control form-control-sm" ng-model="portfolio.website_url" placeholder="https://yourdomain.com">
                  </div>
                </div>

                <!-- Projects in Portfolio -->
                <div class="d-flex justify-content-between align-items-center mb-2 pt-2 border-top">
                  <h6 class="fw-bold small text-dark mb-0"><i class="bi bi-folder-fill text-warning me-1"></i>Projects Showcase ({{portfolio.projects.length}})</h6>
                  <button class="btn btn-sm btn-outline-primary py-0 px-2 small" ng-click="addProject()">+ Add Project</button>
                </div>
                <div class="p-2 bg-light rounded border mb-2" ng-repeat="pr in portfolio.projects">
                  <div class="d-flex justify-content-between align-items-center mb-1">
                    <input type="text" class="form-control form-control-sm fw-bold me-2" ng-model="pr.title" placeholder="Project Title">
                    <button class="btn btn-sm btn-outline-danger py-0 px-2" ng-click="removeProject($index)"><i class="bi bi-trash"></i></button>
                  </div>
                  <textarea class="form-control form-control-sm mb-1" rows="2" ng-model="pr.description" placeholder="Project Description"></textarea>
                  <input type="text" class="form-control form-control-sm" ng-model="pr.technologies" placeholder="Technologies (e.g. Java, MySQL, Angular)">
                </div>

                <button class="btn btn-primary btn-sm fw-bold mt-2" ng-click="savePortfolio()">
                  <i class="bi bi-save me-1"></i>Save Portfolio Updates
                </button>
              </div>
            </div>

            <!-- Live Preview -->
            <div class="col-lg-6">
              <div class="card shadow-sm border rounded-3 p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                  <h6 class="fw-bold mb-0"><i class="bi bi-eye text-info me-2"></i>Live Recruiter Preview</h6>
                  <span class="badge bg-light text-muted border">Views: {{portfolio.views_count || 0}}</span>
                </div>
                <div class="p-4 rounded-3 text-white mb-3" style="background: linear-gradient(135deg, #090e29 0%, #1e1b4b 100%);">
                  <div class="d-flex align-items-center gap-3">
                    <div class="sidebar-avatar" style="width:54px; height:54px; font-size:1.4rem;">{{currentUser.name.charAt(0)}}</div>
                    <div>
                      <h5 class="fw-bold mb-0 text-white">{{currentUser.name}}</h5>
                      <span class="text-white-50 small">{{portfolio.headline || 'Full-Stack Developer'}}</span>
                    </div>
                  </div>
                  <p class="small text-white-50 mt-2 mb-0" style="font-size: 0.82rem;">{{portfolio.about_me || 'Student at Sanjivani University, Kopargaon.'}}</p>
                </div>

                <div class="small">
                  <b>Projects:</b>
                  <div class="p-2 bg-light rounded border mt-1" ng-repeat="p in portfolio.projects">
                    <b>{{p.title}}</b>
                    <div class="text-muted small">{{p.description}}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>

    <!-- Controlled Public Recruiter Portfolio View (Preserved) -->
    <div id="view-public-portfolio" class="view-container section-compact" ng-show="activeView === 'public-portfolio'">
      <div class="container" style="max-width: 960px;" ng-if="publicPortfolio">
        <div class="card shadow-lg border rounded-4 overflow-hidden mb-3">
          <div class="p-4 text-white" style="background: linear-gradient(135deg, #090e29 0%, #1e1b4b 100%);">
            <div class="d-flex align-items-center gap-3 mb-2">
              <div class="sidebar-avatar" style="width:60px; height:60px; font-size:1.6rem; background: #4f46e5;">{{publicPortfolio.name.charAt(0)}}</div>
              <div>
                <h4 class="fw-bold mb-0 text-white">{{publicPortfolio.name}}</h4>
                <div class="text-warning small fw-semibold">{{publicPortfolio.headline || 'Sanjivani University Graduate'}}</div>
                <small class="text-white-50">{{publicPortfolio.branch}} &bull; CGPA: {{publicPortfolio.cgpa}}</small>
              </div>
            </div>
            <p class="small text-white-50 mb-0" style="max-width: 680px;">{{publicPortfolio.about_me}}</p>
          </div>
          <div class="card-body p-4">
            <h6 class="fw-bold mb-2">Featured Technical Projects</h6>
            <div class="row g-2 mb-3">
              <div class="col-md-6" ng-repeat="p in publicPortfolio.projects">
                <div class="p-3 bg-light rounded border h-100">
                  <h6 class="fw-bold text-dark mb-1">{{p.title}}</h6>
                  <p class="small text-muted mb-2">{{p.description}}</p>
                  <span class="badge bg-primary-subtle text-primary small">{{p.technologies}}</span>
                </div>
              </div>
            </div>
            <div class="d-flex justify-content-between align-items-center pt-3 border-top">
              <span class="small text-muted">&copy; Sanjivani University Kopargaon Placement Verification</span>
              <button class="btn btn-sm btn-outline-primary" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print PDF</button>
            </div>
          </div>
        </div>
      </div>
    </div>

  </main>

  <!-- ========================================== -->
  <!-- MODALS CONTAINER                           -->
  <!-- ========================================== -->
  
  <!-- Chat Request Modal (Student to Alumni) -->
  <div class="modal fade" id="chatRequestModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h6 class="modal-title fw-bold"><i class="bi bi-chat-dots-fill text-primary me-2"></i>Connect with {{chatRequestModalData.alumni_name}}</h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <p class="small text-muted mb-2">Introduce yourself and mention the topics you'd like guidance on (e.g., technical rounds, system design, resume review).</p>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Your Message to Alumnus</label>
            <textarea class="form-control form-control-sm" rows="4" ng-model="chatRequestModalData.message" required></textarea>
          </div>
          <button type="button" class="btn btn-primary btn-sm w-100 fw-bold" ng-click="submitChatRequest()">
            <i class="bi bi-send me-1"></i>Send Chat Request
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Schedule Interview Modal (Officer/Admin to Student) -->
  <div class="modal fade" id="scheduleInterviewModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h6 class="modal-title fw-bold"><i class="bi bi-calendar-check-fill text-warning me-2"></i>Schedule Student Interview</h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <form ng-submit="saveInterview()">
            <div class="row g-2 mb-2">
              <div class="col-md-6">
                <label class="form-label small fw-semibold">Company Name</label>
                <input type="text" class="form-control form-control-sm" ng-model="interviewForm.company_name" required>
              </div>
              <div class="col-md-6">
                <label class="form-label small fw-semibold">Job Designation</label>
                <input type="text" class="form-control form-control-sm" ng-model="interviewForm.job_designation" required>
              </div>
            </div>
            <div class="row g-2 mb-2">
              <div class="col-md-6">
                <label class="form-label small fw-semibold">Interview Date</label>
                <input type="date" class="form-control form-control-sm" ng-model="interviewForm.interview_date" required>
              </div>
              <div class="col-md-6">
                <label class="form-label small fw-semibold">Interview Time</label>
                <input type="time" class="form-control form-control-sm" ng-model="interviewForm.interview_time" required>
              </div>
            </div>
            <div class="row g-2 mb-2">
              <div class="col-md-6">
                <label class="form-label small fw-semibold">Interview Mode</label>
                <select class="form-select form-select-sm" ng-model="interviewForm.interview_mode">
                  <option value="Online">Online Video Call</option>
                  <option value="Offline">On-Campus / In-Person</option>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label small fw-semibold">Location / Meeting Link</label>
                <input type="text" class="form-control form-control-sm" ng-model="interviewForm.location_or_link" placeholder="https://meet.google.com/..." required>
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label small fw-semibold">Instructions for Student</label>
              <textarea class="form-control form-control-sm" rows="2" ng-model="interviewForm.instructions" placeholder="Join 5 minutes prior with portfolio and resume ready..."></textarea>
            </div>
            <button type="submit" class="btn btn-warning w-100 fw-bold btn-sm text-dark">
              <i class="bi bi-calendar-check me-1"></i>Confirm Schedule & Send Student Alert
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Drive Details Modal -->
  <div class="modal fade" id="driveDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h6 class="modal-title fw-bold">{{activeDrive.company_name}} &bull; {{activeDrive.job_role}}</h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body small">
          <div class="d-flex justify-content-between mb-2">
            <span><b>Package:</b> {{activeDrive.package}} LPA</span>
            <span><b>Location:</b> {{activeDrive.location}}</span>
          </div>
          <div class="mb-2"><b>Eligible Branches:</b> {{activeDrive.eligible_branches}}</div>
          <div class="mb-2"><b>Min CGPA:</b> {{activeDrive.min_cgpa}}</div>
          <div class="mb-2"><b>Required Skills:</b> {{activeDrive.skills}}</div>
          <div class="mb-3"><b>Deadline:</b> {{activeDrive.deadline}}</div>
          <button class="btn btn-primary btn-sm w-100 fw-bold" ng-if="currentUser && currentUser.role === 'student'" ng-click="openApplyModal(activeDrive)">
            Apply for this Drive
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Apply Drive Confirmation Modal -->
  <div class="modal fade" id="applyDriveModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h6 class="modal-title fw-bold">Confirm Drive Application</h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body small">
          <p>You are applying for <b>{{applyDriveTarget.job_role}}</b> at <b>{{applyDriveTarget.company_name}}</b> ({{applyDriveTarget.package}} LPA).</p>
          <p class="text-muted">Your active resume and institutional profile will be forwarded to the corporate recruitment team.</p>
          <button class="btn btn-primary w-100 btn-sm fw-bold" ng-click="submitApplication()">Confirm & Submit Application</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Update Application Status Modal (TPO) -->
  <div class="modal fade" id="updateStatusModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h6 class="modal-title fw-bold">Update Application Stage</h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body small">
          <div class="mb-3">
            <label class="form-label fw-semibold">Recruitment Status</label>
            <select class="form-select form-select-sm" ng-model="statusModalData.status">
              <option value="Applied">Applied</option>
              <option value="Shortlisted">Shortlisted</option>
              <option value="Interview">Interview Scheduled</option>
              <option value="Selected">Selected / Placed</option>
              <option value="Rejected">Rejected</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Review Notes</label>
            <textarea class="form-control form-control-sm" rows="2" ng-model="statusModalData.notes" placeholder="Optional notes for candidate..."></textarea>
          </div>
          <button class="btn btn-primary btn-sm w-100 fw-bold" ng-click="saveApplicationStatus()">Update Status</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Add/Edit Drive Modal (TPO) -->
  <div class="modal fade" id="driveModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h6 class="modal-title fw-bold">{{driveFormModalTitle || 'Placement Drive'}}</h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body small">
          <form ng-submit="saveDrive()">
            <div class="row g-2 mb-2">
              <div class="col-md-6">
                <label class="form-label fw-semibold">Company</label>
                <select class="form-select form-select-sm" ng-model="driveForm.company_id" required>
                  <option value="">Select Company</option>
                  <option ng-repeat="c in companiesList" value="{{c.id}}">{{c.company_name}}</option>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label fw-semibold">Job Designation</label>
                <input type="text" class="form-control form-control-sm" ng-model="driveForm.job_role" required>
              </div>
            </div>
            <div class="row g-2 mb-2">
              <div class="col-md-6">
                <label class="form-label fw-semibold">Package (LPA)</label>
                <input type="number" step="0.1" class="form-control form-control-sm" ng-model="driveForm.package" required>
              </div>
              <div class="col-md-6">
                <label class="form-label fw-semibold">Location</label>
                <input type="text" class="form-control form-control-sm" ng-model="driveForm.location" required>
              </div>
            </div>
            <div class="row g-2 mb-2">
              <div class="col-md-6">
                <label class="form-label fw-semibold">Drive Date</label>
                <input type="date" class="form-control form-control-sm" ng-model="driveForm.drive_date" required>
              </div>
              <div class="col-md-6">
                <label class="form-label fw-semibold">Application Deadline</label>
                <input type="date" class="form-control form-control-sm" ng-model="driveForm.deadline" required>
              </div>
            </div>
            <div class="row g-2 mb-2">
              <div class="col-md-6">
                <label class="form-label fw-semibold">Min CGPA</label>
                <input type="number" step="0.01" class="form-control form-control-sm" ng-model="driveForm.min_cgpa" required>
              </div>
              <div class="col-md-6">
                <label class="form-label fw-semibold">Vacancies</label>
                <input type="number" class="form-control form-control-sm" ng-model="driveForm.vacancies" required>
              </div>
            </div>
            <div class="mb-2">
              <label class="form-label fw-semibold">Eligible Branches</label>
              <input type="text" class="form-control form-control-sm" ng-model="driveForm.eligible_branches" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold">Required Skills</label>
              <input type="text" class="form-control form-control-sm" ng-model="driveForm.skills" required>
            </div>
            <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">Save Drive</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Global Toast Notification Element -->
  <div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 1090;">
    <div id="portalToast" class="toast align-items-center border-0 shadow-lg" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body d-flex align-items-center">
          <i id="toastIcon" class="bi bi-info-circle-fill me-2 fs-5 text-primary"></i>
          <span id="toastBody" class="small fw-semibold text-dark">Notification message</span>
        </div>
        <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    </div>
  </div>

  <!-- Global Footer (Phase 2 & 15: Clean Contact & Zero Demo Logins) -->
  <footer class="footer-custom">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-5">
          <h5 class="d-flex align-items-center gap-2">
            <i class="bi bi-mortarboard-fill text-warning"></i>
            Sanjivani University &bull; Kopargaon
          </h5>
          <p class="small text-white-50">
            Directorate of Corporate Relations & Training, Placement & Alumni Cell. Driving placement excellence, skill readiness, and industry collaboration.
          </p>
          <div class="small text-white-50 mt-2">
            <div><i class="bi bi-geo-alt me-1 text-warning"></i> Sahajanandnagar, Post: Shingnapur, Kopargaon, Dist: Ahmednagar, Maharashtra - 423603</div>
            <div><i class="bi bi-telephone me-1 text-info"></i> Contact Number: <b>8668680085</b></div>
            <div><i class="bi bi-envelope me-1 text-primary"></i> Official Email: <b>tpo@sanjivani.edu.in</b></div>
          </div>
        </div>

        <div class="col-lg-3 col-6">
          <h6>Navigation</h6>
          <ul class="list-unstyled small">
            <li class="mb-1"><a href="#home" ng-click="navigate('home')">Home</a></li>
            <li class="mb-1"><a href="#drives" ng-click="navigate('drives')">Placement Drives</a></li>
            <li class="mb-1"><a href="#alumni" ng-click="navigate('alumni')">Alumni Directory</a></li>
            <li class="mb-1"><a href="#prep-hub" ng-click="navigate('prep-hub')">Interview Prep Hub</a></li>
            <li class="mb-1"><a href="#statistics" ng-click="navigate('statistics')">Placement Statistics</a></li>
          </ul>
        </div>

        <div class="col-lg-4 col-6">
          <h6>Institutional Platform</h6>
          <p class="small text-white-50">
            SU T&P is an enterprise-grade placement management and alumni tracking system engineered for higher education institutions.
          </p>
          <div class="d-flex gap-2 text-white-50 fs-5">
            <i class="bi bi-filetype-php" title="PHP 8 Backend"></i>
            <i class="bi bi-database" title="MySQL Relational Database"></i>
            <i class="bi bi-bootstrap" title="Bootstrap 5.3"></i>
            <i class="bi bi-shield-check" title="RBAC & Security"></i>
          </div>
        </div>
      </div>
      <hr class="my-3 border-secondary">
      <div class="text-center small text-white-50">
        &copy; 2026 Sanjivani University, Kopargaon &bull; Training & Placement Cell. All rights reserved.
      </div>
    </div>
  </footer>

  <!-- Bootstrap 5 JS Bundle -->
  <script src="assets/js/bootstrap.bundle.min.js"></script>
  <!-- Application Scripts -->
  <script src="assets/js/charts.js"></script>
  <script src="assets/js/app.js"></script>
</body>
</html>
HTML;

file_put_contents(__DIR__ . '/../index.html', $html);
echo "index.html successfully updated! Length: " . strlen($html) . " bytes\n";
