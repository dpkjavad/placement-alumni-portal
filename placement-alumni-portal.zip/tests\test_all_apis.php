<?php
/**
 * Automated End-to-End API and Integration Test Suite
 * Tests all 18 Phases and Verification Points using cURL cookie jar
 */

$baseUrl = 'http://localhost/placement-alumni-portal';
$cookieStudent = __DIR__ . '/cookie_student.txt';
$cookieAlumni  = __DIR__ . '/cookie_alumni.txt';
$cookieAdmin   = __DIR__ . '/cookie_admin.txt';

@unlink($cookieStudent);
@unlink($cookieAlumni);
@unlink($cookieAdmin);

function makeRequest($url, $method = 'GET', $data = null, $cookieFile = null) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    if ($cookieFile) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    }
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($data) ? json_encode($data) : $data);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        }
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    
    return [
        'code' => $httpCode,
        'body' => $response,
        'json' => json_decode($response, true),
        'curl_err' => $err
    ];
}

$passed = 0;
$failed = 0;

function assertTest($name, $condition, $details = '') {
    global $passed, $failed;
    if ($condition) {
        echo "[PASS] $name\n";
        $passed++;
    } else {
        echo "[FAIL] $name $details\n";
        $failed++;
    }
}

echo "====================================================\n";
echo "SU T&P PORTAL - COMPREHENSIVE AUTOMATED TEST SUITE\n";
echo "====================================================\n\n";

// 1. Test Home Page Loading
$home = makeRequest("$baseUrl/index.html");
assertTest("HTTP 200 on index.html", $home['code'] === 200);
assertTest("Official Contact 8668680085 present on homepage", strpos($home['body'], '8668680085') !== false);
assertTest("Zero demo login buttons in markup", strpos($home['body'], 'demo-login') === false && strpos($home['body'], 'fillDemo') === false);

// 2. Test Alumni Public API
$alumniRes = makeRequest("$baseUrl/api/alumni/index.php");
assertTest("Alumni API returns HTTP 200", $alumniRes['code'] === 200);
$alumniData = $alumniRes['json'];
assertTest("Alumni API returns success = true", isset($alumniData['success']) && $alumniData['success'] === true);
$hasNilesh = false;
$hasDynamicExp = false;
if (isset($alumniData['data'])) {
    foreach ($alumniData['data'] as $alum) {
        if (strpos($alum['name'], 'Nilesh Kulkarni') !== false) {
            $hasNilesh = true;
            if (!empty($alum['dynamic_experience'])) {
                $hasDynamicExp = true;
                echo "   -> Found Alumnus: {$alum['name']} | Exp: {$alum['dynamic_experience']} | Joining: {$alum['joining_date']}\n";
            }
        }
    }
}
assertTest("Kopargaon Alumnus Er. Nilesh Kulkarni present in alumni data", $hasNilesh);
assertTest("Dynamic experience calculated automatically from joining_date", $hasDynamicExp);

// 3. Test Student Login
$studentLogin = makeRequest("$baseUrl/api/auth/login.php", 'POST', [
    'email' => 'rohan.kulkarni@sanjivani.edu.in',
    'password' => 'Student@123'
], $cookieStudent);

assertTest("Student login returns HTTP 200", $studentLogin['code'] === 200);
assertTest("Student login success", isset($studentLogin['json']['success']) && $studentLogin['json']['success'] === true, $studentLogin['body']);

// 4. Test Student Profile & Social Links (Phase 4)
$profileUpdate = makeRequest("$baseUrl/api/students/profile.php", 'POST', [
    'action' => 'update',
    'phone' => '8668680085',
    'skills' => 'PHP, MySQL, JavaScript, Python, Java, Data Structures',
    'github_url' => 'https://github.com/rohan-sanjivani',
    'hackerrank_url' => 'https://hackerrank.com/rohan_dev',
    'linkedin_url' => 'https://linkedin.com/in/rohan-kulkarni-sanjivani'
], $cookieStudent);

assertTest("Student profile update with GitHub/HackerRank/LinkedIn returns success", isset($profileUpdate['json']['success']) && $profileUpdate['json']['success'] === true, $profileUpdate['body']);

// 5. Test Smart Job Matching & Skill Gap Analysis (Phase 10)
$smartMatching = makeRequest("$baseUrl/api/smart_matching/jobs.php", 'GET', null, $cookieStudent);
assertTest("Smart Matching API returns HTTP 200", $smartMatching['code'] === 200);
assertTest("Smart Matching provides match score and gaps", isset($smartMatching['json']['data']) && count($smartMatching['json']['data']) > 0, $smartMatching['body']);
if (!empty($smartMatching['json']['data'][0])) {
    $firstJob = $smartMatching['json']['data'][0];
    echo "   -> Smart Job: {$firstJob['job_role']} at {$firstJob['company_name']} | Match Score: {$firstJob['match_percentage']}% | Missing: " . count($firstJob['missing_skills']) . " skills\n";
}

// 6. Test Placement Readiness Score (Phase 11)
$readiness = makeRequest("$baseUrl/api/smart_matching/readiness.php", 'GET', null, $cookieStudent);
assertTest("Placement Readiness Score API returns HTTP 200", $readiness['code'] === 200);
assertTest("Readiness score calculated with 5 breakdown pillars", isset($readiness['json']['overall_score']) && isset($readiness['json']['breakdown']), $readiness['body']);
if (isset($readiness['json']['overall_score'])) {
    echo "   -> Overall Readiness: {$readiness['json']['overall_score']}% ({$readiness['json']['tier']})\n";
}

// 7. Test Interview Prep Hub (Phase 12)
$prepHub = makeRequest("$baseUrl/api/prep_hub/index.php", 'GET', null, $cookieStudent);
assertTest("Interview Prep Hub API returns categorized questions", isset($prepHub['json']['success']) && $prepHub['json']['success'] === true && count($prepHub['json']['data']) > 0);
echo "   -> Prep Hub Questions Loaded: " . count($prepHub['json']['data']) . " curated questions\n";

// 8. Test Student-Alumni Chat Request (Phase 8)
// Send chat request to Alumnus ID 15 (Er. Nilesh Kulkarni)
$chatReq = makeRequest("$baseUrl/api/chat/requests.php", 'POST', [
    'action' => 'send',
    'alumni_id' => 15,
    'message' => 'Hello Er. Nilesh sir, I am a 3rd year student from Sanjivani Kopargaon seeking career guidance.'
], $cookieStudent);
assertTest("Chat request sent successfully or already pending", isset($chatReq['json']['success']), $chatReq['body']);

// 9. Test Notification Center (Phase 9 & 8)
$notifs = makeRequest("$baseUrl/api/notifications/index.php", 'GET', null, $cookieStudent);
assertTest("Notification center returns notification stream", isset($notifs['json']['success']) && $notifs['json']['success'] === true, $notifs['body']);
if (isset($notifs['json']['data'])) {
    echo "   -> Notifications in student inbox: " . count($notifs['json']['data']) . "\n";
}

// 10. Test Alumni Login & Chat Request Acceptance
$alumniLogin = makeRequest("$baseUrl/api/auth/login.php", 'POST', [
    'email' => 'nilesh.kulkarni@sanjivani.edu.in',
    'password' => 'Alumni@123'
], $cookieAlumni);
assertTest("Alumnus Nilesh Kulkarni login successful", isset($alumniLogin['json']['success']) && $alumniLogin['json']['success'] === true, $alumniLogin['body']);

// Check pending chat requests as Alumnus
$alumniReqs = makeRequest("$baseUrl/api/chat/requests.php", 'GET', null, $cookieAlumni);
assertTest("Alumnus can view chat requests", isset($alumniReqs['json']['success']) && $alumniReqs['json']['success'] === true, $alumniReqs['body']);

$reqId = null;
if (!empty($alumniReqs['json']['data'])) {
    $reqId = $alumniReqs['json']['data'][0]['id'];
    echo "   -> Found chat request #$reqId from student\n";
    // Accept the chat request if pending
    if ($alumniReqs['json']['data'][0]['status'] === 'pending') {
        $acceptRes = makeRequest("$baseUrl/api/chat/requests.php", 'POST', [
            'action' => 'respond',
            'request_id' => $reqId,
            'status' => 'accepted'
        ], $cookieAlumni);
        assertTest("Alumnus accepted chat request", isset($acceptRes['json']['success']) && $acceptRes['json']['success'] === true);
    } else {
        assertTest("Alumnus chat request is already {$alumniReqs['json']['data'][0]['status']}", true);
    }
}

// 11. Test Direct Messaging (Phase 8)
if ($reqId) {
    // Alumnus sends message
    $msgSend = makeRequest("$baseUrl/api/chat/messages.php", 'POST', [
        'request_id' => $reqId,
        'message' => 'Welcome Rohan! Glad to connect with a fellow Sanjivani student from Kopargaon.'
    ], $cookieAlumni);
    assertTest("Alumnus sent chat message successfully", isset($msgSend['json']['success']) && $msgSend['json']['success'] === true, $msgSend['body']);
    
    // Student fetches messages
    $msgList = makeRequest("$baseUrl/api/chat/messages.php?request_id=$reqId", 'GET', null, $cookieStudent);
    assertTest("Student fetched conversation messages", isset($msgList['json']['success']) && count($msgList['json']['data']) > 0, $msgList['body']);
    if (isset($msgList['json']['data'])) {
        echo "   -> Direct chat conversation length: " . count($msgList['json']['data']) . " messages\n";
    }
}

// 12. Test Alumni Job Referral Posting (Phase 11 Feature 5)
$referralPost = makeRequest("$baseUrl/api/alumni/referrals.php", 'POST', [
    'action' => 'create',
    'company_name' => 'Tata Consultancy Services',
    'job_title' => 'Associate Software Engineer - Cloud Practice',
    'location' => 'Pune / Hybrid',
    'requirements' => 'B.Tech/BE Computer/IT with CGPA >= 7.5 and good DSA foundation',
    'deadline' => date('Y-m-d', strtotime('+30 days'))
], $cookieAlumni);
assertTest("Alumnus posted job referral", isset($referralPost['json']['success']) && $referralPost['json']['success'] === true, $referralPost['body']);

// Student fetches referrals and applies
$studentRefs = makeRequest("$baseUrl/api/alumni/referrals.php", 'GET', null, $cookieStudent);
assertTest("Student can view active alumni referrals", isset($studentRefs['json']['success']) && count($studentRefs['json']['data']) > 0, $studentRefs['body']);
if (!empty($studentRefs['json']['data'])) {
    $refId = $studentRefs['json']['data'][0]['id'];
    $applyRef = makeRequest("$baseUrl/api/alumni/referrals.php", 'POST', [
        'action' => 'apply',
        'referral_id' => $refId,
        'notes' => 'Applied with active resume and verified profile.'
    ], $cookieStudent);
    assertTest("Student applied for alumni referral", isset($applyRef['json']['success']), $applyRef['body']);
}

// 13. Test Admin Login & Enterprise Security Controls (Phase 7 & 15)
$adminLogin = makeRequest("$baseUrl/api/auth/login.php", 'POST', [
    'email' => 'admin@sanjivani.edu.in',
    'password' => 'Admin@123'
], $cookieAdmin);
assertTest("Admin login successful", isset($adminLogin['json']['success']) && $adminLogin['json']['success'] === true, $adminLogin['body']);

// 14. Test Interview Scheduling (Phase 9)
$interviewCreate = makeRequest("$baseUrl/api/interviews/index.php", 'POST', [
    'action' => 'create',
    'student_id' => 1,
    'company_name' => 'Tata Consultancy Services',
    'job_designation' => 'Software Engineer (Kopargaon Campus Drive)',
    'interview_date' => date('Y-m-d', strtotime('+2 days')),
    'interview_time' => '10:30:00',
    'interview_mode' => 'Online',
    'location_or_link' => 'https://meet.google.com/sanjivani-tcs-interview',
    'instructions' => 'Keep your college ID and resume ready.'
], $cookieAdmin);
assertTest("Admin/TPO scheduled an interview with student alert", isset($interviewCreate['json']['success']) && $interviewCreate['json']['success'] === true, $interviewCreate['body']);

// Student views scheduled interview
$studentInterviews = makeRequest("$baseUrl/api/interviews/index.php", 'GET', null, $cookieStudent);
assertTest("Student receives scheduled interview alerts", isset($studentInterviews['json']['success']) && count($studentInterviews['json']['data']) > 0, $studentInterviews['body']);
if (!empty($studentInterviews['json']['data'])) {
    $firstIv = $studentInterviews['json']['data'][0];
    echo "   -> Scheduled Interview: {$firstIv['job_designation']} at {$firstIv['company_name']} on {$firstIv['interview_date']} at {$firstIv['interview_time']}\n";
}

// Test Admin Dashboard Stats
$adminStats = makeRequest("$baseUrl/api/admin/dashboard_stats.php", 'GET', null, $cookieAdmin);
assertTest("Admin dashboard stats retrieved", isset($adminStats['json']['success']) && $adminStats['json']['success'] === true, $adminStats['body']);
if (isset($adminStats['json']['data']['kpis'])) {
    $k = $adminStats['json']['data']['kpis'];
    echo "   -> KPIs: Students: {$k['total_students']}, Alumni: {$k['total_alumni']}, Jobs: {$k['total_jobs']}, Resumes: {$k['total_resumes']}\n";
}

// Test Enterprise Audit Logs
$auditLogs = makeRequest("$baseUrl/api/admin/audit_logs.php", 'GET', null, $cookieAdmin);
assertTest("Audit logs stream verified with security activity", isset($auditLogs['json']['success']) && count($auditLogs['json']['data']) > 0, $auditLogs['body']);
if (isset($auditLogs['json']['data'])) {
    echo "   -> Total recorded audit log events: " . count($auditLogs['json']['data']) . "\n";
}

// Test Institutional Announcements
$announcements = makeRequest("$baseUrl/api/admin/announcements.php", 'GET', null, $cookieAdmin);
assertTest("Institutional announcements verified", isset($announcements['json']['success']) && count($announcements['json']['data']) > 0, $announcements['body']);

echo "\n====================================================\n";
echo "TEST RESULTS SUMMARY: $passed PASSED, $failed FAILED\n";
echo "====================================================\n";

@unlink($cookieStudent);
@unlink($cookieAlumni);
@unlink($cookieAdmin);
