<?php
/**
 * API: Interview Scheduling & Alert Management
 * Implements Phase 9: Interview Scheduling and Student Notification System
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireLogin();
$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

// 1. GET: List interviews
if ($method === 'GET') {
    if ($user['role'] === 'student') {
        $studentId = (int)($user['student_profile']['id'] ?? 0);
        $stmt = $pdo->prepare("
            SELECT i.*, d.package, d.location AS drive_location
            FROM interview_schedules i
            LEFT JOIN drives d ON i.drive_id = d.id
            WHERE i.student_id = :sid
            ORDER BY i.interview_date ASC, i.interview_time ASC
        ");
        $stmt->execute(['sid' => $studentId]);
        $interviews = $stmt->fetchAll();

        // Calculate upcoming reminder flag
        $now = new DateTime();
        foreach ($interviews as &$iv) {
            $ivDateTime = new DateTime($iv['interview_date'] . ' ' . $iv['interview_time']);
            $diffHours = ($ivDateTime->getTimestamp() - $now->getTimestamp()) / 3600;
            $iv['is_upcoming'] = ($diffHours > 0 && $diffHours <= 48);
            $iv['is_past'] = ($diffHours < 0);
        }
        unset($iv);

        sendJson(['success' => true, 'data' => $interviews]);
    } elseif (in_array($user['role'], ['admin', 'officer'])) {
        $status = trim($_GET['status'] ?? '');
        $sql = "
            SELECT i.*, s.roll_no, s.branch, s.cgpa, u.name AS student_name, u.email AS student_email
            FROM interview_schedules i
            JOIN students s ON i.student_id = s.id
            JOIN users u ON s.user_id = u.id
        ";
        $params = [];
        if (!empty($status)) {
            $sql .= " WHERE i.status = :st";
            $params['st'] = $status;
        }
        $sql .= " ORDER BY i.interview_date ASC, i.interview_time ASC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        sendJson(['success' => true, 'data' => $stmt->fetchAll()]);
    }

    sendError('Unauthorized role for interview schedules.', 403);
}

// 2. POST: Schedule an interview (Admin or Placement Officer)
if ($method === 'POST') {
    $user = requireRole(['admin', 'officer']);
    $data = getRequestData();

    $studentId = (int)($data['student_id'] ?? 0);
    $driveId = !empty($data['drive_id']) ? (int)$data['drive_id'] : null;
    $applicationId = !empty($data['application_id']) ? (int)$data['application_id'] : null;
    $companyName = trim($data['company_name'] ?? '');
    $jobDesignation = trim($data['job_designation'] ?? '');
    $interviewDate = trim($data['interview_date'] ?? '');
    $interviewTime = trim($data['interview_time'] ?? '');
    $interviewMode = in_array($data['interview_mode'] ?? '', ['Online', 'Offline']) ? $data['interview_mode'] : 'Online';
    $locationOrLink = trim($data['location_or_link'] ?? '');
    $instructions = trim($data['instructions'] ?? '');

    if ($studentId <= 0 || empty($companyName) || empty($jobDesignation) || empty($interviewDate) || empty($interviewTime)) {
        sendError('Student, Company Name, Job Role, Date, and Time are required.');
    }

    // Verify student exists & get their user_id for notifications
    $stStmt = $pdo->prepare("SELECT s.id, s.user_id, u.name, u.email FROM students s JOIN users u ON s.user_id = u.id WHERE s.id = :sid LIMIT 1");
    $stStmt->execute(['sid' => $studentId]);
    $st = $stStmt->fetch();
    if (!$st) sendError('Student not found.', 404);

    $stmt = $pdo->prepare("
        INSERT INTO interview_schedules 
        (drive_id, application_id, student_id, company_name, job_designation, interview_date, interview_time, interview_mode, location_or_link, instructions, status, created_by)
        VALUES (:did, :aid, :sid, :comp, :role, :idate, :itime, :mode, :loc, :inst, 'Scheduled', :uid)
    ");
    $stmt->execute([
        'did' => $driveId,
        'aid' => $applicationId,
        'sid' => $studentId,
        'comp' => sanitizeString($companyName),
        'role' => sanitizeString($jobDesignation),
        'idate' => $interviewDate,
        'itime' => $interviewTime,
        'mode' => $interviewMode,
        'loc' => sanitizeString($locationOrLink),
        'inst' => sanitizeString($instructions),
        'uid' => $user['id']
    ]);
    $interviewId = (int)$pdo->lastInsertId();

    // Update application status to 'Interview' if application ID provided
    if ($applicationId > 0) {
        $pdo->prepare("UPDATE applications SET status = 'Interview' WHERE id = :aid")->execute(['aid' => $applicationId]);
    }

    // Create high-priority reminder notification for student
    $formattedDate = date('d M Y', strtotime($interviewDate));
    $formattedTime = date('h:i A', strtotime($interviewTime));
    createNotification(
        (int)$st['user_id'],
        "Interview Scheduled: {$companyName}",
        "Reminder: Your interview with {$companyName} for {$jobDesignation} is scheduled for {$formattedDate} at {$formattedTime} ({$interviewMode}).",
        'interview',
        $interviewId
    );

    logAudit('Schedule Interview', "Scheduled interview for {$st['name']} with {$companyName} on {$interviewDate}", $user['id']);

    sendJson([
        'success' => true,
        'message' => "Interview scheduled successfully and notification sent to {$st['name']}!",
        'interview_id' => $interviewId
    ], 201);
}

// 3. PUT: Update interview status or reschedule
if ($method === 'PUT') {
    $user = requireRole(['admin', 'officer']);
    $data = getRequestData();
    $id = (int)($data['id'] ?? 0);
    $status = trim($data['status'] ?? '');
    $notes = trim($data['notes'] ?? '');

    if ($id <= 0 || empty($status)) {
        sendError('Interview ID and status are required.');
    }

    $stmt = $pdo->prepare("
        SELECT i.*, s.user_id AS student_user_id, u.name AS student_name
        FROM interview_schedules i
        JOIN students s ON i.student_id = s.id
        JOIN users u ON s.user_id = u.id
        WHERE i.id = :id LIMIT 1
    ");
    $stmt->execute(['id' => $id]);
    $iv = $stmt->fetch();
    if (!$iv) sendError('Interview record not found.', 404);

    $upd = $pdo->prepare("UPDATE interview_schedules SET status = :st, updated_at = NOW() WHERE id = :id");
    $upd->execute(['st' => $status, 'id' => $id]);

    // Send status change notification to student
    createNotification(
        (int)$iv['student_user_id'],
        "Interview Status Update: {$iv['company_name']}",
        "Your interview status with {$iv['company_name']} has been updated to: {$status}.",
        'interview',
        $id
    );

    logAudit('Update Interview', "Updated interview ID: {$id} status to {$status}", $user['id']);
    sendJson(['success' => true, 'message' => "Interview status updated to {$status}."]);
}

sendError('Method Not Allowed', 405);
