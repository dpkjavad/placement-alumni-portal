<?php
/**
 * API: Student-Alumni Direct Chat Requests & Management
 * Implements Phase 8: Student-Alumni Request and Response Workflow
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireLogin();
$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

// 1. GET: Fetch chat requests
if ($method === 'GET') {
    if ($user['role'] === 'student') {
        $studentId = (int)($user['student_profile']['id'] ?? 0);
        $stmt = $pdo->prepare("
            SELECT cr.*, 
                   u.name AS alumni_name, u.avatar AS alumni_avatar, a.company, a.job_role,
                   (SELECT COUNT(*) FROM chat_messages cm WHERE cm.request_id = cr.id AND cm.recipient_id = :uid AND cm.is_read = 0) AS unread_count
            FROM chat_requests cr
            JOIN alumni a ON cr.alumni_id = a.id
            JOIN users u ON a.user_id = u.id
            WHERE cr.student_id = :sid
            ORDER BY cr.updated_at DESC
        ");
        $stmt->execute(['sid' => $studentId, 'uid' => $user['id']]);
        $requests = $stmt->fetchAll();
        sendJson(['success' => true, 'data' => $requests]);
    } elseif ($user['role'] === 'alumni') {
        $alumniId = (int)($user['alumni_profile']['id'] ?? 0);
        $stmt = $pdo->prepare("
            SELECT cr.*, 
                   u.name AS student_name, u.avatar AS student_avatar, s.branch, s.cgpa, s.roll_no,
                   (SELECT COUNT(*) FROM chat_messages cm WHERE cm.request_id = cr.id AND cm.recipient_id = :uid AND cm.is_read = 0) AS unread_count
            FROM chat_requests cr
            JOIN students s ON cr.student_id = s.id
            JOIN users u ON s.user_id = u.id
            WHERE cr.alumni_id = :aid
            ORDER BY cr.status = 'pending' DESC, cr.updated_at DESC
        ");
        $stmt->execute(['aid' => $alumniId, 'uid' => $user['id']]);
        $requests = $stmt->fetchAll();
        sendJson(['success' => true, 'data' => $requests]);
    } elseif (in_array($user['role'], ['admin', 'officer'])) {
        $stmt = $pdo->query("
            SELECT cr.*,
                   su.name AS student_name, au.name AS alumni_name,
                   (SELECT COUNT(*) FROM chat_messages cm WHERE cm.request_id = cr.id) AS total_messages,
                   (SELECT COUNT(*) FROM chat_messages cm WHERE cm.request_id = cr.id AND cm.is_reported = 1) AS reported_count
            FROM chat_requests cr
            JOIN students s ON cr.student_id = s.id
            JOIN users su ON s.user_id = su.id
            JOIN alumni a ON cr.alumni_id = a.id
            JOIN users au ON a.user_id = au.id
            ORDER BY cr.id DESC
        ");
        sendJson(['success' => true, 'data' => $stmt->fetchAll()]);
    }

    sendError('Unauthorized role for chat requests.', 403);
}

// 2. POST: Student sends chat request to Alumni
if ($method === 'POST') {
    $user = requireRole('student');
    $data = getRequestData();
    $studentId = (int)($user['student_profile']['id'] ?? 0);
    $alumniId = (int)($data['alumni_id'] ?? 0);
    $message = trim($data['message'] ?? '');

    if ($alumniId <= 0 || empty($message)) {
        sendError('Alumni ID and message are required.');
    }

    // Check if request already exists
    $chk = $pdo->prepare("SELECT id, status FROM chat_requests WHERE student_id = :sid AND alumni_id = :aid LIMIT 1");
    $chk->execute(['sid' => $studentId, 'aid' => $alumniId]);
    $existing = $chk->fetch();

    if ($existing) {
        if ($existing['status'] === 'pending') {
            sendError('You already have a pending chat request with this alumni mentor.');
        } elseif ($existing['status'] === 'accepted') {
            sendError('Chat connection is already established with this alumni!');
        } elseif ($existing['status'] === 'blocked') {
            sendError('Communication with this profile has been restricted.', 403);
        }
    }

    // Verify alumni exists & get their user_id for notification
    $alStmt = $pdo->prepare("SELECT a.id, a.user_id, u.name FROM alumni a JOIN users u ON a.user_id = u.id WHERE a.id = :aid LIMIT 1");
    $alStmt->execute(['aid' => $alumniId]);
    $alum = $alStmt->fetch();
    if (!$alum) sendError('Alumni profile not found.', 404);

    $stmt = $pdo->prepare("
        INSERT INTO chat_requests (student_id, alumni_id, status, message)
        VALUES (:sid, :aid, 'pending', :msg)
    ");
    $stmt->execute(['sid' => $studentId, 'aid' => $alumniId, 'msg' => sanitizeString($message)]);
    $reqId = (int)$pdo->lastInsertId();

    // Dispatch notification to Alumni
    createNotification(
        (int)$alum['user_id'],
        'New Chat Request Received',
        "Student {$user['name']} has requested a 1-on-1 chat regarding career guidance: \"{$message}\"",
        'chat',
        $reqId
    );

    sendJson(['success' => true, 'message' => 'Chat request sent successfully to ' . $alum['name'] . '!']);
}

// 3. PUT: Alumni accepts or rejects request
if ($method === 'PUT') {
    $user = requireRole('alumni');
    $data = getRequestData();
    $alumniId = (int)($user['alumni_profile']['id'] ?? 0);
    $requestId = (int)($data['request_id'] ?? 0);
    $newStatus = trim($data['status'] ?? '');
    $responseMsg = trim($data['response_message'] ?? '');

    if (!in_array($newStatus, ['accepted', 'rejected'], true)) {
        sendError('Status must be either accepted or rejected.');
    }

    $chk = $pdo->prepare("
        SELECT cr.*, s.user_id AS student_user_id, u.name AS student_name
        FROM chat_requests cr
        JOIN students s ON cr.student_id = s.id
        JOIN users u ON s.user_id = u.id
        WHERE cr.id = :id AND cr.alumni_id = :aid LIMIT 1
    ");
    $chk->execute(['id' => $requestId, 'aid' => $alumniId]);
    $req = $chk->fetch();

    if (!$req) {
        sendError('Chat request not found or unauthorized.', 404);
    }

    $upd = $pdo->prepare("UPDATE chat_requests SET status = :st, response_message = :resp, updated_at = NOW() WHERE id = :id");
    $upd->execute(['st' => $newStatus, 'resp' => sanitizeString($responseMsg), 'id' => $requestId]);

    // Notify Student
    $notifTitle = ($newStatus === 'accepted') ? 'Chat Request Accepted!' : 'Chat Request Update';
    $notifMsg = ($newStatus === 'accepted')
        ? "Alumni {$user['name']} accepted your chat request! You can now start direct messaging."
        : "Alumni {$user['name']} was unable to accept your chat request at this time.";

    createNotification(
        (int)$req['student_user_id'],
        $notifTitle,
        $notifMsg,
        'chat',
        $requestId
    );

    sendJson([
        'success' => true,
        'message' => "Request has been marked as {$newStatus}."
    ]);
}

sendError('Method Not Allowed', 405);
