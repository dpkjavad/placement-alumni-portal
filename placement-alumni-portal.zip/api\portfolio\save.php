<?php
/**
 * API: Save Student Portfolio
 * POST: Updates portfolio details and child sections inside a database transaction.
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireRole(['student']);
$pdo = Database::getConnection();

$studentId = (int)($user['student_profile']['id'] ?? 0);
if ($studentId <= 0) {
    sendError('Student profile not found.', 404);
}

$data = getRequestData();
$portfolioData = $data['portfolio'] ?? $data;

// Fetch current portfolio
$pStmt = $pdo->prepare("SELECT id, slug FROM student_portfolios WHERE student_id = :sid LIMIT 1");
$pStmt->execute(['sid' => $studentId]);
$portfolio = $pStmt->fetch();

if (!$portfolio) {
    sendError('Portfolio not initialized. Please load portfolio first.', 404);
}

$portfolioId = (int)$portfolio['id'];

$headline = trim($portfolioData['headline'] ?? 'Aspiring Software Engineer');
$aboutMe = trim($portfolioData['about_me'] ?? '');
$location = trim($portfolioData['location'] ?? 'Kopargaon, Maharashtra');
$phone = trim($portfolioData['phone'] ?? '');
$email = trim($portfolioData['email'] ?? $user['email']);
$githubUrl = trim($portfolioData['github_url'] ?? '');
$linkedinUrl = trim($portfolioData['linkedin_url'] ?? '');
$websiteUrl = trim($portfolioData['website_url'] ?? '');
$template = in_array($portfolioData['template'] ?? '', ['modern', 'tech_dark', 'minimal', 'executive'], true) ? $portfolioData['template'] : 'modern';
$primaryColor = trim($portfolioData['primary_color'] ?? '#4f46e5');
$isPublished = !empty($portfolioData['is_published']) ? 1 : 0;

$pdo->beginTransaction();

try {
    // 1. Update Portfolio Header
    $updPort = $pdo->prepare("
        UPDATE student_portfolios SET
            headline = :head,
            about_me = :about,
            location = :loc,
            phone = :phone,
            email = :email,
            github_url = :gh,
            linkedin_url = :li,
            website_url = :web,
            template = :tpl,
            primary_color = :color,
            is_published = :pub,
            updated_at = NOW()
        WHERE id = :id
    ");
    $updPort->execute([
        'head' => $headline,
        'about' => $aboutMe,
        'loc' => $location,
        'phone' => $phone,
        'email' => $email,
        'gh' => $githubUrl,
        'li' => $linkedinUrl,
        'web' => $websiteUrl,
        'tpl' => $template,
        'color' => $primaryColor,
        'pub' => $isPublished,
        'id' => $portfolioId
    ]);

    // 2. Sync Education
    if (isset($portfolioData['education']) && is_array($portfolioData['education'])) {
        $pdo->prepare("DELETE FROM portfolio_education WHERE portfolio_id = :pid")->execute(['pid' => $portfolioId]);
        $insEdu = $pdo->prepare("
            INSERT INTO portfolio_education (portfolio_id, degree, institution, field_of_study, start_year, end_year, grade_cgpa, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        foreach ($portfolioData['education'] as $edu) {
            $degree = trim($edu['degree'] ?? '');
            $institution = trim($edu['institution'] ?? '');
            if (!empty($degree) && !empty($institution)) {
                $insEdu->execute([
                    $portfolioId,
                    $degree,
                    $institution,
                    trim($edu['field_of_study'] ?? ''),
                    (int)($edu['start_year'] ?? 2022),
                    !empty($edu['end_year']) ? (int)$edu['end_year'] : null,
                    trim($edu['grade_cgpa'] ?? ''),
                    trim($edu['description'] ?? '')
                ]);
            }
        }
    }

    // 3. Sync Skills
    if (isset($portfolioData['skills']) && is_array($portfolioData['skills'])) {
        $pdo->prepare("DELETE FROM portfolio_skills WHERE portfolio_id = :pid")->execute(['pid' => $portfolioId]);
        $insSkill = $pdo->prepare("
            INSERT INTO portfolio_skills (portfolio_id, skill_name, skill_type, proficiency_level)
            VALUES (?, ?, ?, ?)
        ");
        foreach ($portfolioData['skills'] as $sk) {
            $name = trim($sk['skill_name'] ?? '');
            if (!empty($name)) {
                $type = (isset($sk['skill_type']) && $sk['skill_type'] === 'soft') ? 'soft' : 'technical';
                $level = in_array(strtolower($sk['proficiency_level'] ?? ''), ['beginner', 'intermediate', 'advanced', 'expert'], true) ? strtolower($sk['proficiency_level']) : 'advanced';
                $insSkill->execute([$portfolioId, $name, $type, $level]);
            }
        }
    }

    // 4. Sync Projects
    if (isset($portfolioData['projects']) && is_array($portfolioData['projects'])) {
        $pdo->prepare("DELETE FROM portfolio_projects WHERE portfolio_id = :pid")->execute(['pid' => $portfolioId]);
        $insProj = $pdo->prepare("
            INSERT INTO portfolio_projects (portfolio_id, title, description, tech_stack, live_url, github_url, featured)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        foreach ($portfolioData['projects'] as $pr) {
            $title = trim($pr['title'] ?? '');
            if (!empty($title)) {
                $insProj->execute([
                    $portfolioId,
                    $title,
                    trim($pr['description'] ?? ''),
                    trim($pr['tech_stack'] ?? ''),
                    trim($pr['live_url'] ?? ''),
                    trim($pr['github_url'] ?? ''),
                    !empty($pr['featured']) ? 1 : 0
                ]);
            }
        }
    }

    // 5. Sync Experiences
    if (isset($portfolioData['experiences']) && is_array($portfolioData['experiences'])) {
        $pdo->prepare("DELETE FROM portfolio_experiences WHERE portfolio_id = :pid")->execute(['pid' => $portfolioId]);
        $insExp = $pdo->prepare("
            INSERT INTO portfolio_experiences (portfolio_id, type, title, company, location, start_date, end_date, is_current, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        foreach ($portfolioData['experiences'] as $ex) {
            $title = trim($ex['title'] ?? '');
            $comp = trim($ex['company'] ?? '');
            if (!empty($title) && !empty($comp)) {
                $type = (isset($ex['type']) && $ex['type'] === 'job') ? 'job' : 'internship';
                $insExp->execute([
                    $portfolioId,
                    $type,
                    $title,
                    $comp,
                    trim($ex['location'] ?? ''),
                    trim($ex['start_date'] ?? ''),
                    trim($ex['end_date'] ?? ''),
                    !empty($ex['is_current']) ? 1 : 0,
                    trim($ex['description'] ?? '')
                ]);
            }
        }
    }

    // 6. Sync Certifications
    if (isset($portfolioData['certifications']) && is_array($portfolioData['certifications'])) {
        $pdo->prepare("DELETE FROM portfolio_certifications WHERE portfolio_id = :pid")->execute(['pid' => $portfolioId]);
        $insCert = $pdo->prepare("
            INSERT INTO portfolio_certifications (portfolio_id, title, issuing_org, issue_date, credential_url)
            VALUES (?, ?, ?, ?, ?)
        ");
        foreach ($portfolioData['certifications'] as $c) {
            $title = trim($c['title'] ?? '');
            $org = trim($c['issuing_org'] ?? '');
            if (!empty($title) && !empty($org)) {
                $insCert->execute([
                    $portfolioId,
                    $title,
                    $org,
                    trim($c['issue_date'] ?? ''),
                    trim($c['credential_url'] ?? '')
                ]);
            }
        }
    }

    // 7. Sync Achievements
    if (isset($portfolioData['achievements']) && is_array($portfolioData['achievements'])) {
        $pdo->prepare("DELETE FROM portfolio_achievements WHERE portfolio_id = :pid")->execute(['pid' => $portfolioId]);
        $insAch = $pdo->prepare("
            INSERT INTO portfolio_achievements (portfolio_id, title, description, date_awarded)
            VALUES (?, ?, ?, ?)
        ");
        foreach ($portfolioData['achievements'] as $a) {
            $title = trim($a['title'] ?? '');
            if (!empty($title)) {
                $insAch->execute([
                    $portfolioId,
                    $title,
                    trim($a['description'] ?? ''),
                    trim($a['date_awarded'] ?? '')
                ]);
            }
        }
    }

    $pdo->commit();

    sendJson([
        'success' => true,
        'message' => 'Portfolio updated successfully!',
        'portfolio_id' => $portfolioId
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    sendError('Failed to save portfolio: ' . $e->getMessage(), 500);
}
