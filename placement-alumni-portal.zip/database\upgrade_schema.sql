-- ========================================================================
-- SU T&P (Sanjivani Placement & Alumni Portal)
-- Enterprise Schema Upgrade Script
-- Implements: Alumni Experience, Student Profiles, Direct Chat,
-- Interview Scheduling, Notifications, Audit Logs, Referrals, Prep Hub
-- ========================================================================

USE `placement_alumni_portal`;

-- 1. Upgrade Alumni Table with Dynamic Experience & Career Details
ALTER TABLE `alumni`
  ADD COLUMN IF NOT EXISTS `joining_date` DATE NULL AFTER `company`,
  ADD COLUMN IF NOT EXISTS `department` VARCHAR(100) NULL AFTER `branch`,
  ADD COLUMN IF NOT EXISTS `experience_years` DECIMAL(4,1) NULL AFTER `joining_date`,
  ADD COLUMN IF NOT EXISTS `employment_history` JSON NULL AFTER `bio`;

-- 2. Upgrade Students Table with Coding Profiles & Resume Tracking
ALTER TABLE `students`
  ADD COLUMN IF NOT EXISTS `github_url` VARCHAR(255) NULL AFTER `skills`,
  ADD COLUMN IF NOT EXISTS `hackerrank_url` VARCHAR(255) NULL AFTER `github_url`,
  ADD COLUMN IF NOT EXISTS `linkedin_url` VARCHAR(255) NULL AFTER `hackerrank_url`,
  ADD COLUMN IF NOT EXISTS `resume_updated_at` TIMESTAMP NULL AFTER `resume`;

-- 3. Upgrade Resumes Table for Full Versioning
ALTER TABLE `resumes`
  ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) DEFAULT 1 AFTER `file_size`,
  ADD COLUMN IF NOT EXISTS `version_number` INT DEFAULT 1 AFTER `is_active`;

-- 4. Create Student-Alumni Chat Requests Table
CREATE TABLE IF NOT EXISTS `chat_requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` INT NOT NULL,
  `alumni_id` INT NOT NULL,
  `status` ENUM('pending', 'accepted', 'rejected', 'blocked') DEFAULT 'pending',
  `message` TEXT NOT NULL,
  `response_message` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_student` (`student_id`),
  INDEX `idx_alumni` (`alumni_id`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Create Direct Chat Messages Table
CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `request_id` INT NOT NULL,
  `sender_id` INT NOT NULL,
  `recipient_id` INT NOT NULL,
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `is_reported` TINYINT(1) DEFAULT 0,
  `report_reason` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_request` (`request_id`),
  INDEX `idx_sender` (`sender_id`),
  INDEX `idx_recipient` (`recipient_id`),
  INDEX `idx_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Create Interview Scheduling Table
CREATE TABLE IF NOT EXISTS `interview_schedules` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `drive_id` INT NULL,
  `application_id` INT NULL,
  `student_id` INT NOT NULL,
  `company_name` VARCHAR(150) NOT NULL,
  `job_designation` VARCHAR(150) NOT NULL,
  `interview_date` DATE NOT NULL,
  `interview_time` TIME NOT NULL,
  `interview_mode` ENUM('Online', 'Offline') DEFAULT 'Online',
  `location_or_link` VARCHAR(255) NOT NULL,
  `instructions` TEXT NULL,
  `status` ENUM('Scheduled', 'Completed', 'Cancelled', 'Rescheduled') DEFAULT 'Scheduled',
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_student` (`student_id`),
  INDEX `idx_drive` (`drive_id`),
  INDEX `idx_date` (`interview_date`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Create Personalized Notifications Table
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `message` TEXT NOT NULL,
  `type` ENUM('interview', 'chat', 'application', 'drive', 'announcement', 'system') DEFAULT 'system',
  `reference_id` INT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user` (`user_id`),
  INDEX `idx_read` (`is_read`),
  INDEX `idx_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Create Enterprise Audit Logs Table
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NULL,
  `user_email` VARCHAR(120) NULL,
  `action` VARCHAR(100) NOT NULL,
  `details` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user` (`user_id`),
  INDEX `idx_action` (`action`),
  INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Create Official Institutional Announcements Table
CREATE TABLE IF NOT EXISTS `announcements` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `target_role` ENUM('all', 'student', 'alumni', 'officer') DEFAULT 'all',
  `is_active` TINYINT(1) DEFAULT 1,
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_role` (`target_role`),
  INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Create Alumni Referrals System Tables
CREATE TABLE IF NOT EXISTS `alumni_referrals` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `alumni_id` INT NOT NULL,
  `company_name` VARCHAR(120) NOT NULL,
  `job_title` VARCHAR(120) NOT NULL,
  `job_url` VARCHAR(255) NULL,
  `requirements` TEXT NOT NULL,
  `location` VARCHAR(100) NULL,
  `deadline` DATE NULL,
  `status` ENUM('open', 'closed') DEFAULT 'open',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_alumni` (`alumni_id`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `referral_applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `referral_id` INT NOT NULL,
  `student_id` INT NOT NULL,
  `resume_url` VARCHAR(255) NULL,
  `notes` TEXT NULL,
  `status` ENUM('applied', 'referred', 'rejected') DEFAULT 'applied',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_referral` (`referral_id`),
  INDEX `idx_student` (`student_id`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Create Interview Preparation Hub Table
CREATE TABLE IF NOT EXISTS `interview_prep_materials` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category` ENUM('Technical', 'HR', 'Aptitude', 'Coding', 'Company-Specific') NOT NULL,
  `company_tag` VARCHAR(100) NULL,
  `title` VARCHAR(255) NOT NULL,
  `question` TEXT NOT NULL,
  `answer_guide` TEXT NOT NULL,
  `tips` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_category` (`category`),
  INDEX `idx_company` (`company_tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
