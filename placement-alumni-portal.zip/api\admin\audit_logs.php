<?php
/**
 * API: Enterprise Audit Logs
 * Implements Phase 7 & 10: Audit Logging & Activity Review
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireRole(['admin']);
$pdo = Database::getConnection();

$limit = isset($_GET['limit']) ? min(100, max(10, (int)$_GET['limit'])) : 50;
$stmt = $pdo->prepare("
    SELECT al.*, u.name AS actor_name
    FROM audit_logs al
    LEFT JOIN users u ON al.user_id = u.id
    ORDER BY al.id DESC
    LIMIT :lim
");
$stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
$stmt->execute();

sendJson([
    'success' => true,
    'data' => $stmt->fetchAll()
]);
