<?php
/**
 * API: Delete Uploaded Resume
 * DELETE / POST: ?id=...
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireRole(['student']);
$pdo = Database::getConnection();

$studentId = (int)($user['student_profile']['id'] ?? 0);
$resumeId = (int)($_GET['id'] ?? ($_POST['id'] ?? 0));

if ($resumeId <= 0) {
    sendError('Valid resume ID is required.');
}

$stmt = $pdo->prepare("SELECT * FROM resumes WHERE id = :id AND student_id = :sid LIMIT 1");
$stmt->execute(['id' => $resumeId, 'sid' => $studentId]);
$resume = $stmt->fetch();

if (!$resume) {
    sendError('Resume not found or access denied.', 404);
}

// Delete file from disk if exists
$targetDir = defined('UPLOAD_PATH') ? UPLOAD_PATH : (__DIR__ . '/../../uploads/resumes');
$filePath = $targetDir . '/' . $resume['stored_filename'];
if (is_file($filePath)) {
    @unlink($filePath);
}

// Delete from DB (cascades to ats_analyses and job_comparisons)
$del = $pdo->prepare("DELETE FROM resumes WHERE id = :id");
$del->execute(['id' => $resumeId]);

sendJson([
    'success' => true,
    'message' => 'Resume and analysis history deleted successfully.'
]);
