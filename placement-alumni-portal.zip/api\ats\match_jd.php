<?php
/**
 * API: Match Resume with Job Description
 * POST: { resume_id?: int, job_description: string, job_title?: string, job_company?: string }
 */

require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/AtsEngine.php';

$user = requireRole(['student']);
$pdo = Database::getConnection();

$studentId = (int)($user['student_profile']['id'] ?? 0);
if ($studentId <= 0) {
    sendError('Student profile not found.', 404);
}

$data = getRequestData();
$jdText = trim($data['job_description'] ?? '');
$jobTitle = trim($data['job_title'] ?? 'Software Engineer');
$jobCompany = trim($data['job_company'] ?? 'Target Employer');
$resumeId = (int)($data['resume_id'] ?? 0);

if (empty($jdText)) {
    sendError('Please paste a job description to perform ATS matching.');
}

if (strlen($jdText) < 50) {
    sendError('Job description is too short. Please paste the full job posting including requirements and qualifications.');
}

// Get resume
if ($resumeId > 0) {
    $rStmt = $pdo->prepare("SELECT * FROM resumes WHERE id = :id AND student_id = :sid LIMIT 1");
    $rStmt->execute(['id' => $resumeId, 'sid' => $studentId]);
    $resume = $rStmt->fetch();
} else {
    $rStmt = $pdo->prepare("SELECT * FROM resumes WHERE student_id = :sid ORDER BY id DESC LIMIT 1");
    $rStmt->execute(['sid' => $studentId]);
    $resume = $rStmt->fetch();
}

if (!$resume) {
    sendError('Please upload your resume first before running Job Description matching.', 404);
}

// Run JD Match
$matchReport = AtsEngine::matchJobDescription($resume['extracted_text'] ?: '', $jdText);

// Save comparison to database
$insComp = $pdo->prepare("
    INSERT INTO job_comparisons (student_id, resume_id, job_title, job_company, job_description, match_percentage, matching_skills, missing_skills, matching_keywords, missing_keywords, suggestions)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");
$insComp->execute([
    $studentId,
    $resume['id'],
    $jobTitle,
    $jobCompany,
    $jdText,
    $matchReport['match_percentage'],
    json_encode($matchReport['matched_skills']),
    json_encode($matchReport['missing_skills']),
    json_encode($matchReport['matched_keywords']),
    json_encode($matchReport['missing_keywords']),
    json_encode($matchReport['suggestions'])
]);
$comparisonId = (int)$pdo->lastInsertId();

sendJson([
    'success' => true,
    'message' => 'Job description comparison generated successfully!',
    'comparison_id' => $comparisonId,
    'job_title' => $jobTitle,
    'job_company' => $jobCompany,
    'match_report' => $matchReport,
    'resume_filename' => $resume['original_filename']
]);
