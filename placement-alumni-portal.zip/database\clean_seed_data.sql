-- ========================================================================
-- SU T&P (Sanjivani Placement & Alumni Portal)
-- Authentic Clean Seed Data: 1 Kopargaon Alumni, Real Interview Prep, Announcements
-- ========================================================================

USE `placement_alumni_portal`;

-- 1. Configure the single authentic Kopargaon Alumnus
-- Ensure User exists for Nilesh Kulkarni (ID 15 or create)
UPDATE `users` SET 
  `name` = 'Er. Nilesh Kulkarni',
  `email` = 'nilesh.kulkarni@sanjivani.edu.in',
  `role` = 'alumni',
  `avatar` = 'alumni_kopargaon.png'
WHERE `id` = 15;

-- Update or Insert Alumni profile
DELETE FROM `alumni` WHERE `user_id` != 15;

INSERT INTO `alumni` (`id`, `user_id`, `graduation_year`, `branch`, `department`, `company`, `joining_date`, `job_role`, `location`, `skills`, `linkedin`, `bio`, `available_for_mentorship`)
VALUES (
  1,
  15,
  2021,
  'Computer Engineering',
  'Department of Computer Engineering, Sanjivani Kopargaon',
  'Tata Consultancy Services',
  '2021-07-15',
  'Senior Software Engineer',
  'Kopargaon / Pune',
  'Java, Spring Boot, MySQL, Microservices, System Design, Data Structures',
  'https://www.linkedin.com/school/sanjivani-college-of-engineering-kopargaon/',
  'Alumnus of Sanjivani College of Engineering, Kopargaon (Batch of 2021). Actively assisting current students with technical interview prep, system design, and placement guidance.',
  1
)
ON DUPLICATE KEY UPDATE
  `graduation_year` = 2021,
  `branch` = 'Computer Engineering',
  `department` = 'Department of Computer Engineering, Sanjivani Kopargaon',
  `company` = 'Tata Consultancy Services',
  `joining_date` = '2021-07-15',
  `job_role` = 'Senior Software Engineer',
  `location` = 'Kopargaon / Pune',
  `skills` = 'Java, Spring Boot, MySQL, Microservices, System Design, Data Structures',
  `linkedin` = 'https://www.linkedin.com/school/sanjivani-college-of-engineering-kopargaon/',
  `bio` = 'Alumnus of Sanjivani College of Engineering, Kopargaon (Batch of 2021). Actively assisting current students with technical interview prep, system design, and placement guidance.',
  `available_for_mentorship` = 1;

-- Clean other dummy alumni users
DELETE FROM `users` WHERE `role` = 'alumni' AND `id` != 15;

-- 2. Populate Authentic Interview Preparation Hub Materials
TRUNCATE TABLE `interview_prep_materials`;

INSERT INTO `interview_prep_materials` (`category`, `company_tag`, `title`, `question`, `answer_guide`, `tips`) VALUES
('Technical', 'General Tech', 'Object-Oriented Programming (OOP) Principles', 
 'Explain the four core principles of OOP with real-world institutional software examples.',
 '1. Encapsulation: Bundling data and methods that operate on that data within a single unit (class) while restricting direct access using private/protected access modifiers.\n2. Abstraction: Hiding internal implementation complexities and exposing only essential interfaces (e.g., using Abstract Classes and Interfaces in Java/C++).\n3. Inheritance: Mechanism where a new class derives properties and behaviors from an existing parent class to promote code reusability (IS-A relationship).\n4. Polymorphism: Ability of an entity to take multiple forms—compile-time (Method Overloading) and run-time (Method Overriding via dynamic dispatch).',
 'Always emphasize modularity, code maintainability, and loose coupling when explaining OOP in technical interviews.'),

('Technical', 'Database', 'Indexing and Query Optimization in Relational Databases',
 'What is database indexing? When should you use B-Tree vs Hash indexes, and how do you optimize slow queries?',
 'An index is a data structure (commonly B+ Tree) that enhances the speed of data retrieval on database tables at the cost of additional storage and slower writes. B-Trees are ideal for range queries (BETWEEN, <, >) and sorted order (ORDER BY). Hash indexes provide O(1) exact lookups but cannot perform range searches. Optimization involves inspecting the EXPLAIN execution plan, creating composite indexes on WHERE/JOIN columns, avoiding SELECT *, and avoiding functions on indexed columns.',
 'Mention composite indexing and explain the leftmost prefix rule in multi-column indexes.'),

('Coding', 'Algorithms', 'Two Pointer Technique & Sliding Window Strategy',
 'How does the Sliding Window technique reduce time complexity from O(N^2) to O(N)? Give an example.',
 'The sliding window algorithm maintains a subarray or substring window with two pointers (left and right). Instead of recomputing results for all nested subarrays from scratch (O(N^2)), it incrementally expands the right boundary and shrinks the left boundary when a condition is violated, processing each element at most twice (O(N) time and O(1) extra space). Examples: Longest Substring Without Repeating Characters, Maximum Sum Subarray of size K.',
 'Always verify edge cases: empty strings, single-character inputs, and all unique or all duplicate characters.'),

('HR', 'Behavioral', 'Tell Me About a Challenging Project Conflict & Resolution',
 'Describe a situation where you encountered a technical disagreement or deadline conflict during a team project.',
 'Use the STAR format:\n- Situation: During our final-year capstone project, our team had conflicting opinions between adopting a monolithic architecture vs microservices.\n- Task: We had a tight 3-week deadline to produce an MVP for institutional evaluation.\n- Action: I scheduled a technical review meeting where we documented pros and cons, assessed our team skills and server hosting constraints, and agreed on a clean modular monolith that satisfied both timeline and scalability.\n- Result: We delivered the project on time with 100% test coverage and high faculty commendations.',
 'Never criticize teammates or faculty. Focus on objective decision-making, mutual respect, and outcome delivery.'),

('Aptitude', 'Quant & Logic', 'Time, Speed, Distance & Relative Motion',
 'Two trains 150m and 200m in length run on parallel tracks in opposite directions at 54 km/h and 72 km/h. Find the time taken to cross each other.',
 '1. Relative Speed: (54 + 72) km/h = 126 km/h.\n2. Convert to m/s: 126 * (5/18) = 35 m/s.\n3. Total Distance to cross: 150m + 200m = 350m.\n4. Time = Distance / Speed = 350 / 35 = 10 seconds.',
 'Always remember: when moving in opposite directions, speeds add up; in the same direction, speeds subtract.'),

('Company-Specific', 'TCS / Mass Recruiters', 'TCS NQT Coding & Core Java Interview Preparation',
 'Common TCS interview topics: String manipulation, frequency counting, collections framework, and JVM memory lifecycle.',
 'Key topics to master for TCS Technical rounds:\n1. String immutability and difference between String, StringBuilder, and StringBuffer.\n2. Garbage collection fundamentals (Stack vs Heap, Eden space, Tenured generation).\n3. Difference between ArrayList and LinkedList, HashMap collision resolution (Bucket arrays, LinkedList, Red-Black Trees in Java 8+).\n4. Exception handling: Checked vs Unchecked exceptions.',
 'Be prepared to write clean, syntactically correct code on paper or plain text editor without IDE autocompletion.');

-- 3. Populate Official Institutional Announcements
TRUNCATE TABLE `announcements`;

INSERT INTO `announcements` (`title`, `content`, `target_role`, `is_active`, `created_by`) VALUES
('Welcome to SU T&P Official Portal', 'Sanjivani University Training & Placement Cell portal is now active for campus placement drives, student portfolio management, and alumni mentorship.', 'all', 1, 1),
('Mandatory Resume Upload & Profile Update', 'All final year and pre-final year students are requested to update their technical skills, coding profiles (GitHub, HackerRank, LinkedIn), and upload their latest resumes.', 'student', 1, 1),
('Alumni Mentorship Network Online', 'Students can now connect with our verified Kopargaon alumni for one-on-one technical mock interviews and career guidance.', 'student', 1, 1);
