<?php
$h = file_get_contents(__DIR__ . '/../index.html');

preg_match_all('/<div\b[^>]*>/i', $h, $divO);
preg_match_all('/<\/div>/i', $h, $divC);
preg_match_all('/<section\b[^>]*>/i', $h, $secO);
preg_match_all('/<\/section>/i', $h, $secC);
preg_match_all('/<main\b[^>]*>/i', $h, $mO);
preg_match_all('/<\/main>/i', $h, $mC);

echo "DIV: " . count($divO[0]) . " opened vs " . count($divC[0]) . " closed\n";
echo "SECTION: " . count($secO[0]) . " opened vs " . count($secC[0]) . " closed\n";
echo "MAIN: " . count($mO[0]) . " opened vs " . count($mC[0]) . " closed\n";

if (strpos($h, '8668680085') !== false) {
    echo "Official Contact Number 8668680085 found.\n";
} else {
    echo "ERROR: Contact number missing!\n";
}

if (strpos($h, 'Er. Nilesh Kulkarni') !== false) {
    echo "Kopargaon Alumnus Er. Nilesh Kulkarni found.\n";
} else {
    echo "ERROR: Nilesh Kulkarni missing!\n";
}

if (strpos($h, '[ALUMNI DETAILS TO BE PROVIDED BY WEBSITE OWNER]') !== false) {
    echo "Alumni placeholder slots found.\n";
} else {
    echo "ERROR: Placeholder slot missing!\n";
}

// Check for forbidden demo names or demo logins
$forbidden = ['demo-login', 'quick-login', 'fillDemo', 'Priya Sharma', 'demo_student'];
foreach ($forbidden as $f) {
    if (stripos($h, $f) !== false) {
        echo "WARNING: Forbidden demo string '$f' detected in index.html!\n";
    }
}
echo "Verification complete.\n";
