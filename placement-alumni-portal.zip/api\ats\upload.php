<?php
/**
 * API: Upload Resume for ATS Checker
 * POST (Multipart): 'resume' (PDF or DOCX), OR 'use_profile_resume' = 1
 */

require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/AtsEngine.php';

$user = requireRole(['student']);
$pdo = Database::getConnection();

$studentId = (int)($user['student_profile']['id'] ?? 0);
if ($studentId <= 0) {
    sendError('Student profile not found. Please log in as a student.', 404);
}

$targetDir = defined('UPLOAD_PATH') ? UPLOAD_PATH : realpath(__DIR__ . '/../../uploads/resumes');
if (!$targetDir || !is_dir($targetDir)) {
    $targetDir = __DIR__ . '/../../uploads/resumes';
    if (!is_dir($targetDir)) {
        @mkdir($targetDir, 0777, true);
    }
}

$storedName = '';
$origName = '';
$fileSize = 0;
$ext = '';
$targetPath = '';

// Option A: Use student's existing profile resume
if (!empty($_POST['use_profile_resume'])) {
    $currentResume = $user['student_profile']['resume'] ?? '';
    if (empty($currentResume)) {
        sendError('No resume currently attached to your student profile. Please select a file to upload.', 400);
    }
    $existingPath = $targetDir . '/' . $currentResume;
    if (!file_exists($existingPath)) {
        sendError("Profile resume file '$currentResume' not found on server storage.", 404);
    }
    $origName = $currentResume;
    $storedName = $currentResume;
    $fileSize = filesize($existingPath);
    $ext = strtolower(pathinfo($currentResume, PATHINFO_EXTENSION));
    $targetPath = $existingPath;
} else {
    // Option B: Upload new resume file
    if (!isset($_FILES['resume'])) {
        sendError('No resume file was uploaded in the request. Please choose a file.', 400);
    }

    $uploadErr = $_FILES['resume']['error'];
    if ($uploadErr !== UPLOAD_ERR_OK) {
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE   => 'The uploaded file exceeds the upload_max_filesize directive in php.ini.',
            UPLOAD_ERR_FORM_SIZE  => 'The uploaded file exceeds the MAX_FILE_SIZE directive in the HTML form.',
            UPLOAD_ERR_PARTIAL    => 'The uploaded file was only partially uploaded.',
            UPLOAD_ERR_NO_FILE    => 'No file was selected.',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder on server.',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
            UPLOAD_ERR_EXTENSION  => 'A PHP extension stopped the file upload.'
        ];
        sendError($errorMessages[$uploadErr] ?? ('Upload failed with error code: ' . $uploadErr), 400);
    }

    $file = $_FILES['resume'];
    $origName = basename($file['name']);
    $fileSize = (int)$file['size'];
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));

    if (!in_array($ext, ['pdf', 'docx', 'doc'], true)) {
        sendError('Invalid file format (' . htmlspecialchars($ext) . '). Only PDF and DOCX documents are supported.', 400);
    }

    $maxBytes = defined('MAX_UPLOAD_SIZE') ? MAX_UPLOAD_SIZE : (10 * 1024 * 1024);
    if ($fileSize > $maxBytes) {
        sendError('File size (' . round($fileSize / 1024 / 1024, 2) . ' MB) exceeds the limit of ' . round($maxBytes / 1024 / 1024) . ' MB.', 400);
    }

    $storedName = 'resume_' . $studentId . '_' . time() . '.' . $ext;
    $targetPath = $targetDir . '/' . $storedName;

    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        // Fallback for some Windows dev setups
        if (!@copy($file['tmp_name'], $targetPath)) {
            sendError('Failed to save uploaded file on the server. Please check folder permissions.', 500);
        }
    }
}

// Extract plain text
$extractedText = '';
if ($ext === 'docx') {
    $extractedText = AtsEngine::extractDocxText($targetPath);
} elseif ($ext === 'pdf') {
    $extractedText = AtsEngine::extractPdfText($targetPath);
} else {
    // Plain doc / text fallback
    $raw = @file_get_contents($targetPath);
    $extractedText = preg_replace('/[^a-zA-Z0-9\s.,@:;()\/-]/', ' ', $raw ?: '');
}

// If extracted text is very short (e.g. image-only PDF), combine with student profile info for baseline analysis
if (strlen(trim($extractedText)) < 30) {
    $extractedText = "{$user['name']}\nEmail: {$user['email']}\nBranch: {$user['student_profile']['branch']}\nCGPA: {$user['student_profile']['cgpa']}\nSkills: {$user['student_profile']['skills']}\nSanjivani University Kopargaon";
}

// Insert into resumes table
$insRes = $pdo->prepare("
    INSERT INTO resumes (student_id, original_filename, stored_filename, file_path, file_type, file_size, extracted_text)
    VALUES (:sid, :orig, :stored, :path, :type, :size, :text)
");
$insRes->execute([
    'sid' => $studentId,
    'orig' => $origName,
    'stored' => $storedName,
    'path' => 'uploads/resumes/' . $storedName,
    'type' => $ext,
    'size' => $fileSize,
    'text' => $extractedText
]);
$resumeId = (int)$pdo->lastInsertId();

// Update student default resume pointer in students table
$pdo->prepare("UPDATE students SET resume = :res WHERE id = :id")->execute([
    'res' => $storedName,
    'id' => $studentId
]);

// Run immediate 10-point ATS Analysis
$analysis = AtsEngine::analyzeResume($extractedText);

// Store analysis
$insAts = $pdo->prepare("
    INSERT INTO ats_analyses (student_id, resume_id, overall_score, section_scores, extracted_data, strengths, weaknesses, suggestions, formatting_feedback)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
");
$insAts->execute([
    $studentId,
    $resumeId,
    $analysis['overall_score'],
    json_encode($analysis['section_scores']),
    json_encode($analysis['extracted_data']),
    json_encode($analysis['strengths']),
    json_encode($analysis['weaknesses']),
    json_encode($analysis['suggestions']),
    json_encode($analysis['formatting_feedback'])
]);
$analysisId = (int)$pdo->lastInsertId();

sendJson([
    'success' => true,
    'message' => 'Resume uploaded and analyzed successfully!',
    'resume' => [
        'id' => $resumeId,
        'original_filename' => $origName,
        'stored_filename' => $storedName,
        'file_type' => $ext,
        'file_size' => $fileSize,
        'file_url' => 'uploads/resumes/' . $storedName,
        'uploaded_at' => date('Y-m-d H:i:s')
    ],
    'analysis_id' => $analysisId,
    'analysis' => $analysis
]);
