<?php
/**
 * API: Institutional Announcements Management
 * Implements Phase 10: Announcements Control
 */

require_once __DIR__ . '/../../config/auth.php';

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $user = getCurrentUser();
    $role = $user['role'] ?? 'all';

    $sql = "SELECT a.*, u.name AS author_name FROM announcements a JOIN users u ON a.created_by = u.id WHERE a.is_active = 1";
    $params = [];

    if ($role !== 'admin' && $role !== 'officer') {
        $sql .= " AND (a.target_role = 'all' OR a.target_role = :r)";
        $params['r'] = $role;
    }
    $sql .= " ORDER BY a.id DESC LIMIT 20";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    sendJson(['success' => true, 'data' => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    $user = requireRole(['admin', 'officer']);
    $data = getRequestData();
    $title = trim($data['title'] ?? '');
    $content = trim($data['content'] ?? '');
    $targetRole = in_array($data['target_role'] ?? '', ['all', 'student', 'alumni', 'officer']) ? $data['target_role'] : 'all';

    if (empty($title) || empty($content)) {
        sendError('Title and content are required.');
    }

    $stmt = $pdo->prepare("INSERT INTO announcements (title, content, target_role, is_active, created_by) VALUES (:t, :c, :tr, 1, :uid)");
    $stmt->execute(['t' => sanitizeString($title), 'c' => sanitizeString($content), 'tr' => $targetRole, 'uid' => $user['id']]);

    logAudit('Create Announcement', "Published announcement: {$title}", $user['id']);
    sendJson(['success' => true, 'message' => 'Announcement published successfully!'], 201);
}

if ($method === 'DELETE') {
    $user = requireRole(['admin', 'officer']);
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) sendError('Announcement ID required.');

    $pdo->prepare("DELETE FROM announcements WHERE id = :id")->execute(['id' => $id]);
    logAudit('Delete Announcement', "Deleted announcement ID: {$id}", $user['id']);
    sendJson(['success' => true, 'message' => 'Announcement deleted.']);
}

sendError('Method Not Allowed', 405);
