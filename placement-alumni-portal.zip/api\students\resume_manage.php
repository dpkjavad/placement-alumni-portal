<?php
/**
 * API: Enterprise Student Resume Management
 * Handles: Versioned Uploads, History, Set Active, Download, and Deletion
 * Complies with Phase 4: Resume Management
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireLogin();
$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

// Resolve student ID based on permissions
$studentId = 0;
if ($user['role'] === 'student') {
    $studentId = (int)($user['student_profile']['id'] ?? 0);
} elseif (in_array($user['role'], ['admin', 'officer'])) {
    $studentId = (int)($_REQUEST['student_id'] ?? 0);
}

if ($studentId <= 0) {
    sendError('Student profile not found or ID not provided.', 400);
}

// 1. GET: List all versioned resumes for student
if ($method === 'GET') {
    $action = $_GET['action'] ?? 'list';

    if ($action === 'download') {
        $resumeId = (int)($_GET['id'] ?? 0);
        $stmt = $pdo->prepare("SELECT * FROM resumes WHERE id = :id AND student_id = :sid LIMIT 1");
        $stmt->execute(['id' => $resumeId, 'sid' => $studentId]);
        $res = $stmt->fetch();
        if (!$res) {
            sendError('Resume not found or unauthorized.', 404);
        }
        $filePath = __DIR__ . '/../../' . $res['file_path'];
        if (!file_exists($filePath)) {
            sendError('File not found on server storage.', 404);
        }

        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($res['original_filename']) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT id, original_filename, stored_filename, file_path, file_type, file_size, is_active, version_number, uploaded_at
        FROM resumes
        WHERE student_id = :sid
        ORDER BY id DESC
    ");
    $stmt->execute(['sid' => $studentId]);
    $resumes = $stmt->fetchAll();

    sendJson(['success' => true, 'data' => $resumes]);
}

// 2. POST: Upload new resume version and set as active
if ($method === 'POST') {
    $action = $_POST['action'] ?? 'upload';

    if ($action === 'set_active') {
        $resumeId = (int)($_POST['resume_id'] ?? 0);
        if ($resumeId <= 0) sendError('Resume ID is required.');

        $stmt = $pdo->prepare("SELECT * FROM resumes WHERE id = :id AND student_id = :sid LIMIT 1");
        $stmt->execute(['id' => $resumeId, 'sid' => $studentId]);
        $target = $stmt->fetch();
        if (!$target) sendError('Resume not found.', 404);

        $pdo->beginTransaction();
        try {
            $pdo->prepare("UPDATE resumes SET is_active = 0 WHERE student_id = :sid")->execute(['sid' => $studentId]);
            $pdo->prepare("UPDATE resumes SET is_active = 1 WHERE id = :id")->execute(['id' => $resumeId]);
            $pdo->prepare("UPDATE students SET resume = :r, resume_updated_at = NOW() WHERE id = :sid")->execute([
                'r' => $target['stored_filename'],
                'sid' => $studentId
            ]);
            $pdo->commit();
            sendJson(['success' => true, 'message' => 'Active resume updated successfully.']);
        } catch (Exception $e) {
            $pdo->rollBack();
            sendError('Failed to activate resume: ' . $e->getMessage(), 500);
        }
    }

    if ($action === 'delete') {
        $resumeId = (int)($_POST['resume_id'] ?? 0);
        if ($resumeId <= 0) sendError('Resume ID is required.');

        $stmt = $pdo->prepare("SELECT * FROM resumes WHERE id = :id AND student_id = :sid LIMIT 1");
        $stmt->execute(['id' => $resumeId, 'sid' => $studentId]);
        $target = $stmt->fetch();
        if (!$target) sendError('Resume not found.', 404);

        $pdo->beginTransaction();
        try {
            $pdo->prepare("DELETE FROM resumes WHERE id = :id")->execute(['id' => $resumeId]);
            // If active was deleted, make the latest one active
            if ((int)$target['is_active'] === 1) {
                $latest = $pdo->prepare("SELECT * FROM resumes WHERE student_id = :sid ORDER BY id DESC LIMIT 1");
                $latest->execute(['sid' => $studentId]);
                $next = $latest->fetch();
                if ($next) {
                    $pdo->prepare("UPDATE resumes SET is_active = 1 WHERE id = :id")->execute(['id' => $next['id']]);
                    $pdo->prepare("UPDATE students SET resume = :r, resume_updated_at = NOW() WHERE id = :sid")->execute([
                        'r' => $next['stored_filename'],
                        'sid' => $studentId
                    ]);
                } else {
                    $pdo->prepare("UPDATE students SET resume = NULL, resume_updated_at = NULL WHERE id = :sid")->execute(['sid' => $studentId]);
                }
            }
            $pdo->commit();

            // Safe physical file removal
            $filePath = __DIR__ . '/../../' . $target['file_path'];
            if (file_exists($filePath)) {
                @unlink($filePath);
            }

            sendJson(['success' => true, 'message' => 'Resume deleted successfully.']);
        } catch (Exception $e) {
            $pdo->rollBack();
            sendError('Failed to delete resume: ' . $e->getMessage(), 500);
        }
    }

    // Default: Upload new version
    if (!isset($_FILES['resume']) || $_FILES['resume']['error'] !== UPLOAD_ERR_OK) {
        $err = $_FILES['resume']['error'] ?? 'None';
        sendError("No resume file uploaded or error code: {$err}", 400);
    }

    $file = $_FILES['resume'];
    $allowed = ['pdf' => 'pdf', 'docx' => 'docx', 'doc' => 'docx'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!isset($allowed[$ext])) {
        sendError('Invalid file format. Please upload a PDF or DOCX resume.', 422);
    }

    if ($file['size'] > 5 * 1024 * 1024) {
        sendError('File size exceeds the 5MB institutional limit.', 422);
    }

    $uploadDir = __DIR__ . '/../../uploads/resumes';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $storedFilename = 'resume_' . $studentId . '_' . time() . '.' . $ext;
    $relPath = 'uploads/resumes/' . $storedFilename;
    $targetPath = $uploadDir . '/' . $storedFilename;

    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        sendError('Failed to save file on server.', 500);
    }

    // Extract text for ATS analysis integration
    require_once __DIR__ . '/../ats/AtsEngine.php';
    $extractedText = AtsEngine::extractText($targetPath, $ext);

    // Compute next version number
    $vStmt = $pdo->prepare("SELECT COALESCE(MAX(version_number), 0) + 1 AS next_v FROM resumes WHERE student_id = :sid");
    $vStmt->execute(['sid' => $studentId]);
    $nextVersion = (int)($vStmt->fetch()['next_v'] ?? 1);

    $pdo->beginTransaction();
    try {
        // Deactivate older resumes
        $pdo->prepare("UPDATE resumes SET is_active = 0 WHERE student_id = :sid")->execute(['sid' => $studentId]);

        // Insert new version
        $ins = $pdo->prepare("
            INSERT INTO resumes (student_id, original_filename, stored_filename, file_path, file_type, file_size, extracted_text, is_active, version_number, uploaded_at)
            VALUES (:sid, :orig, :stored, :path, :type, :size, :txt, 1, :v, NOW())
        ");
        $ins->execute([
            'sid' => $studentId,
            'orig' => sanitizeString($file['name']),
            'stored' => $storedFilename,
            'path' => $relPath,
            'type' => $allowed[$ext],
            'size' => $file['size'],
            'txt' => $extractedText,
            'v' => $nextVersion
        ]);
        $newResumeId = (int)$pdo->lastInsertId();

        // Update student master record
        $pdo->prepare("UPDATE students SET resume = :r, resume_updated_at = NOW() WHERE id = :sid")->execute([
            'r' => $storedFilename,
            'sid' => $studentId
        ]);

        logAudit('Resume Upload', "Student {$studentId} uploaded resume version v{$nextVersion}: {$file['name']}", $user['id']);
        $pdo->commit();

        sendJson([
            'success' => true,
            'message' => "Resume version v{$nextVersion} uploaded and set as active!",
            'data' => [
                'id' => $newResumeId,
                'version' => $nextVersion,
                'filename' => $storedFilename,
                'original_filename' => $file['name'],
                'path' => $relPath,
                'uploaded_at' => date('Y-m-d H:i:s')
            ]
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        sendError('Database error during resume save: ' . $e->getMessage(), 500);
    }
}

sendError('Method Not Allowed', 405);
