<?php
/**
 * API: Publish / Unpublish Portfolio
 * POST: { is_published: true/false, template?: string, primary_color?: string }
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireRole(['student']);
$pdo = Database::getConnection();

$studentId = (int)($user['student_profile']['id'] ?? 0);
if ($studentId <= 0) {
    sendError('Student profile not found.', 404);
}

$data = getRequestData();
$isPublished = !empty($data['is_published']) ? 1 : 0;
$template = in_array($data['template'] ?? '', ['modern', 'tech_dark', 'minimal', 'executive'], true) ? $data['template'] : null;
$primaryColor = !empty($data['primary_color']) ? trim($data['primary_color']) : null;

$pStmt = $pdo->prepare("SELECT id, slug, template, primary_color FROM student_portfolios WHERE student_id = :sid LIMIT 1");
$pStmt->execute(['sid' => $studentId]);
$portfolio = $pStmt->fetch();

if (!$portfolio) {
    sendError('Portfolio not found.', 404);
}

$sql = "UPDATE student_portfolios SET is_published = :pub";
$params = ['pub' => $isPublished, 'id' => $portfolio['id']];

if ($template !== null) {
    $sql .= ", template = :tpl";
    $params['tpl'] = $template;
}
if ($primaryColor !== null) {
    $sql .= ", primary_color = :col";
    $params['col'] = $primaryColor;
}
$sql .= ", updated_at = NOW() WHERE id = :id";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$baseUrl = defined('APP_URL') ? APP_URL : 'http://127.0.0.1:8000';
$publicUrl = "{$baseUrl}/#public-portfolio?slug=" . urlencode($portfolio['slug']);

sendJson([
    'success' => true,
    'message' => $isPublished ? 'Portfolio published successfully! Your public link is live.' : 'Portfolio changed to Draft (Unpublished).',
    'is_published' => $isPublished === 1,
    'slug' => $portfolio['slug'],
    'public_url' => $publicUrl
]);
