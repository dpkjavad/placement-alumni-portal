<?php
/**
 * API: Direct Chat Messaging Endpoint
 * Handles: Real-time Message Exchange, Unread Status, History, and Reporting
 * Phase 8: Student-Alumni Direct Chat System
 */

require_once __DIR__ . '/../../config/auth.php';

$user = requireLogin();
$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

// Helper to verify caller is a participant in the request
function verifyParticipant(PDO $pdo, int $requestId, array $user): array {
    $stmt = $pdo->prepare("
        SELECT cr.*, 
               s.user_id AS student_user_id, su.name AS student_name, su.avatar AS student_avatar,
               a.user_id AS alumni_user_id, au.name AS alumni_name, au.avatar AS alumni_avatar
        FROM chat_requests cr
        JOIN students s ON cr.student_id = s.id
        JOIN users su ON s.user_id = su.id
        JOIN alumni a ON cr.alumni_id = a.id
        JOIN users au ON a.user_id = au.id
        WHERE cr.id = :id LIMIT 1
    ");
    $stmt->execute(['id' => $requestId]);
    $req = $stmt->fetch();

    if (!$req) {
        sendError('Chat conversation not found.', 404);
    }

    $currentUserId = (int)$user['id'];
    $isStudent = ($currentUserId === (int)$req['student_user_id']);
    $isAlumni = ($currentUserId === (int)$req['alumni_user_id']);
    $isAdmin = in_array($user['role'], ['admin', 'officer']);

    if (!$isStudent && !$isAlumni && !$isAdmin) {
        sendError('Forbidden. You are not a participant in this conversation.', 403);
    }

    $recipientId = $isStudent ? (int)$req['alumni_user_id'] : (int)$req['student_user_id'];
    $recipientName = $isStudent ? $req['alumni_name'] : $req['student_name'];

    return [
        'request' => $req,
        'recipient_id' => $recipientId,
        'recipient_name' => $recipientName,
        'is_admin' => $isAdmin
    ];
}

// 1. GET: Fetch conversation history
if ($method === 'GET') {
    $requestId = (int)($_GET['request_id'] ?? 0);
    if ($requestId <= 0) sendError('Request ID is required.');

    $context = verifyParticipant($pdo, $requestId, $user);

    // Mark unread incoming messages as read
    $mark = $pdo->prepare("UPDATE chat_messages SET is_read = 1 WHERE request_id = :rid AND recipient_id = :uid AND is_read = 0");
    $mark->execute(['rid' => $requestId, 'uid' => $user['id']]);

    // Fetch messages
    $stmt = $pdo->prepare("
        SELECT cm.*, u.name AS sender_name, u.avatar AS sender_avatar
        FROM chat_messages cm
        JOIN users u ON cm.sender_id = u.id
        WHERE cm.request_id = :rid
        ORDER BY cm.id ASC
    ");
    $stmt->execute(['rid' => $requestId]);
    $messages = $stmt->fetchAll();

    sendJson([
        'success' => true,
        'data' => $messages,
        'conversation_meta' => [
            'request_id' => $requestId,
            'status' => $context['request']['status'],
            'recipient_id' => $context['recipient_id'],
            'recipient_name' => $context['recipient_name'],
            'initial_message' => $context['request']['message']
        ]
    ]);
}

// 2. POST: Send message or report conversation
if ($method === 'POST') {
    $data = getRequestData();
    $action = $data['action'] ?? 'send';
    $requestId = (int)($data['request_id'] ?? 0);
    if ($requestId <= 0) sendError('Request ID is required.');

    $context = verifyParticipant($pdo, $requestId, $user);

    // Reporting inappropriate communication
    if ($action === 'report') {
        $reason = trim($data['reason'] ?? 'Inappropriate communication or unprofessional behavior');
        $messageId = (int)($data['message_id'] ?? 0);

        if ($messageId > 0) {
            $rep = $pdo->prepare("UPDATE chat_messages SET is_reported = 1, report_reason = :r WHERE id = :mid AND request_id = :rid");
            $rep->execute(['r' => sanitizeString($reason), 'mid' => $messageId, 'rid' => $requestId]);
        }

        logAudit('Chat Reported', "User {$user['id']} reported chat request {$requestId}: {$reason}", $user['id']);
        sendJson(['success' => true, 'message' => 'Thank you. The conversation has been flagged for institutional administrator review.']);
    }

    // Direct message dispatch
    $req = $context['request'];
    if ($req['status'] !== 'accepted') {
        sendError('Direct messaging is only available after the chat request has been accepted.', 403);
    }

    $message = trim($data['message'] ?? '');
    if (empty($message)) {
        sendError('Message text cannot be empty.');
    }

    $ins = $pdo->prepare("
        INSERT INTO chat_messages (request_id, sender_id, recipient_id, message, is_read)
        VALUES (:rid, :sid, :rec, :msg, 0)
    ");
    $ins->execute([
        'rid' => $requestId,
        'sid' => $user['id'],
        'rec' => $context['recipient_id'],
        'msg' => sanitizeString($message)
    ]);
    $newMsgId = (int)$pdo->lastInsertId();

    // Trigger instant notification to recipient
    createNotification(
        $context['recipient_id'],
        "New message from {$user['name']}",
        mb_strimwidth($message, 0, 80, "..."),
        'chat',
        $requestId
    );

    sendJson([
        'success' => true,
        'message' => 'Message delivered.',
        'data' => [
            'id' => $newMsgId,
            'request_id' => $requestId,
            'sender_id' => $user['id'],
            'sender_name' => $user['name'],
            'message' => $message,
            'created_at' => date('Y-m-d H:i:s')
        ]
    ]);
}

sendError('Method Not Allowed', 405);
